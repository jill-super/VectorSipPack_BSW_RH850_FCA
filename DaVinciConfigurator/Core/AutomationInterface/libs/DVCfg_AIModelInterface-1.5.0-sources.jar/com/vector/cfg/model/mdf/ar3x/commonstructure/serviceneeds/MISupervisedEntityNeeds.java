package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs on the configuration of the Watchdog Manager for one specific Supervised Entity (SE).
 */
public interface MISupervisedEntityNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "SupervisedEntityNeeds";
  // attribute : activateAtStart generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACTIVATE_AT_START = "activateAtStart";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACTIVATE_AT_START_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACTIVATE_AT_START,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * true/false: supervision activation status of SE shall be enabled/disabled at start
   * Attribute-Kind = versionAttribute   */
  public Boolean getActivateAtStart();
  /**
   * true/false: supervision activation status of SE shall be enabled/disabled at start
   * Attribute-Kind = versionAttribute   */
  public void setActivateAtStart(Boolean newValue);
  // attribute : enableDeactivation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ENABLE_DEACTIVATION = "enableDeactivation";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ENABLE_DEACTIVATION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ENABLE_DEACTIVATION,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * true: SWC shall be allowed to deactivate supervision of this SE false: not
   * Attribute-Kind = versionAttribute   */
  public Boolean getEnableDeactivation();
  /**
   * true: SWC shall be allowed to deactivate supervision of this SE false: not
   * Attribute-Kind = versionAttribute   */
  public void setEnableDeactivation(Boolean newValue);
  // attribute : expectedAliveCycle generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXPECTED_ALIVE_CYCLE = "expectedAliveCycle";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo EXPECTED_ALIVE_CYCLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,EXPECTED_ALIVE_CYCLE,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Expected cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getExpectedAliveCycle();
  /**
   * Expected cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public void setExpectedAliveCycle(java.math.BigDecimal newValue);
  // attribute : maxAliveCycle generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_ALIVE_CYCLE = "maxAliveCycle";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_ALIVE_CYCLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_ALIVE_CYCLE,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaxAliveCycle();
  /**
   * Maximum cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public void setMaxAliveCycle(java.math.BigDecimal newValue);
  // attribute : minAliveCycle generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_ALIVE_CYCLE = "minAliveCycle";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_ALIVE_CYCLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_ALIVE_CYCLE,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinAliveCycle();
  /**
   * Minimum cycle time of alive trigger of this SE (in seconds)
   * Attribute-Kind = versionAttribute   */
  public void setMinAliveCycle(java.math.BigDecimal newValue);
  // attribute : toleratedFailedCycles generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TOLERATED_FAILED_CYCLES = "toleratedFailedCycles";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TOLERATED_FAILED_CYCLES_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TOLERATED_FAILED_CYCLES,"ar3x.commonstructure.serviceneeds.SupervisedEntityNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Number of consecutive failed alive cycles for this SE which shall be tolerated until the supervision status of the SE is set to EXPIRED (see WdgM documentation for details). Note that this has to be recalculated w.r.t. the WdgMs own cycle time for ECU configuration.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getToleratedFailedCycles();
  /**
   * Number of consecutive failed alive cycles for this SE which shall be tolerated until the supervision status of the SE is set to EXPIRED (see WdgM documentation for details). Note that this has to be recalculated w.r.t. the WdgMs own cycle time for ECU configuration.
   * Attribute-Kind = versionAttribute   */
  public void setToleratedFailedCycles(java.math.BigInteger newValue);
}
