package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * BSW module entity, which is designed for control by the BSW Scheduler. It implements a so-called "main" function.
 */
public interface MIBswSchedulableEntity extends com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity
{
  public final static String CLASS_NAME = "BswSchedulableEntity";
  // reference : bswSchedulableEntityARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_SCHEDULABLE_ENTITY_ARREF_REF_TARGETS_OWNER = "bswSchedulableEntityARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_SCHEDULABLE_ENTITY_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_SCHEDULABLE_ENTITY_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswSchedulableEntity",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef> getBswSchedulableEntityARRefRefTargetsOwner();
}
