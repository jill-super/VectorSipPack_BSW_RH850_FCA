package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;
import javax.jmi.model.*;

public enum MISwGenericAxisParamTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_GENERIC_AXIS_PARAM_TYPE("SW-GENERIC-AXIS-PARAM-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "axis" );
    temp.add( "SwGenericAxisParamTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwGenericAxisParamTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
