package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHWElementARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "HWElementARRef";
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.HWElementARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: hWElementARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.HWElementARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.H_WELEMENT_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement> getRefTargets();
  // reference : complexDeviceDriverComponentType_hardwareElement_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER = "complexDeviceDriverComponentType_hardwareElement_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: hardwareElement
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER,"ar3x.ecuresourcetemplate.HWElementARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType.HARDWARE_ELEMENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType getComplexDeviceDriverComponentTypeHardwareElementOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComplexDeviceDriverComponentTypeHardwareElementOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType newValue);
  // reference : ecuAbstractionComponentType_hardwareElement_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_ABSTRACTION_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER = "ecuAbstractionComponentType_hardwareElement_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: hardwareElement
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_ABSTRACTION_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_ABSTRACTION_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER,"ar3x.ecuresourcetemplate.HWElementARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType.HARDWARE_ELEMENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType getEcuAbstractionComponentTypeHardwareElementOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuAbstractionComponentTypeHardwareElementOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType newValue);
  // reference : bswImplementation_requiredHW_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_IMPLEMENTATION_REQUIRED_HW_OWNER = "bswImplementation_requiredHW_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: requiredHW
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_IMPLEMENTATION_REQUIRED_HW_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_IMPLEMENTATION_REQUIRED_HW_OWNER,"ar3x.ecuresourcetemplate.HWElementARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswimplementation.MIBswImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswimplementation.MIBswImplementation.REQUIRED_HW_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswimplementation.MIBswImplementation getBswImplementationRequiredHWOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswImplementationRequiredHWOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswimplementation.MIBswImplementation newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement newRefTarget);

}
