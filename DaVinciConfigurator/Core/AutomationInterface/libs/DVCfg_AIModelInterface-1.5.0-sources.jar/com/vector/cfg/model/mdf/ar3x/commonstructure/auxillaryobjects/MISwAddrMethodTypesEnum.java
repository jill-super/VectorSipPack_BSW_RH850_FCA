package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;
import javax.jmi.model.*;

public enum MISwAddrMethodTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_ADDR_METHOD("SW-ADDR-METHOD");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "auxillaryobjects" );
    temp.add( "SwAddrMethodTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwAddrMethodTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
