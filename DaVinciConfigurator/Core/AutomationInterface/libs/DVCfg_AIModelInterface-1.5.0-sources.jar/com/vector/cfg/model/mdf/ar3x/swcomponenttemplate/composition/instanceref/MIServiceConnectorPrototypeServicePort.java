package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIServiceConnectorPrototypeServicePort extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ServiceConnectorPrototypeServicePort";
  // reference : serviceConnectorPrototype_servicePort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_OWNER = "serviceConnectorPrototype_servicePort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: servicePort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_OWNER,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeServicePort",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype.SERVICE_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype getServiceConnectorPrototypeServicePortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceConnectorPrototypeServicePortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype newValue);
  // reference : portPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE = "portPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototypeServicePort_portPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeServicePort",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef getPortPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef newValue);
  // reference : serviceComponentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_COMPONENT_PROTOTYPE = "serviceComponentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototypeServicePort_serviceComponentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeServicePort",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototypeARRef.SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_SERVICE_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototypeARRef getServiceComponentPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceComponentPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototypeARRef newValue);
}
