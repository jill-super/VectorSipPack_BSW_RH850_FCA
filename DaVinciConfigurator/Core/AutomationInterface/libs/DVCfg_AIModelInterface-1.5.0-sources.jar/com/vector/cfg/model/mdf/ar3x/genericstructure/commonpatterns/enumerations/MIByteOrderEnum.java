package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations;
import javax.jmi.model.*;

public enum MIByteOrderEnum implements javax.jmi.reflect.RefEnum
{
  MOST_SIGNIFICANT_BYTE_FIRST("MOST-SIGNIFICANT-BYTE-FIRST"),
  MOST_SIGNIFICANT_BYTE_LAST("MOST-SIGNIFICANT-BYTE-LAST");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "enumerations" );
    temp.add( "ByteOrderEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIByteOrderEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
