package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage;
import javax.jmi.model.*;

public enum MIMemorySectionType implements javax.jmi.reflect.RefEnum
{
  CODE("CODE"),
  VAR_NO_INIT("VAR-NO-INIT"),
  VAR_POWER_ON_INIT("VAR-POWER-ON-INIT"),
  VAR_FAST("VAR-FAST"),
  VAR("VAR"),
  CONST("CONST"),
  CONFIG_DATA("CONFIG-DATA"),
  USER_DEFINED("USER-DEFINED");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memorysectionusage" );
    temp.add( "MemorySectionType" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemorySectionType(String literalName)
  {
    this.literalName = literalName;
  }
}
