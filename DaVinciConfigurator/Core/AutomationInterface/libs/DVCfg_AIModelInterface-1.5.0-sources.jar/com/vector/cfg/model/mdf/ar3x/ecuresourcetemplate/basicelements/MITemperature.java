package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * General element to describe temperature ranges and need for cooling/heating.
 */
public interface MITemperature extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Temperature";
  // attribute : operationMin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPERATION_MIN = "operationMin";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPERATION_MIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPERATION_MIN,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * It describes the temperature range (min) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getOperationMin();
  /**
   * It describes the temperature range (min) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public void setOperationMin(java.math.BigInteger newValue);
  // attribute : operationMax generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPERATION_MAX = "operationMax";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPERATION_MAX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPERATION_MAX,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * It describes the temperature range (max) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getOperationMax();
  /**
   * It describes the temperature range (max) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public void setOperationMax(java.math.BigInteger newValue);
  // attribute : operationTypical generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPERATION_TYPICAL = "operationTypical";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPERATION_TYPICAL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPERATION_TYPICAL,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * It describes the temperature range (typical) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getOperationTypical();
  /**
   * It describes the temperature range (typical) in which the HW Element can be operated. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public void setOperationTypical(java.math.BigInteger newValue);
  // attribute : storageMin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STORAGE_MIN = "storageMin";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STORAGE_MIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STORAGE_MIN,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The storage temperature defines minimum temperature the device is allowed to be stored. The HW Element is not in an operational state. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getStorageMin();
  /**
   * The storage temperature defines minimum temperature the device is allowed to be stored. The HW Element is not in an operational state. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public void setStorageMin(java.math.BigInteger newValue);
  // attribute : storageMax generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STORAGE_MAX = "storageMax";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STORAGE_MAX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STORAGE_MAX,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The storage temperature defines maximum temperature the device is allowed to be stored. The HW Element is not in an operational state. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getStorageMax();
  /**
   * The storage temperature defines maximum temperature the device is allowed to be stored. The HW Element is not in an operational state. Unit: Kelvin (K)
   * Attribute-Kind = versionAttribute   */
  public void setStorageMax(java.math.BigInteger newValue);
  // attribute : needsCooling generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NEEDS_COOLING = "needsCooling";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NEEDS_COOLING_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NEEDS_COOLING,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * These attributes describe that there is an active cooling system required for this HW Element.
   * Attribute-Kind = versionAttribute   */
  public Boolean getNeedsCooling();
  /**
   * These attributes describe that there is an active cooling system required for this HW Element.
   * Attribute-Kind = versionAttribute   */
  public void setNeedsCooling(Boolean newValue);
  // attribute : needsHeating generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NEEDS_HEATING = "needsHeating";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NEEDS_HEATING_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NEEDS_HEATING,"ar3x.ecuresourcetemplate.basicelements.Temperature",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * These attributes describe that there is an active heating system required for this HW Element.
   * Attribute-Kind = versionAttribute   */
  public Boolean getNeedsHeating();
  /**
   * These attributes describe that there is an active heating system required for this HW Element.
   * Attribute-Kind = versionAttribute   */
  public void setNeedsHeating(Boolean newValue);
  // reference : hWElement_hwElementTemperature_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_HW_ELEMENT_TEMPERATURE_OWNER = "hWElement_hwElementTemperature_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: hwElementTemperature
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_HW_ELEMENT_TEMPERATURE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_HW_ELEMENT_TEMPERATURE_OWNER,"ar3x.ecuresourcetemplate.basicelements.Temperature",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.HW_ELEMENT_TEMPERATURE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement getHWElementHwElementTemperatureOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementHwElementTemperatureOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement newValue);
}
