package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This abstract class represents the possible methods of defining the size of a BaseType.
 */
public interface MIBaseTypeSizeDefinition extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "BaseTypeSizeDefinition";
  // reference : baseTypeDirectDefinition_baseTypeSizeDefintionType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_DIRECT_DEFINITION_BASE_TYPE_SIZE_DEFINTION_TYPE_OWNER = "baseTypeDirectDefinition_baseTypeSizeDefintionType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseTypeSizeDefintionType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_DIRECT_DEFINITION_BASE_TYPE_SIZE_DEFINTION_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_DIRECT_DEFINITION_BASE_TYPE_SIZE_DEFINTION_TYPE_OWNER,"ar3x.commonstructure.basetypes.BaseTypeSizeDefinition",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition.BASE_TYPE_SIZE_DEFINTION_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition getBaseTypeDirectDefinitionBaseTypeSizeDefintionTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeDirectDefinitionBaseTypeSizeDefintionTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition newValue);
}
