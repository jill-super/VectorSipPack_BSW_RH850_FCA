package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Dependency on the existence of a certain file.
 */
public interface MIDependencyOnFile extends com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency
{
  public final static String CLASS_NAME = "DependencyOnFile";
  // reference : dependencyOnFileXfile generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DEPENDENCY_ON_FILE_XFILE = "dependencyOnFileXfile";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: dependencyOnFile_dependencyOnFileXfile_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DEPENDENCY_ON_FILE_XFILE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DEPENDENCY_ON_FILE_XFILE,"ar3x.commonstructure.implementation.DependencyOnFile",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo.DEPENDENCY_ON_FILE_DEPENDENCY_ON_FILE_XFILE_OWNER_RELATION_INFO;}};
  /**
   * The specified file needs to exist.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo getDependencyOnFileXfile();
  /**
   * The specified file needs to exist.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDependencyOnFileXfile(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo newValue);
}
