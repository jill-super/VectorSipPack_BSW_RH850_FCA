package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes of PPortPrototypes with respect to Nv data communication on the provided side. 
 */
public interface MINvProvideComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "NvProvideComSpec";
  // reference : ramBlockInitValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RAM_BLOCK_INIT_VALUE = "ramBlockInitValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvProvideComSpec_ramBlockInitValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RAM_BLOCK_INIT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RAM_BLOCK_INIT_VALUE,"ar3x.swcomponenttemplate.communication.NvProvideComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.NV_PROVIDE_COM_SPEC_RAM_BLOCK_INIT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * This represents the initial value of the RAM block that corresponds to the referenced nvData.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef getRamBlockInitValue();
  /**
   * This represents the initial value of the RAM block that corresponds to the referenced nvData.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRamBlockInitValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef newValue);
  // reference : romBlockInitValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ROM_BLOCK_INIT_VALUE = "romBlockInitValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvProvideComSpec_romBlockInitValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ROM_BLOCK_INIT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ROM_BLOCK_INIT_VALUE,"ar3x.swcomponenttemplate.communication.NvProvideComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.NV_PROVIDE_COM_SPEC_ROM_BLOCK_INIT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * This represents the initial value of the ROM block that corresponds to the referenced nvData.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef getRomBlockInitValue();
  /**
   * This represents the initial value of the ROM block that corresponds to the referenced nvData.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRomBlockInitValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef newValue);
  // reference : nvDataElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_DATA_ELEMENT = "nvDataElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvProvideComSpec_nvDataElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_DATA_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_DATA_ELEMENT,"ar3x.swcomponenttemplate.communication.NvProvideComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.NV_PROVIDE_COM_SPEC_NV_DATA_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * The DataElementPrototype the ComSpec applies for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getNvDataElement();
  /**
   * The DataElementPrototype the ComSpec applies for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setNvDataElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
}
