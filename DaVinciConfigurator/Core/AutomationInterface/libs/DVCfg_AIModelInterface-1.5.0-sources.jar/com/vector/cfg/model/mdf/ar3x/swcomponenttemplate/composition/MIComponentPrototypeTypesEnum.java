package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;
import javax.jmi.model.*;

public enum MIComponentPrototypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  COMPONENT_PROTOTYPE("COMPONENT-PROTOTYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "composition" );
    temp.add( "ComponentPrototypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIComponentPrototypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
