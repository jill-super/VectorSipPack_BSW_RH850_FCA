package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;
import javax.jmi.model.*;

public enum MISwCalibrationAccessEnum implements javax.jmi.reflect.RefEnum
{
  READ_ONLY("READ-ONLY"),
  NOT_ACCESSIBLE("NOT-ACCESSIBLE"),
  READ_WRITE("READ-WRITE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "datadefproperties" );
    temp.add( "SwCalibrationAccessEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwCalibrationAccessEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
