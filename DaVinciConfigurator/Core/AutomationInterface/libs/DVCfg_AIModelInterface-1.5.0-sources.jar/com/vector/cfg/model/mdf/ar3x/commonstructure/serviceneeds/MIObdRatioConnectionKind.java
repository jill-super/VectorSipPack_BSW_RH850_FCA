package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

public enum MIObdRatioConnectionKind implements javax.jmi.reflect.RefEnum
{
  API_USE("API-USE"),
  OBSERVER("OBSERVER");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "ObdRatioConnectionKind" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIObdRatioConnectionKind(String literalName)
  {
    this.literalName = literalName;
  }
}
