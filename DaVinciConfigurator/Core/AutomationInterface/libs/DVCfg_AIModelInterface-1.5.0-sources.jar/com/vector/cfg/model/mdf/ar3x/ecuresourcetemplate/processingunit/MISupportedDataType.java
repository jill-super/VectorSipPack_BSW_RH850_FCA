package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element provides a list of all supported data types and its according data sizes of the described PU. Examples: Boolean (1, 8 bit), Bit String / Bit Field (x bit), Character (8, 16 bit), Signed / unsigned integer (8, 16, 24, 32, 48, 64 bit), Single / double float (56, 64 bit), Fixed point (24 bit), Fractional, Packed (two values handled in one register)
 */
public interface MISupportedDataType extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "SupportedDataType";
  // reference : processingUnit_supportedDataType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSING_UNIT_SUPPORTED_DATA_TYPE_OWNER = "processingUnit_supportedDataType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: supportedDataType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_SUPPORTED_DATA_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_SUPPORTED_DATA_TYPE_OWNER,"ar3x.ecuresourcetemplate.processingunit.SupportedDataType",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.SUPPORTED_DATA_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitSupportedDataTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProcessingUnitSupportedDataTypeOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
  // reference : supportedDataSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SUPPORTED_DATA_SIZE = "supportedDataSize";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: supportedDataType_supportedDataSize_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTED_DATA_SIZE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTED_DATA_SIZE,"ar3x.ecuresourcetemplate.processingunit.SupportedDataType",133,null,com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem.SUPPORTED_DATA_TYPE_SUPPORTED_DATA_SIZE_OWNER_RELATION_INFO;}};
  /**
   * The size of the data type. Unit: Bit
   */
  public java.util.List<com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem> getSupportedDataSize();
}
