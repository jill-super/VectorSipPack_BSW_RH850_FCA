package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A HWPin is an elementary electrical interface of the HWElement. The HWPins of a HWPort can be clustered if there are some HWPins with the same behaviour.
 */
public interface MIHWPin extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "HWPin";
  // reference : hWPinARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String H_WPIN_ARREF_REF_TARGETS_OWNER = "hWPinARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WPIN_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WPIN_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.HWPin",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef> getHWPinARRefRefTargetsOwner();
  // reference : hWPort_pin_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WPORT_PIN_OWNER = "hWPort_pin_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: pin
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WPORT_PIN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WPORT_PIN_OWNER,"ar3x.ecuresourcetemplate.HWPin",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort.PIN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort getHWPortPinOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWPortPinOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort newValue);
}
