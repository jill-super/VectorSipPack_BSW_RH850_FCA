package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIECUCommunicationPortARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ECUCommunicationPortARRef";
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.peripherals.ECUCommunicationPortARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: eCUCommunicationPortARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.peripherals.ECUCommunicationPortARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPort.E_CUCOMMUNICATION_PORT_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPort> getRefTargets();
  // reference : hWPortMapping_ecuCommunicationPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WPORT_MAPPING_ECU_COMMUNICATION_PORT_OWNER = "hWPortMapping_ecuCommunicationPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: ecuCommunicationPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WPORT_MAPPING_ECU_COMMUNICATION_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WPORT_MAPPING_ECU_COMMUNICATION_PORT_OWNER,"ar3x.ecuresourcetemplate.peripherals.ECUCommunicationPortARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIHWPortMapping.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIHWPortMapping.ECU_COMMUNICATION_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIHWPortMapping getHWPortMappingEcuCommunicationPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWPortMappingEcuCommunicationPortOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIHWPortMapping newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPort getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPort newRefTarget);

}
