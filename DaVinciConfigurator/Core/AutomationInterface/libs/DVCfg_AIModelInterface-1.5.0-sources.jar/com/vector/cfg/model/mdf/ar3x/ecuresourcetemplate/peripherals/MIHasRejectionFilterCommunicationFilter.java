package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasRejectionFilterCommunicationFilter extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasRejectionFilterCommunicationFilter";
  // reference : rejectionFilter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REJECTION_FILTER = "rejectionFilter";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasRejectionFilterCommunicationFilter_rejectionFilter_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REJECTION_FILTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REJECTION_FILTER,"ar3x.ecuresourcetemplate.peripherals.HasRejectionFilterCommunicationFilter",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter.HAS_REJECTION_FILTER_COMMUNICATION_FILTER_REJECTION_FILTER_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter getRejectionFilter();
  public void setRejectionFilter(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter newValue);
}
