package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * These are the common attributes for both, the ADC and the DAC.
 */
public interface MIAnalogueIO extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral
{
  public final static String CLASS_NAME = "AnalogueIO";
  // attribute : accuracy generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACCURACY = "accuracy";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACCURACY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACCURACY,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * There is a number of different conversion error in an ADC or DAC like non-linearity and absolute error. The accuracy is defined as the total error and it can be expressed as a deviation from its nominal value by e.g. 0.5, 1.0, 1.5 or 2.0 LSB.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getAccuracy();
  /**
   * There is a number of different conversion error in an ADC or DAC like non-linearity and absolute error. The accuracy is defined as the total error and it can be expressed as a deviation from its nominal value by e.g. 0.5, 1.0, 1.5 or 2.0 LSB.
   * Attribute-Kind = versionAttribute   */
  public void setAccuracy(java.math.BigDecimal newValue);
  // attribute : conversionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CONVERSION_TIME = "conversionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CONVERSION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CONVERSION_TIME,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * ADC: The conversion time is the definition how long it takes for an ADC to convert an analogue signal to a digital value. DAC: The conversion time is the definition how long it takes for a DAC to convert a digital value to an analogue signal.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getConversionTime();
  /**
   * ADC: The conversion time is the definition how long it takes for an ADC to convert an analogue signal to a digital value. DAC: The conversion time is the definition how long it takes for a DAC to convert a digital value to an analogue signal.
   * Attribute-Kind = versionAttribute   */
  public void setConversionTime(java.math.BigDecimal newValue);
  // attribute : mode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODE = "mode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODE,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIoModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * An ADC or DAC can operate in continuous, single  or sequential mode. In the continuous mode the conversion is automatically repeated after a completion. In single shot only one conversion is performed. For the sequential mode can a predefined number of different analogue channels be converted.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIoModeEnum getMode();
  /**
   * An ADC or DAC can operate in continuous, single  or sequential mode. In the continuous mode the conversion is automatically repeated after a completion. In single shot only one conversion is performed. For the sequential mode can a predefined number of different analogue channels be converted.
   * Attribute-Kind = versionAttribute   */
  public void setMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIoModeEnum newValue);
  // attribute : multiplexedM generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MULTIPLEXED_M = "multiplexedM";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MULTIPLEXED_M_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MULTIPLEXED_M,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the design of a simple multiplexer used by an ADC. Example A 2:8-multiplexer has 2 input channels and 8 registers. M is the second value.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMultiplexedM();
  /**
   * Defines the design of a simple multiplexer used by an ADC. Example A 2:8-multiplexer has 2 input channels and 8 registers. M is the second value.
   * Attribute-Kind = versionAttribute   */
  public void setMultiplexedM(java.math.BigInteger newValue);
  // attribute : multiplexedN generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MULTIPLEXED_N = "multiplexedN";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MULTIPLEXED_N_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MULTIPLEXED_N,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the design of a simple multiplexer used by an ADC. Example A 2:8-multiplexer has 2 input channels and 8 registers. N is the first value.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMultiplexedN();
  /**
   * Defines the design of a simple multiplexer used by an ADC. Example A 2:8-multiplexer has 2 input channels and 8 registers. N is the first value.
   * Attribute-Kind = versionAttribute   */
  public void setMultiplexedN(java.math.BigInteger newValue);
  // attribute : resolution generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION = "resolution";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * For an Analogue to Digital Converter the resolution defines the number of different voltage levels, which are converted to a digital value. For example, an ADC with 10-bits resolution have the ability to convert an analogue value into 1024 different digital  values. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getResolution();
  /**
   * For an Analogue to Digital Converter the resolution defines the number of different voltage levels, which are converted to a digital value. For example, an ADC with 10-bits resolution have the ability to convert an analogue value into 1024 different digital  values. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public void setResolution(java.math.BigInteger newValue);
  // attribute : width generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WIDTH = "width";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WIDTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WIDTH,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The number of Bits used to store the digital value.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getWidth();
  /**
   * The number of Bits used to store the digital value.
   * Attribute-Kind = versionAttribute   */
  public void setWidth(java.math.BigInteger newValue);
  // reference : externalReferenceVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXTERNAL_REFERENCE_VOLTAGE = "externalReferenceVoltage";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: analogueIO_externalReferenceVoltage_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXTERNAL_REFERENCE_VOLTAGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXTERNAL_REFERENCE_VOLTAGE,"ar3x.ecuresourcetemplate.peripherals.AnalogueIO",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange.ANALOGUE_IO_EXTERNAL_REFERENCE_VOLTAGE_OWNER_RELATION_INFO;}};
  /**
   * The analogue comparator of an ADC must be connected to a voltage reference. An external voltage is usually connected to one low and one high voltage reference input pin. For an internal DAC it is normally only one voltage reference input. The low voltage reference input is internally connected to the analogue ground.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange getExternalReferenceVoltage();
  /**
   * The analogue comparator of an ADC must be connected to a voltage reference. An external voltage is usually connected to one low and one high voltage reference input pin. For an internal DAC it is normally only one voltage reference input. The low voltage reference input is internally connected to the analogue ground.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setExternalReferenceVoltage(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange newValue);
}
