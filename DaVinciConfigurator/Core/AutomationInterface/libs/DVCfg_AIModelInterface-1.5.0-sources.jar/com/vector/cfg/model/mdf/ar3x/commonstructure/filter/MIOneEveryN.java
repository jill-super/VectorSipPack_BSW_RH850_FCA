package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pass a message once every N message occurrences. Algorithm: occurrence % period == offset Start: occurrence = 0. Each time the message is received or transmitted, occurrence is incremented by 1 after filtering. Length of occurrence is 8 bit (minimum).
 */
public interface MIOneEveryN extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "OneEveryN";
  // attribute : period generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PERIOD = "period";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PERIOD_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PERIOD,"ar3x.commonstructure.filter.OneEveryN",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * specifies number of messages to occur before the message is passed again
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getPeriod();
  /**
   * specifies number of messages to occur before the message is passed again
   * Attribute-Kind = versionAttribute   */
  public void setPeriod(java.math.BigInteger newValue);
  // attribute : offset generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OFFSET = "offset";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OFFSET_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OFFSET,"ar3x.commonstructure.filter.OneEveryN",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * specifies the initial number of messages to occur before the first message is passed
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getOffset();
  /**
   * specifies the initial number of messages to occur before the first message is passed
   * Attribute-Kind = versionAttribute   */
  public void setOffset(java.math.BigInteger newValue);
}
