package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;
import javax.jmi.model.*;

public enum MIPortGroupTypesEnum implements javax.jmi.reflect.RefEnum
{
  PORT_GROUP("PORT-GROUP");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "components" );
    temp.add( "PortGroupTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIPortGroupTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
