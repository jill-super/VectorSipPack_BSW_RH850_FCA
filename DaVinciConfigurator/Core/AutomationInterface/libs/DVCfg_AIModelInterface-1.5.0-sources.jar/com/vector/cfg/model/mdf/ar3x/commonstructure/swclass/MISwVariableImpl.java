package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes the implementation details of a class attribute which manifests itself as a variable.
 */
public interface MISwVariableImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwVariableImpl";
  // reference : swVariablePrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_VARIABLE_PROTOTYPE = "swVariablePrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swVariableImpl_swVariablePrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_PROTOTYPE,"ar3x.commonstructure.swclass.SwVariableImpl",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef.SW_VARIABLE_IMPL_SW_VARIABLE_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * This element describes the prototype declaration of a class attribute, which appears in the form of a variable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef getSwVariablePrototype();
  /**
   * This element describes the prototype declaration of a class attribute, which appears in the form of a variable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwVariablePrototype(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef newValue);
  // reference : hasSwVariableImpl_swVariableImpl_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SW_VARIABLE_IMPL_SW_VARIABLE_IMPL_OWNER = "hasSwVariableImpl_swVariableImpl_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swVariableImpl
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SW_VARIABLE_IMPL_SW_VARIABLE_IMPL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SW_VARIABLE_IMPL_SW_VARIABLE_IMPL_OWNER,"ar3x.commonstructure.swclass.SwVariableImpl",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl.SW_VARIABLE_IMPL_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl getHasSwVariableImplSwVariableImplOwner();
  public void setHasSwVariableImplSwVariableImplOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl newValue);
}
