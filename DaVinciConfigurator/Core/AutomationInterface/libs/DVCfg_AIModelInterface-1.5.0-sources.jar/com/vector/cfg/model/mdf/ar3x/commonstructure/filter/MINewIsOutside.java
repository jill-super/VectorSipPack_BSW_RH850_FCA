package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pass a message if its value is outside a predefined boundary.  (min > new_value) OR (new_value > max)
 */
public interface MINewIsOutside extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "NewIsOutside";
  // attribute : max generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX = "max";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX,"ar3x.commonstructure.filter.NewIsOutside",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Value to specify the upper boundary
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMax();
  /**
   * Value to specify the upper boundary
   * Attribute-Kind = versionAttribute   */
  public void setMax(java.math.BigInteger newValue);
  // attribute : min generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN = "min";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN,"ar3x.commonstructure.filter.NewIsOutside",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Value to specify the lower boundary
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMin();
  /**
   * Value to specify the lower boundary
   * Attribute-Kind = versionAttribute   */
  public void setMin(java.math.BigInteger newValue);
}
