package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the linker attributes used to decribe how the linker shall be invoked.
 */
public interface MILinker extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "Linker";
  // attribute : linkerName generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LINKER_NAME = "linkerName";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LINKER_NAME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LINKER_NAME,"ar3x.commonstructure.implementation.Linker",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Linker name.
   * Attribute-Kind = versionAttribute   */
  public String getLinkerName();
  /**
   * Linker name.
   * Attribute-Kind = versionAttribute   */
  public void setLinkerName(String newValue);
  // attribute : options generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPTIONS = "options";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPTIONS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPTIONS,"ar3x.commonstructure.implementation.Linker",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the linker options.
   * Attribute-Kind = versionAttribute   */
  public String getOptions();
  /**
   * Specifies the linker options.
   * Attribute-Kind = versionAttribute   */
  public void setOptions(String newValue);
  // attribute : vendor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VENDOR = "vendor";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VENDOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VENDOR,"ar3x.commonstructure.implementation.Linker",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Vendor of linker.
   * Attribute-Kind = versionAttribute   */
  public String getVendor();
  /**
   * Vendor of linker.
   * Attribute-Kind = versionAttribute   */
  public void setVendor(String newValue);
  // attribute : version generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VERSION = "version";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VERSION,"ar3x.commonstructure.implementation.Linker",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Exact version of linker executable.
   * Attribute-Kind = versionAttribute   */
  public String getVersion();
  /**
   * Exact version of linker executable.
   * Attribute-Kind = versionAttribute   */
  public void setVersion(String newValue);
  // reference : implementation_linker_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_LINKER_OWNER = "implementation_linker_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: linker
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_LINKER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_LINKER_OWNER,"ar3x.commonstructure.implementation.Linker",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.LINKER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationLinkerOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationLinkerOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);
}
