package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes an axis integrated into a parameter (field etc.). The integration makes this individual to each parameter. The so-called grouped axis represents the counterpart to this. It is conceived as an independent parameter (see class SwAxisGrouped).  The attributes swVariableRefs, compuMethod and unit can exist in parallel, although physically speaking, only one is practical. This parallelism introduces flexibility into the development process, as axes can be described purely physically, without a conversion formula being available. The following priority exists: * swVariableRefs * compuMethod * unit
 */
public interface MISwAxisIndividual extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy
{
  public final static String CLASS_NAME = "SwAxisIndividual";
  // reference : swCalprmAxisIndividualAxis_swAxisIndividual_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_INDIVIDUAL_AXIS_SW_AXIS_INDIVIDUAL_OWNER = "swCalprmAxisIndividualAxis_swAxisIndividual_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swAxisIndividual
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_INDIVIDUAL_AXIS_SW_AXIS_INDIVIDUAL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_INDIVIDUAL_AXIS_SW_AXIS_INDIVIDUAL_OWNER,"ar3x.commonstructure.axis.SwAxisIndividual",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisIndividualAxis.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisIndividualAxis.SW_AXIS_INDIVIDUAL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisIndividualAxis getSwCalprmAxisIndividualAxisSwAxisIndividualOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisIndividualAxisSwAxisIndividualOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisIndividualAxis newValue);
  // reference : swMinAxisPoints generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_MIN_AXIS_POINTS = "swMinAxisPoints";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_swMinAxisPoints_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_MIN_AXIS_POINTS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_MIN_AXIS_POINTS,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.SW_AXIS_INDIVIDUAL_SW_MIN_AXIS_POINTS_OWNER_RELATION_INFO;}};
  /**
   * This element specifies the minimum number of base points on the current axis of a map or curve.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf getSwMinAxisPoints();
  /**
   * This element specifies the minimum number of base points on the current axis of a map or curve.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwMinAxisPoints(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf newValue);
  // reference : swMaxAxisPoints generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_MAX_AXIS_POINTS = "swMaxAxisPoints";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_swMaxAxisPoints_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_MAX_AXIS_POINTS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_MAX_AXIS_POINTS,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.SW_AXIS_INDIVIDUAL_SW_MAX_AXIS_POINTS_OWNER_RELATION_INFO;}};
  /**
   * Maximum number of base points contained in the axis of a map or curve.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf getSwMaxAxisPoints();
  /**
   * Maximum number of base points contained in the axis of a map or curve.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwMaxAxisPoints(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf newValue);
  // reference : swAxisGeneric generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_GENERIC = "swAxisGeneric";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_swAxisGeneric_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_GENERIC_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_GENERIC,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric.SW_AXIS_INDIVIDUAL_SW_AXIS_GENERIC_OWNER_RELATION_INFO;}};
  /**
   * This element defines an axis for the base points calculated in the ECU. The ECU is equipped with a fixed calculation algorithm. Parameters for the algorithm can be stored in the data component of the ECU. The following is valid:  * The algorithm to be used is specified as <swAxisType> in the data dictionary ** (reservation of keyword and specification of parameters). Thus when forming an axis, the algorithm is given through the appropriate reference ( <swAxisTypeRef> ).  * The number of base points to be calculated is defined in <SW-NUMER-OF-AXIS-POINTS>. This element exists to enable the number of axis points to be stored explicitly, although it could also be described as <swGenericAxisParam> .  * The calculated base points can be stored on a physical level in the element <swValuesPhys> , which means that it is not necessary for the required calculation algorithm to be implemented in every MCD system.  * The calculated base points can be stored on a standardized level in the element <swValuesCoded> , which means that it is not necessary for the required calculation algorithm to be implemented in every MCD system.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric getSwAxisGeneric();
  /**
   * This element defines an axis for the base points calculated in the ECU. The ECU is equipped with a fixed calculation algorithm. Parameters for the algorithm can be stored in the data component of the ECU. The following is valid:  * The algorithm to be used is specified as <swAxisType> in the data dictionary ** (reservation of keyword and specification of parameters). Thus when forming an axis, the algorithm is given through the appropriate reference ( <swAxisTypeRef> ).  * The number of base points to be calculated is defined in <SW-NUMER-OF-AXIS-POINTS>. This element exists to enable the number of axis points to be stored explicitly, although it could also be described as <swGenericAxisParam> .  * The calculated base points can be stored on a physical level in the element <swValuesPhys> , which means that it is not necessary for the required calculation algorithm to be implemented in every MCD system.  * The calculated base points can be stored on a standardized level in the element <swValuesCoded> , which means that it is not necessary for the required calculation algorithm to be implemented in every MCD system.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisGeneric(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric newValue);
  // reference : compuMethod generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_METHOD = "compuMethod";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_compuMethod_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_METHOD_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_METHOD,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef.SW_AXIS_INDIVIDUAL_COMPU_METHOD_OWNER_RELATION_INFO;}};
  /**
   * This is the compuMethod which is expected for the axis. It is used in early stages if the particular input-value is not yet available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef getCompuMethod();
  /**
   * This is the compuMethod which is expected for the axis. It is used in early stages if the particular input-value is not yet available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuMethod(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef newValue);
  // reference : dataConstr generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_CONSTR = "dataConstr";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_dataConstr_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_CONSTR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_CONSTR,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef.SW_AXIS_INDIVIDUAL_DATA_CONSTR_OWNER_RELATION_INFO;}};
  /**
   * Refers to constraints, e.g. for plausibility checks.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef getDataConstr();
  /**
   * Refers to constraints, e.g. for plausibility checks.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataConstr(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef newValue);
  // reference : unit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String UNIT = "unit";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisIndividual_unit_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo UNIT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(UNIT,"ar3x.commonstructure.axis.SwAxisIndividual",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef.SW_AXIS_INDIVIDUAL_UNIT_OWNER_RELATION_INFO;}};
  /**
   * Use <unit> to enter the unit of a parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef getUnit();
  /**
   * Use <unit> to enter the unit of a parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setUnit(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef newValue);
}
