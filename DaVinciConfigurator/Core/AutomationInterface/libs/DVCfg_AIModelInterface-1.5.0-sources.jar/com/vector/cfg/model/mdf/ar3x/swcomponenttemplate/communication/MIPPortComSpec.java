package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes for P-Ports. This class will contain attributes that are valid for all kinds of provide ports, independent of client-server or sender-receiver communication patterns.
 */
public interface MIPPortComSpec extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PPortComSpec";
  // reference : pPortPrototype_providedComSpec_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String P_PORT_PROTOTYPE_PROVIDED_COM_SPEC_OWNER = "pPortPrototype_providedComSpec_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: providedComSpec
  public static final ru.novosoft.mdf.impl.MDFRelationInfo P_PORT_PROTOTYPE_PROVIDED_COM_SPEC_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(P_PORT_PROTOTYPE_PROVIDED_COM_SPEC_OWNER,"ar3x.swcomponenttemplate.communication.PPortComSpec",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype.PROVIDED_COM_SPEC_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype getPPortPrototypeProvidedComSpecOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPPortPrototypeProvidedComSpecOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype newValue);
}
