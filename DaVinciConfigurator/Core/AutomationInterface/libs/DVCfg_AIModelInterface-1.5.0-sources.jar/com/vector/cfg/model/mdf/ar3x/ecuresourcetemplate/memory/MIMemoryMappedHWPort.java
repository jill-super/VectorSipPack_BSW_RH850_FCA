package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIMemoryMappedHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "MemoryMappedHWPort";
  // attribute : dataInterfaceWidth generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_INTERFACE_WIDTH = "dataInterfaceWidth";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DATA_INTERFACE_WIDTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DATA_INTERFACE_WIDTH,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPort",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The element defines the number of bits that can be transferred from the PU to the memory device or vice versa. The width of data bus are important characteristics. All technical characteristics of the memory are covered by the access time. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDataInterfaceWidth();
  /**
   * The element defines the number of bits that can be transferred from the PU to the memory device or vice versa. The width of data bus are important characteristics. All technical characteristics of the memory are covered by the access time. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public void setDataInterfaceWidth(java.math.BigInteger newValue);
  // attribute : hwPortType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HW_PORT_TYPE = "hwPortType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo HW_PORT_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,HW_PORT_TYPE,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPort",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * the type of port
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum getHwPortType();
  /**
   * the type of port
   * Attribute-Kind = versionAttribute   */
  public void setHwPortType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMemoryMappedHwPortTypeEnum newValue);
  // reference : memoryMappedHWPortARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEMORY_MAPPED_HWPORT_ARREF_REF_TARGETS_OWNER = "memoryMappedHWPortARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_MAPPED_HWPORT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_MAPPED_HWPORT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPort",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef> getMemoryMappedHWPortARRefRefTargetsOwner();
}
