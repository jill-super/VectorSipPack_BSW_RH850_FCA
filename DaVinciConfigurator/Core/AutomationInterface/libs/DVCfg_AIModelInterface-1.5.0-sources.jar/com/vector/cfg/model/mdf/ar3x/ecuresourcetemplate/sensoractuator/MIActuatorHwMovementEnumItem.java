package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIActuatorHwMovementEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "ActuatorHwMovementEnumItem";
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHwMovementEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum newValue);
}
