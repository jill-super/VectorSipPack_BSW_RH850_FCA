package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutarref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIContentSwRecordLayoutARRef extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild
{
  public final static String CLASS_NAME = "ContentSwRecordLayoutARRef";
}
