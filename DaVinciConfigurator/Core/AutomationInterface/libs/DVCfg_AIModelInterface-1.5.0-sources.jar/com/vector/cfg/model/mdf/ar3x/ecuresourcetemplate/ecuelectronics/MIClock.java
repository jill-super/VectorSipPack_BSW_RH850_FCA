package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The clock delivers the time for the PU and other HW Elements on the ECU.
 */
public interface MIClock extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "Clock";
  // attribute : adjustable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ADJUSTABLE = "adjustable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ADJUSTABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ADJUSTABLE,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if the clock is adjustable from software.
   * Attribute-Kind = versionAttribute   */
  public Boolean getAdjustable();
  /**
   * Defines if the clock is adjustable from software.
   * Attribute-Kind = versionAttribute   */
  public void setAdjustable(Boolean newValue);
  // attribute : clockJitter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CLOCK_JITTER = "clockJitter";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CLOCK_JITTER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CLOCK_JITTER,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The short-term deviation of the nominal frequency to the real frequency. Jitter is influenced by the circuitry itself, voltage spikes etc. Jitter is critical for communication elements. PLL need/generate jitter for operation. Therefore communication interfaces should operate from an oscillator e.g. quartz directly or use only divider, not a PLL, as clock source. Using PLL for communication interfaces is a very common source for problems in ECU test and integration.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getClockJitter();
  /**
   * The short-term deviation of the nominal frequency to the real frequency. Jitter is influenced by the circuitry itself, voltage spikes etc. Jitter is critical for communication elements. PLL need/generate jitter for operation. Therefore communication interfaces should operate from an oscillator e.g. quartz directly or use only divider, not a PLL, as clock source. Using PLL for communication interfaces is a very common source for problems in ECU test and integration.
   * Attribute-Kind = versionAttribute   */
  public void setClockJitter(java.math.BigDecimal newValue);
  // attribute : clockStartupTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CLOCK_STARTUP_TIME = "clockStartupTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CLOCK_STARTUP_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CLOCK_STARTUP_TIME,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The time the clock generation needs to deliver a stable and valid signal.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getClockStartupTime();
  /**
   * The time the clock generation needs to deliver a stable and valid signal.
   * Attribute-Kind = versionAttribute   */
  public void setClockStartupTime(java.math.BigDecimal newValue);
  // attribute : clockTolerance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CLOCK_TOLERANCE = "clockTolerance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CLOCK_TOLERANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CLOCK_TOLERANCE,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The long-term deviation of the nominal frequency to the real frequency. Influenced by manufacturing, layout, temperature, external components and voltage. Tolerances are critical for timer application and time synchronisation.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getClockTolerance();
  /**
   * The long-term deviation of the nominal frequency to the real frequency. Influenced by manufacturing, layout, temperature, external components and voltage. Tolerances are critical for timer application and time synchronisation.
   * Attribute-Kind = versionAttribute   */
  public void setClockTolerance(java.math.BigDecimal newValue);
  // attribute : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPE = "type";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPE,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIClockTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the type of the clock signal.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIClockTypeEnum getType();
  /**
   * Defines the type of the clock signal.
   * Attribute-Kind = versionAttribute   */
  public void setType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIClockTypeEnum newValue);
  // reference : clockARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CLOCK_ARREF_REF_TARGETS_OWNER = "clockARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLOCK_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLOCK_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef> getClockARRefRefTargetsOwner();
  // reference : frequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String FREQUENCY = "frequency";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: clock_frequency_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo FREQUENCY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(FREQUENCY,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange.CLOCK_FREQUENCY_OWNER_RELATION_INFO;}};
  /**
   * The frequency range the clock is able to provide. This value depends on what the oscillator is delivering.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange getFrequency();
  /**
   * The frequency range the clock is able to provide. This value depends on what the oscillator is delivering.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setFrequency(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange newValue);
  // reference : oscillator generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OSCILLATOR = "oscillator";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: clock_oscillator_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OSCILLATOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OSCILLATOR,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.CLOCK_OSCILLATOR_OWNER_RELATION_INFO;}};
  /**
   * Specifies which oscillator is used to generate the clock.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef> getOscillator();
  // reference : processingUnit_puClock_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSING_UNIT_PU_CLOCK_OWNER = "processingUnit_puClock_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: puClock
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_PU_CLOCK_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_PU_CLOCK_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.Clock",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.PU_CLOCK_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitPuClockOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProcessingUnitPuClockOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
}
