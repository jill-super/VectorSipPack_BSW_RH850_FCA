package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIProcessingUnitAdressingModeEnum implements javax.jmi.reflect.RefEnum
{
  DIRECT("DIRECT"),
  INDIRECT("INDIRECT"),
  INDEXED("INDEXED");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitAdressingModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitAdressingModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
