package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIECUPrototype extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ECUPrototype";
  // reference : executionTime_ecu_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXECUTION_TIME_ECU_OWNER = "executionTime_ecu_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: ecu
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXECUTION_TIME_ECU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXECUTION_TIME_ECU_OWNER,"ar3x.commonstructure.resourceconsumption.executiontime.ECUPrototype",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.ECU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime getExecutionTimeEcuOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setExecutionTimeEcuOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime newValue);
  // reference : eCU generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String E_CU = "eCU";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: eCUPrototype_eCU_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo E_CU_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(E_CU,"ar3x.commonstructure.resourceconsumption.executiontime.ECUPrototype",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.E_CUPROTOTYPE_E_CU_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef getECU();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setECU(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef newValue);
}
