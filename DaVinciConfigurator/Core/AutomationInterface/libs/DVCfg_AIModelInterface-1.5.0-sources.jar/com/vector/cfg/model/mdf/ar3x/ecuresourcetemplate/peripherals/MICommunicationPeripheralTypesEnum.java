package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MICommunicationPeripheralTypesEnum implements javax.jmi.reflect.RefEnum
{
  COMMUNICATION_PERIPHERAL("COMMUNICATION-PERIPHERAL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "CommunicationPeripheralTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICommunicationPeripheralTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
