package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MITimeRange extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "TimeRange";
  // attribute : min generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN = "min";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN,"ar3x.ecuresourcetemplate.basicelements.TimeRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMin();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setMin(java.math.BigDecimal newValue);
  // attribute : max generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX = "max";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX,"ar3x.ecuresourcetemplate.basicelements.TimeRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMax();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setMax(java.math.BigDecimal newValue);
  // attribute : typical generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPICAL = "typical";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPICAL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPICAL,"ar3x.ecuresourcetemplate.basicelements.TimeRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTypical();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setTypical(java.math.BigDecimal newValue);
  // reference : sensorActuatorHW_cycleTime_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENSOR_ACTUATOR_HW_CYCLE_TIME_OWNER = "sensorActuatorHW_cycleTime_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: cycleTime
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENSOR_ACTUATOR_HW_CYCLE_TIME_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENSOR_ACTUATOR_HW_CYCLE_TIME_OWNER,"ar3x.ecuresourcetemplate.basicelements.TimeRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW.CYCLE_TIME_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW getSensorActuatorHWCycleTimeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSensorActuatorHWCycleTimeOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW newValue);
  // reference : memoryAccess_time_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MEMORY_ACCESS_TIME_OWNER = "memoryAccess_time_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: time
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_ACCESS_TIME_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_ACCESS_TIME_OWNER,"ar3x.ecuresourcetemplate.basicelements.TimeRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess.TIME_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess getMemoryAccessTimeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setMemoryAccessTimeOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess newValue);
}
