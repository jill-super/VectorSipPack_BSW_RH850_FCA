package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Receiver specific communication attributes (R-Port and sender-receiver interface).
 */
public interface MIReceiverComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec
{
  public final static String CLASS_NAME = "ReceiverComSpec";
  // attribute : maxDeltaCounterInit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_DELTA_COUNTER_INIT = "maxDeltaCounterInit";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_DELTA_COUNTER_INIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_DELTA_COUNTER_INIT,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Initial maximum allowed gap between two counter values of two consecutively received valid Data, i.e. how many subsequent lost data is accepted. For example, if the receiver gets Data with counter 1 and maxDeltaCounterInit is 1, then at the next reception the receiver can accept Counters with values 2 and 3, but not 4.  Note that if the receiver does not receive new Data at a consecutive read, then the receiver increments the tolerance by 1.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaxDeltaCounterInit();
  /**
   * Initial maximum allowed gap between two counter values of two consecutively received valid Data, i.e. how many subsequent lost data is accepted. For example, if the receiver gets Data with counter 1 and maxDeltaCounterInit is 1, then at the next reception the receiver can accept Counters with values 2 and 3, but not 4.  Note that if the receiver does not receive new Data at a consecutive read, then the receiver increments the tolerance by 1.
   * Attribute-Kind = versionAttribute   */
  public void setMaxDeltaCounterInit(java.math.BigInteger newValue);
  // attribute : maxNoNewOrRepeatedData generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_NO_NEW_OR_REPEATED_DATA = "maxNoNewOrRepeatedData";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_NO_NEW_OR_REPEATED_DATA_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_NO_NEW_OR_REPEATED_DATA,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum amount of missing or repeated Data which the receiver does not expect to exceed under normal communication conditions.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaxNoNewOrRepeatedData();
  /**
   * The maximum amount of missing or repeated Data which the receiver does not expect to exceed under normal communication conditions.
   * Attribute-Kind = versionAttribute   */
  public void setMaxNoNewOrRepeatedData(java.math.BigInteger newValue);
  // attribute : syncCounterInit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SYNC_COUNTER_INIT = "syncCounterInit";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SYNC_COUNTER_INIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SYNC_COUNTER_INIT,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Number of Data required for validating the consistency of the counter that must be received with a valid counter (i.e. counter within the allowed lock-in range) after the detection of an unexpected behavior of a received counter.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSyncCounterInit();
  /**
   * Number of Data required for validating the consistency of the counter that must be received with a valid counter (i.e. counter within the allowed lock-in range) after the detection of an unexpected behavior of a received counter.
   * Attribute-Kind = versionAttribute   */
  public void setSyncCounterInit(java.math.BigInteger newValue);
  // attribute : usesEndToEndProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String USES_END_TO_END_PROTECTION = "usesEndToEndProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo USES_END_TO_END_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,USES_END_TO_END_PROTECTION,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection.
   * Attribute-Kind = versionAttribute   */
  public Boolean getUsesEndToEndProtection();
  /**
   * This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection.
   * Attribute-Kind = versionAttribute   */
  public void setUsesEndToEndProtection(Boolean newValue);
  // reference : filter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String FILTER = "filter";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: receiverComSpec_filter_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo FILTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(FILTER,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter.RECEIVER_COM_SPEC_FILTER_OWNER_RELATION_INFO;}};
  /**
   * The DataFilter associated with this ReceiverComSpec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter getFilter();
  /**
   * The DataFilter associated with this ReceiverComSpec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setFilter(com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter newValue);
  // reference : dataElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_ELEMENT = "dataElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: receiverComSpec_dataElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_ELEMENT,"ar3x.swcomponenttemplate.communication.ReceiverComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.RECEIVER_COM_SPEC_DATA_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * Data element these attributes belong to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getDataElement();
  /**
   * Data element these attributes belong to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
}
