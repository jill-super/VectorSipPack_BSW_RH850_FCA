package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIInterruptProduceHWPortTypesEnum implements javax.jmi.reflect.RefEnum
{
  INTERRUPT_PRODUCE_HW_PORT("INTERRUPT-PRODUCE-HW-PORT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "InterruptProduceHWPortTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIInterruptProduceHWPortTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
