package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasDataFilter extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasDataFilter";
  // reference : dataFilter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_FILTER = "dataFilter";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasDataFilter_dataFilter_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_FILTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_FILTER,"ar3x.commonstructure.filter.HasDataFilter",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter.HAS_DATA_FILTER_DATA_FILTER_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter getDataFilter();
  public void setDataFilter(com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter newValue);
}
