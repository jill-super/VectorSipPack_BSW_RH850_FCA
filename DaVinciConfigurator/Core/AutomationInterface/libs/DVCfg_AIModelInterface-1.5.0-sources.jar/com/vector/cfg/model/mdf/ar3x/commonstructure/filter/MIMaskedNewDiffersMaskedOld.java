package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pass messages where the masked value has changed.  (new_value&mask) !=(old_value&mask) new_value: current value of the message old_value: last value of the message (initialised with the initial value of the message, updated with new_value if the new message value is not filtered out)  
 */
public interface MIMaskedNewDiffersMaskedOld extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "MaskedNewDiffersMaskedOld";
  // attribute : mask generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MASK = "mask";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MASK_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MASK,"ar3x.commonstructure.filter.MaskedNewDiffersMaskedOld",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * mask for old and new value
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMask();
  /**
   * mask for old and new value
   * Attribute-Kind = versionAttribute   */
  public void setMask(java.math.BigInteger newValue);
}
