package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIDelegationConnectorPrototypeInnerPort extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "DelegationConnectorPrototypeInnerPort";
  // reference : delegationConnectorPrototype_innerPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_OWNER = "delegationConnectorPrototype_innerPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: innerPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_OWNER,"ar3x.swcomponenttemplate.composition.instanceref.DelegationConnectorPrototypeInnerPort",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype.INNER_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype getDelegationConnectorPrototypeInnerPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDelegationConnectorPrototypeInnerPortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype newValue);
  // reference : portPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE = "portPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationConnectorPrototypeInnerPort_portPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.DelegationConnectorPrototypeInnerPort",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef getPortPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef newValue);
  // reference : componentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_PROTOTYPE = "componentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationConnectorPrototypeInnerPort_componentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.DelegationConnectorPrototypeInnerPort",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef getComponentPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef newValue);
}
