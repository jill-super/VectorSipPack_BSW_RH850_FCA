package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This BaseType is defined directly (as opposite to a derived BaseType)
 */
public interface MIBaseTypeDirectDefinition extends com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition
{
  public final static String CLASS_NAME = "BaseTypeDirectDefinition";
  // attribute : baseTypeEncoding generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BASE_TYPE_ENCODING = "baseTypeEncoding";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BASE_TYPE_ENCODING_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BASE_TYPE_ENCODING,"ar3x.commonstructure.basetypes.BaseTypeDirectDefinition",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This specifies, how an object of the current BaseType is encode eg. in an ECU in a message sequence.
   * Attribute-Kind = versionAttribute   */
  public String getBaseTypeEncoding();
  /**
   * This specifies, how an object of the current BaseType is encode eg. in an ECU in a message sequence.
   * Attribute-Kind = versionAttribute   */
  public void setBaseTypeEncoding(String newValue);
  // attribute : memAlignment generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEM_ALIGNMENT = "memAlignment";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MEM_ALIGNMENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MEM_ALIGNMENT,"ar3x.commonstructure.basetypes.BaseTypeDirectDefinition",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute describes the alignment of the memory object in bits. E.g. "8" specifies, that the object in question is aligned to a byte while "32" specifies that it is aligned four byte.  If the value is set to "0" the meaning shall be interpreted as "unspecified".
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMemAlignment();
  /**
   * This attribute describes the alignment of the memory object in bits. E.g. "8" specifies, that the object in question is aligned to a byte while "32" specifies that it is aligned four byte.  If the value is set to "0" the meaning shall be interpreted as "unspecified".
   * Attribute-Kind = versionAttribute   */
  public void setMemAlignment(java.math.BigInteger newValue);
  // reference : byteOrder generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BYTE_ORDER = "byteOrder";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: baseTypeDirectDefinition_byteOrder_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BYTE_ORDER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BYTE_ORDER,"ar3x.commonstructure.basetypes.BaseTypeDirectDefinition",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.byteorder.MIByteOrder.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.byteorder.MIByteOrder.BASE_TYPE_DIRECT_DEFINITION_BYTE_ORDER_OWNER_RELATION_INFO;}};
  /**
   * This element specifies the byte order of the parent element. The byte order is defined with the attribute TYPE. Possible values are:  * MOST-SIGNIFICANT-BYTE-FIRST  * MOST-SIGNIFICANT-BYTE-LAST
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.byteorder.MIByteOrder getByteOrder();
  /**
   * This element specifies the byte order of the parent element. The byte order is defined with the attribute TYPE. Possible values are:  * MOST-SIGNIFICANT-BYTE-FIRST  * MOST-SIGNIFICANT-BYTE-LAST
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setByteOrder(com.vector.cfg.model.mdf.ar3x.commonstructure.byteorder.MIByteOrder newValue);
  // reference : baseTypeSizeDefintionType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_SIZE_DEFINTION_TYPE = "baseTypeSizeDefintionType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: baseTypeDirectDefinition_baseTypeSizeDefintionType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_SIZE_DEFINTION_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_SIZE_DEFINTION_TYPE,"ar3x.commonstructure.basetypes.BaseTypeDirectDefinition",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition.BASE_TYPE_DIRECT_DEFINITION_BASE_TYPE_SIZE_DEFINTION_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This aggregation is necessary to specify the exact sequence of properties in the xml-file. It represents the size of the BaseType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition getBaseTypeSizeDefintionType();
  /**
   * This aggregation is necessary to specify the exact sequence of properties in the xml-file. It represents the size of the BaseType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeSizeDefintionType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition newValue);
}
