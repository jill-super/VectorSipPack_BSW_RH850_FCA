package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * List of possible communication speed.
 */
public interface MICommunicationSpeedList extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed
{
  public final static String CLASS_NAME = "CommunicationSpeedList";
  // reference : speed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SPEED = "speed";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationSpeedList_speed_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SPEED_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SPEED,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeedList",133,null,com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem.COMMUNICATION_SPEED_LIST_SPEED_OWNER_RELATION_INFO;}};
  /**
   * Unit: bits per second
   */
  public java.util.List<com.vector.cfg.model.mdf.commoncore.basetypes.MIIntegerItem> getSpeed();
}
