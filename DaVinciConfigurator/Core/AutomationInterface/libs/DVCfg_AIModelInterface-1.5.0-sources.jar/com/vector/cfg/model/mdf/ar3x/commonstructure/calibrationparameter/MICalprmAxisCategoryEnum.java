package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;
import javax.jmi.model.*;

public enum MICalprmAxisCategoryEnum implements javax.jmi.reflect.RefEnum
{
  STD_AXIS("STD-AXIS"),
  FIX_AXIS("FIX-AXIS"),
  CURVE_AXIS("CURVE-AXIS"),
  COM_AXIS("COM-AXIS"),
  RES_AXIS("RES-AXIS");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "calibrationparameter" );
    temp.add( "CalprmAxisCategoryEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICalprmAxisCategoryEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
