package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIInternalConstrs extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.localconstraints.MIHasUpperLimitLimit, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.localconstraints.MIHasLowerLimitLimit, com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr
{
  public final static String CLASS_NAME = "InternalConstrs";
  // attribute : maxDiff generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_DIFF = "maxDiff";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_DIFF_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_DIFF,"ar3x.commonstructure.globalconstraints.InternalConstrs",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public String getMaxDiff();
  /**
   * Maximum difference that is permitted between two consecutive values if the constraint is applied to an axis.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public void setMaxDiff(String newValue);
  // attribute : maxGradient generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_GRADIENT = "maxGradient";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_GRADIENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_GRADIENT,"ar3x.commonstructure.globalconstraints.InternalConstrs",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies the maximum slope that may be used in maps and curves.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public String getMaxGradient();
  /**
   * This element specifies the maximum slope that may be used in maps and curves.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public void setMaxGradient(String newValue);
  // attribute : monotony generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MONOTONY = "monotony";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MONOTONY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MONOTONY,"ar3x.commonstructure.globalconstraints.InternalConstrs",null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies the monotony characteristics of the current internal or physical limits. The following table shows the monotony characteristics which are to be filled through the corresponding values. If the element has no contents or if it is omitted, "no-monotony" is the default content. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum getMonotony();
  /**
   * This element specifies the monotony characteristics of the current internal or physical limits. The following table shows the monotony characteristics which are to be filled through the corresponding values. If the element has no contents or if it is omitted, "no-monotony" is the default content. 
   * Attribute-Kind = versionAttribute   */
  public void setMonotony(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum newValue);
  // reference : dataConstrRule_internalConstrs_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_CONSTR_RULE_INTERNAL_CONSTRS_OWNER = "dataConstrRule_internalConstrs_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: internalConstrs
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_CONSTR_RULE_INTERNAL_CONSTRS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_CONSTR_RULE_INTERNAL_CONSTRS_OWNER,"ar3x.commonstructure.globalconstraints.InternalConstrs",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrRule.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrRule.INTERNAL_CONSTRS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrRule getDataConstrRuleInternalConstrsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataConstrRuleInternalConstrsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrRule newValue);
}
