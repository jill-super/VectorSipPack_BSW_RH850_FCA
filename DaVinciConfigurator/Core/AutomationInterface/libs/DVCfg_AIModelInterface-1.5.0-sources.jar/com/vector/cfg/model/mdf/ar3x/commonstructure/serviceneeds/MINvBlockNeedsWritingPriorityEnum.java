package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

public enum MINvBlockNeedsWritingPriorityEnum implements javax.jmi.reflect.RefEnum
{
  LOW("LOW"),
  MEDIUM("MEDIUM"),
  HIGH("HIGH");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "NvBlockNeedsWritingPriorityEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MINvBlockNeedsWritingPriorityEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
