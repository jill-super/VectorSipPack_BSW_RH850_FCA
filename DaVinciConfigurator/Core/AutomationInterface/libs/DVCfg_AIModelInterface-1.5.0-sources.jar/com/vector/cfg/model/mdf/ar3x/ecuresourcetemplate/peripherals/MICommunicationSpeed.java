package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Abstract element to describe communication speed. This can be either a fixed value, a range or a list of allowed communication speed.
 */
public interface MICommunicationSpeed extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "CommunicationSpeed";
  // attribute : tolerance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TOLERANCE = "tolerance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TOLERANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TOLERANCE,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeed",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The element defines the tolerance allowed for the interface. (E.g. K-Line or LIN +/- 2 % at 9.6 Kbd)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTolerance();
  /**
   * The element defines the tolerance allowed for the interface. (E.g. K-Line or LIN +/- 2 % at 9.6 Kbd)
   * Attribute-Kind = versionAttribute   */
  public void setTolerance(java.math.BigDecimal newValue);
  // reference : communicationHWPort_speed_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_HWPORT_SPEED_OWNER = "communicationHWPort_speed_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: speed
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_HWPORT_SPEED_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_HWPORT_SPEED_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeed",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.SPEED_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort getCommunicationHWPortSpeedOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationHWPortSpeedOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort newValue);
}
