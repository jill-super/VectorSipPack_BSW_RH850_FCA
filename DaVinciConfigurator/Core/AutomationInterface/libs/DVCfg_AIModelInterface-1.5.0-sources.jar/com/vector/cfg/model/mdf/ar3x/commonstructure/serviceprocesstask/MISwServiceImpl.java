package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * tbd
 */
public interface MISwServiceImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwServiceImpl";
}
