package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * An AssemblyHWConnection is established between at least two HWPorts provided by different HWElements.  The AssemblyHWConnection can only be established between HWPorts on the same hierarchical level. To connect accross hierarchical levels use the DelegationHWConnection.
 */
public interface MIAssemblyHWConnection extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection
{
  public final static String CLASS_NAME = "AssemblyHWConnection";
  // reference : hwPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HW_PORT = "hwPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyHWConnection_hwPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HW_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HW_PORT,"ar3x.ecuresourcetemplate.AssemblyHWConnection",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.ASSEMBLY_HWCONNECTION_HW_PORT_OWNER_RELATION_INFO;}};
  /**
   * References to HWPorts connected by this AssemblyHWConnection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef> getHwPort();
}
