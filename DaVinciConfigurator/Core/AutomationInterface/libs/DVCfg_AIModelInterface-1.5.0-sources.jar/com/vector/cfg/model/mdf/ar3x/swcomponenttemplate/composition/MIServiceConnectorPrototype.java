package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A ServiceConnectorPrototype connects a PortPrototype owned by an ComponentPrototype with the service PortPrototype owned by the ServiceComponentPrototype. A ServiceConnectorPrototype is only added to the model in ECU Configuration phase for the specific purpose of configuring services within an EcuSwComposition.
 */
public interface MIServiceConnectorPrototype extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype
{
  public final static String CLASS_NAME = "ServiceConnectorPrototype";
  // reference : applicationPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String APPLICATION_PORT = "applicationPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototype_applicationPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo APPLICATION_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(APPLICATION_PORT,"ar3x.swcomponenttemplate.composition.ServiceConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_OWNER_RELATION_INFO;}};
  /**
   * Service port to be connected on application component side
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort getApplicationPort();
  /**
   * Service port to be connected on application component side
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setApplicationPort(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort newValue);
  // reference : servicePort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_PORT = "servicePort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototype_servicePort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_PORT,"ar3x.swcomponenttemplate.composition.ServiceConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort.SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_OWNER_RELATION_INFO;}};
  /**
   * Service port to be connected on service component side
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort getServicePort();
  /**
   * Service port to be connected on service component side
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServicePort(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort newValue);
  // reference : ecuSwComposition_ecuSwCompositionConnector_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_SW_COMPOSITION_ECU_SW_COMPOSITION_CONNECTOR_OWNER = "ecuSwComposition_ecuSwCompositionConnector_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: ecuSwCompositionConnector
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_SW_COMPOSITION_ECU_SW_COMPOSITION_CONNECTOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_SW_COMPOSITION_ECU_SW_COMPOSITION_CONNECTOR_OWNER,"ar3x.swcomponenttemplate.composition.ServiceConnectorPrototype",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIEcuSwComposition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIEcuSwComposition.ECU_SW_COMPOSITION_CONNECTOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIEcuSwComposition getEcuSwCompositionEcuSwCompositionConnectorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuSwCompositionEcuSwCompositionConnectorOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIEcuSwComposition newValue);
}
