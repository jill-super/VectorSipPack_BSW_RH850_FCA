package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIRemarkChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "RemarkChild";
  // reference : remark_remarkChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REMARK_REMARK_CHILDREN_OWNER = "remark_remarkChildren_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: remarkChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REMARK_REMARK_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REMARK_REMARK_CHILDREN_OWNER,"ar3x.genericstructure.commonpatterns.annotation.RemarkChild",74,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark.REMARK_CHILDREN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark getRemarkRemarkChildrenOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRemarkRemarkChildrenOwner(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark newValue);
}
