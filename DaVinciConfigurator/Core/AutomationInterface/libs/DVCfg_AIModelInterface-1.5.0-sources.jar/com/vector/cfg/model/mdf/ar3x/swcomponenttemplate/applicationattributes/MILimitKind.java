package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;
import javax.jmi.model.*;

public enum MILimitKind implements javax.jmi.reflect.RefEnum
{
  NONE("NONE"),
  MIN("MIN"),
  MAX("MAX");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "applicationattributes" );
    temp.add( "LimitKind" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MILimitKind(String literalName)
  {
    this.literalName = literalName;
  }
}
