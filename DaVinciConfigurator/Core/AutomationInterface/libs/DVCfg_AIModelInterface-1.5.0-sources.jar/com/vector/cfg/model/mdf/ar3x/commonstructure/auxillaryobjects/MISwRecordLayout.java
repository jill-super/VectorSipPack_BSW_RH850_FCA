package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Defines how the data objects (variables, calibration parameters etc.) are to be stored in the ECU memory. As an example, this definition specifies the sequence of axis points in the ECU memory. Iterations through axis values are stored within the subelements swRecordLayoutGroup . These subelements might be stored nested to support multidimensional data objects.
 */
public interface MISwRecordLayout extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "SwRecordLayout";
  // reference : swRecordLayoutARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_ARREF_REF_TARGETS_OWNER = "swRecordLayoutARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.auxillaryobjects.SwRecordLayout",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef> getSwRecordLayoutARRefRefTargetsOwner();
  // reference : swRecordLayoutGroup generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_GROUP = "swRecordLayoutGroup";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swRecordLayout_swRecordLayoutGroup_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_GROUP_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_GROUP,"ar3x.commonstructure.auxillaryobjects.SwRecordLayout",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup.SW_RECORD_LAYOUT_SW_RECORD_LAYOUT_GROUP_OWNER_RELATION_INFO;}};
  /**
   * Set up for the record layout of axis values.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup> getSwRecordLayoutGroup();
}
