package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A BSW event, which can happen sporadically. The event is activated/cancelled by explicit calls from the module to the BSW Scheduler. There a two purposes for such an event: - cause a context switch, e.g. from an ISR context into a task context - implement a time delay
 */
public interface MIBswSporadicEvent extends com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent
{
  public final static String CLASS_NAME = "BswSporadicEvent";
  // attribute : delayTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DELAY_TIME = "delayTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DELAY_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DELAY_TIME,"ar3x.bswmoduletemplate.bswbehavior.BswSporadicEvent",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Requirement for the delay time (in seconds) after which this event is triggered. The delay is counted from the activation of this event by a BswModuleEntitiy until the actual triggering of another BswModuleEntity associated by the event. 
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getDelayTime();
  /**
   * Requirement for the delay time (in seconds) after which this event is triggered. The delay is counted from the activation of this event by a BswModuleEntitiy until the actual triggering of another BswModuleEntity associated by the event. 
   * Attribute-Kind = versionAttribute   */
  public void setDelayTime(java.math.BigDecimal newValue);
  // reference : bswSporadicEventARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_SPORADIC_EVENT_ARREF_REF_TARGETS_OWNER = "bswSporadicEventARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_SPORADIC_EVENT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_SPORADIC_EVENT_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswSporadicEvent",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef> getBswSporadicEventARRefRefTargetsOwner();
}
