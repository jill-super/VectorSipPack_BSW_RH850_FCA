package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIProcessingUnitARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ProcessingUnitARRef";
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnitARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: processingUnitARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnitARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.PROCESSING_UNIT_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit> getRefTargets();
  // reference : implementation_processor_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_PROCESSOR_OWNER = "implementation_processor_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: processor
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_PROCESSOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_PROCESSOR_OWNER,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnitARRef",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.PROCESSOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationProcessorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationProcessorOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newRefTarget);

}
