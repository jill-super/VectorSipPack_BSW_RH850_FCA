package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Base class for data filters.
 */
public interface MIDataFilter extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "DataFilter";
  // reference : receiverComSpec_filter_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RECEIVER_COM_SPEC_FILTER_OWNER = "receiverComSpec_filter_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: filter
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RECEIVER_COM_SPEC_FILTER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RECEIVER_COM_SPEC_FILTER_OWNER,"ar3x.commonstructure.filter.DataFilter",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec.FILTER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec getReceiverComSpecFilterOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setReceiverComSpecFilterOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec newValue);
  // reference : hasDataFilter_dataFilter_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_DATA_FILTER_DATA_FILTER_OWNER = "hasDataFilter_dataFilter_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: dataFilter
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_DATA_FILTER_DATA_FILTER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_DATA_FILTER_DATA_FILTER_OWNER,"ar3x.commonstructure.filter.DataFilter",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIHasDataFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIHasDataFilter.DATA_FILTER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIHasDataFilter getHasDataFilterDataFilterOwner();
  public void setHasDataFilterDataFilterOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIHasDataFilter newValue);
}
