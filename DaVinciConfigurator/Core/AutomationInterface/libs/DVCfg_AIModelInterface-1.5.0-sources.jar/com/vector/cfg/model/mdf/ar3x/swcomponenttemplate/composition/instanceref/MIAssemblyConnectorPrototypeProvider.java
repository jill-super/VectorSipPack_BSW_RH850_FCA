package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIAssemblyConnectorPrototypeProvider extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "AssemblyConnectorPrototypeProvider";
  // reference : assemblyConnectorPrototype_provider_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_OWNER = "assemblyConnectorPrototype_provider_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: provider
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_OWNER,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeProvider",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype.PROVIDER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype getAssemblyConnectorPrototypeProviderOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeProviderOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype newValue);
  // reference : providerPPortPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDER_PPORT_PROTOTYPE = "providerPPortPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototypeProvider_providerPPortPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDER_PPORT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDER_PPORT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeProvider",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef.ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_PROVIDER_PPORT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef getProviderPPortPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProviderPPortPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef newValue);
  // reference : componentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_PROTOTYPE = "componentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototypeProvider_componentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeProvider",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef getComponentPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef newValue);
}
