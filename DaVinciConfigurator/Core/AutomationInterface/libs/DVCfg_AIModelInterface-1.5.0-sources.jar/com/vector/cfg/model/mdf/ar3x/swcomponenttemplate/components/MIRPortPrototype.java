package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Component port requiring a certain port interface.
 */
public interface MIRPortPrototype extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype
{
  public final static String CLASS_NAME = "RPortPrototype";
  // reference : rPortPrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String R_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "rPortPrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo R_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(R_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototype",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef> getRPortPrototypeARRefRefTargetsOwner();
  // reference : requiredComSpec generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUIRED_COM_SPEC = "requiredComSpec";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: rPortPrototype_requiredComSpec_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUIRED_COM_SPEC_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUIRED_COM_SPEC,"ar3x.swcomponenttemplate.components.RPortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec.R_PORT_PROTOTYPE_REQUIRED_COM_SPEC_OWNER_RELATION_INFO;}};
  /**
   * Required communication attributes, one for each interface element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec> getRequiredComSpec();
  // reference : requiredInterface generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUIRED_INTERFACE = "requiredInterface";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: rPortPrototype_requiredInterface_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUIRED_INTERFACE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUIRED_INTERFACE,"ar3x.swcomponenttemplate.components.RPortPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef.R_PORT_PROTOTYPE_REQUIRED_INTERFACE_OWNER_RELATION_INFO;}};
  /**
   * The interface that this port requires, i.e. the port depends on another port providing the specified interface.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef getRequiredInterface();
  /**
   * The interface that this port requires, i.e. the port depends on another port providing the specified interface.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRequiredInterface(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef newValue);
}
