package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the ExecutionTime which has been gathered using simulation means.
 */
public interface MISimulatedExecutionTime extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime
{
  public final static String CLASS_NAME = "SimulatedExecutionTime";
  // attribute : averageExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AVERAGE_EXECUTION_TIME = "averageExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AVERAGE_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AVERAGE_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.SimulatedExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Average SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getAverageExecutionTime();
  /**
   * Average SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setAverageExecutionTime(java.math.BigDecimal newValue);
  // attribute : maximalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAXIMAL_EXECUTION_TIME = "maximalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAXIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAXIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.SimulatedExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaximalExecutionTime();
  /**
   * Maximum SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMaximalExecutionTime(java.math.BigDecimal newValue);
  // attribute : minimalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MINIMAL_EXECUTION_TIME = "minimalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MINIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MINIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.SimulatedExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinimalExecutionTime();
  /**
   * Minimum SimulatedExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMinimalExecutionTime(java.math.BigDecimal newValue);
}
