package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * General dependency, typically on the existence of another artifact.
 */
public interface MIDependency extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "Dependency";
  // reference : implementation_implementationDependency_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_IMPLEMENTATION_DEPENDENCY_OWNER = "implementation_implementationDependency_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: implementationDependency
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_IMPLEMENTATION_DEPENDENCY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_IMPLEMENTATION_DEPENDENCY_OWNER,"ar3x.commonstructure.implementation.Dependency",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.IMPLEMENTATION_DEPENDENCY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationImplementationDependencyOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationImplementationDependencyOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);
  // reference : usage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String USAGE = "usage";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: dependency_usage_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo USAGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(USAGE,"ar3x.commonstructure.implementation.Dependency",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnumItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnumItem.DEPENDENCY_USAGE_OWNER_RELATION_INFO;}};
  /**
   * Specification during for which process step(s) this dependency is required.
   */
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnumItem> getUsage();
}
