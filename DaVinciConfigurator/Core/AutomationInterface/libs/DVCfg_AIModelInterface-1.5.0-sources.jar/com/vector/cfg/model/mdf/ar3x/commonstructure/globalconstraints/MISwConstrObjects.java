package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Parameters or variables can reference plausibility checks. The assignment of data to <swConstrObjects> makes the reverse direction possible.  In this way for example plausibility libraries stored in external files can be latched beneath the previous element <SW-DATA-CONSTRS> -element.
 */
public interface MISwConstrObjects extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwConstrObjects";
}
