package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pass messages whose masked value is equal to a specific value x  (new_value&mask) == x new_value: current value of the message
 */
public interface MIMaskedNewEqualsX extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "MaskedNewEqualsX";
  // attribute : x generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String X = "x";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo X_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,X,"ar3x.commonstructure.filter.MaskedNewEqualsX",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Value to compare with
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getX();
  /**
   * Value to compare with
   * Attribute-Kind = versionAttribute   */
  public void setX(java.math.BigInteger newValue);
  // attribute : mask generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MASK = "mask";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MASK_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MASK,"ar3x.commonstructure.filter.MaskedNewEqualsX",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * mask for the new Value
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMask();
  /**
   * mask for the new Value
   * Attribute-Kind = versionAttribute   */
  public void setMask(java.math.BigInteger newValue);
}
