package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This BaseType is defined by referring to anotherone. This indirect definition allows to create alias base types.
 */
public interface MIBaseTypeIndirectDefinition extends com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition
{
  public final static String CLASS_NAME = "BaseTypeIndirectDefinition";
  // reference : baseType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE = "baseType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: baseTypeIndirectDefinition_baseType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE,"ar3x.commonstructure.basetypes.BaseTypeIndirectDefinition",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.BASE_TYPE_INDIRECT_DEFINITION_BASE_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This is the baseType on which the indirectly defined base type is derived. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef getBaseType();
  /**
   * This is the baseType on which the indirectly defined base type is derived. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef newValue);
}
