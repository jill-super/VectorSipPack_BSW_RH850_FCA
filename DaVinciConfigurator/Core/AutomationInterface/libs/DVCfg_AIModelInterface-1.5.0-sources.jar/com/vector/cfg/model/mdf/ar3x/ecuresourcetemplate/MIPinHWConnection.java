package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Is used to connect the HWPins of the HWPorts that are referenced by the HWConnection.
 */
public interface MIPinHWConnection extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PinHWConnection";
  // reference : hWConnection_connectedPin_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WCONNECTION_CONNECTED_PIN_OWNER = "hWConnection_connectedPin_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: connectedPin
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WCONNECTION_CONNECTED_PIN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WCONNECTION_CONNECTED_PIN_OWNER,"ar3x.ecuresourcetemplate.PinHWConnection",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection.CONNECTED_PIN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection getHWConnectionConnectedPinOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWConnectionConnectedPinOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection newValue);
  // reference : connectedPin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CONNECTED_PIN = "connectedPin";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_TARGET_HAS_UPPER_BOUND; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: pinHWConnection_connectedPin_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CONNECTED_PIN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CONNECTED_PIN,"ar3x.ecuresourcetemplate.PinHWConnection",2097285,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef.PIN_HWCONNECTION_CONNECTED_PIN_OWNER_RELATION_INFO;}};
  /**
   * Reference to the connected pin. When the PinHWConnection is used in the context of a DelegationHWConnection there might be only ONE pin known (typically this is a pin of the OUTER-PORT), so only one pin has to be specified.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPinARRef> getConnectedPin();
}
