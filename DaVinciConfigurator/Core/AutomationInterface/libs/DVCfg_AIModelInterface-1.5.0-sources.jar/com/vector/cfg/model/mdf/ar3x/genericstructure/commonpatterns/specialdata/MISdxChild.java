package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISdxChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SdxChild";
  // reference : sdx_sdxChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SDX_SDX_CHILDREN_OWNER = "sdx_sdxChildren_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: sdxChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SDX_SDX_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SDX_SDX_CHILDREN_OWNER,"ar3x.genericstructure.commonpatterns.specialdata.SdxChild",74,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx.SDX_CHILDREN_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx getSdxSdxChildrenOwner();
  public void setSdxSdxChildrenOwner(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx newValue);
}
