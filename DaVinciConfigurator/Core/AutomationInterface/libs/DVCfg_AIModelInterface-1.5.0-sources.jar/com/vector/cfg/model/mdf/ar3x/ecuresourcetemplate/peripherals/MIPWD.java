package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pulse Width Demodulation is the inverse method of PWM. Here the processing unit is trying to gather information about a signal. A PWD can detect rising and falling edges and call the software in order to calculate the pulse width. When a PWD have more than one input signal the frequency and phase between the signals can be obtained.
 */
public interface MIPWD extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPulseWidthPeripheral
{
  public final static String CLASS_NAME = "PWD";
  // attribute : mode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODE = "mode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODE,"ar3x.ecuresourcetemplate.peripherals.PWD",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPwdModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A Pulse Width Demodulation peripheral can be configured to decode a two phase or a three phase input signals.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPwdModeEnum getMode();
  /**
   * A Pulse Width Demodulation peripheral can be configured to decode a two phase or a three phase input signals.
   * Attribute-Kind = versionAttribute   */
  public void setMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPwdModeEnum newValue);
  // attribute : phaseDetection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PHASE_DETECTION = "phaseDetection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PHASE_DETECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PHASE_DETECTION,"ar3x.ecuresourcetemplate.peripherals.PWD",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Some timers have the possibility to detect signals from a quadrature rotating switch. There are two outputs signal from such a switch; the signals are 90 degrees phase shifted from each other. The rotation of the switch can then automatically be detected by a special function in a timer.
   * Attribute-Kind = versionAttribute   */
  public Boolean getPhaseDetection();
  /**
   * Some timers have the possibility to detect signals from a quadrature rotating switch. There are two outputs signal from such a switch; the signals are 90 degrees phase shifted from each other. The rotation of the switch can then automatically be detected by a special function in a timer.
   * Attribute-Kind = versionAttribute   */
  public void setPhaseDetection(Boolean newValue);
}
