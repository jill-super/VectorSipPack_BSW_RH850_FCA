package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIProcessingUnitArchitectureTypeEnum implements javax.jmi.reflect.RefEnum
{
  RISC("RISC"),
  CISC("CISC"),
  SIMD("SIMD"),
  MIND("MIND");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitArchitectureTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitArchitectureTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
