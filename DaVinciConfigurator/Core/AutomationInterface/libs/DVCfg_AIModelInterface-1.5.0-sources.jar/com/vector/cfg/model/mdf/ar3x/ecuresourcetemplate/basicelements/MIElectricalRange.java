package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies electrical ranges for different applications within the ECU Resource Template.
 */
public interface MIElectricalRange extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ElectricalRange";
  // attribute : minVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_VOLTAGE = "minVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_VOLTAGE,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinVoltage();
  /**
   * Minimum voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public void setMinVoltage(java.math.BigDecimal newValue);
  // attribute : maxVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_VOLTAGE = "maxVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_VOLTAGE,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaxVoltage();
  /**
   * Maximum voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public void setMaxVoltage(java.math.BigDecimal newValue);
  // attribute : typicalVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPICAL_VOLTAGE = "typicalVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPICAL_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPICAL_VOLTAGE,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Typical voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTypicalVoltage();
  /**
   * Typical voltage Unit: V
   * Attribute-Kind = versionAttribute   */
  public void setTypicalVoltage(java.math.BigDecimal newValue);
  // attribute : minCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_CURRENT = "minCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_CURRENT,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinCurrent();
  /**
   * Minimum Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public void setMinCurrent(java.math.BigDecimal newValue);
  // attribute : maxCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_CURRENT = "maxCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_CURRENT,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaxCurrent();
  /**
   * Maximum Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public void setMaxCurrent(java.math.BigDecimal newValue);
  // attribute : typicalCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPICAL_CURRENT = "typicalCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPICAL_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPICAL_CURRENT,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Typical Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTypicalCurrent();
  /**
   * Typical Current Unit: A
   * Attribute-Kind = versionAttribute   */
  public void setTypicalCurrent(java.math.BigDecimal newValue);
  // reference : analogueIO_externalReferenceVoltage_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ANALOGUE_IO_EXTERNAL_REFERENCE_VOLTAGE_OWNER = "analogueIO_externalReferenceVoltage_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: externalReferenceVoltage
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ANALOGUE_IO_EXTERNAL_REFERENCE_VOLTAGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ANALOGUE_IO_EXTERNAL_REFERENCE_VOLTAGE_OWNER,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO.EXTERNAL_REFERENCE_VOLTAGE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO getAnalogueIOExternalReferenceVoltageOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAnalogueIOExternalReferenceVoltageOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO newValue);
  // reference : powerSupplyHWPort_supplied_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String POWER_SUPPLY_HWPORT_SUPPLIED_OWNER = "powerSupplyHWPort_supplied_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: supplied
  public static final ru.novosoft.mdf.impl.MDFRelationInfo POWER_SUPPLY_HWPORT_SUPPLIED_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(POWER_SUPPLY_HWPORT_SUPPLIED_OWNER,"ar3x.ecuresourcetemplate.basicelements.ElectricalRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWPort.SUPPLIED_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWPort getPowerSupplyHWPortSuppliedOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPowerSupplyHWPortSuppliedOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWPort newValue);
}
