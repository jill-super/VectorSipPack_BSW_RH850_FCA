package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;
import javax.jmi.model.*;

public enum MISwServiceImplPolicyEnum implements javax.jmi.reflect.RefEnum
{
  STANDARD("STANDARD"),
  INLINE("INLINE"),
  MACRO("MACRO"),
  INLINE_CONDITIONAL("INLINE-CONDITIONAL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceprocesstask" );
    temp.add( "SwServiceImplPolicyEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwServiceImplPolicyEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
