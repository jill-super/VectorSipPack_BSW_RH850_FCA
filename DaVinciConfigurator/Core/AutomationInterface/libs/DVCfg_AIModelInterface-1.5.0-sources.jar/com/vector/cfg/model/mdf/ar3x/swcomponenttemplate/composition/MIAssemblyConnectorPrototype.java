package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * AssemblyConnectorPrototypes are exclusively used to connect ComponentPrototypes in the context of a CompositionType.
 */
public interface MIAssemblyConnectorPrototype extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype
{
  public final static String CLASS_NAME = "AssemblyConnectorPrototype";
  // reference : provider generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDER = "provider";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototype_provider_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDER,"ar3x.swcomponenttemplate.composition.AssemblyConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_OWNER_RELATION_INFO;}};
  /**
   * Instance of providing port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider getProvider();
  /**
   * Instance of providing port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProvider(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider newValue);
  // reference : requester generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUESTER = "requester";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototype_requester_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUESTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUESTER,"ar3x.swcomponenttemplate.composition.AssemblyConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_OWNER_RELATION_INFO;}};
  /**
   * Instance of requiring port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester getRequester();
  /**
   * Instance of requiring port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRequester(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester newValue);
}
