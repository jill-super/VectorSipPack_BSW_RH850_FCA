package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The SensorActuatorSoftwareComponentType introduces the possibility to link from the software representation of a sensor/actuator to its hardware description provided by the ECU Resource Template. 
 */
public interface MISensorActuatorSoftwareComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "SensorActuatorSoftwareComponentType";
  // reference : sensorActuator generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENSOR_ACTUATOR = "sensorActuator";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: sensorActuatorSoftwareComponentType_sensorActuator_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENSOR_ACTUATOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENSOR_ACTUATOR,"ar3x.swcomponenttemplate.components.SensorActuatorSoftwareComponentType",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef.SENSOR_ACTUATOR_SOFTWARE_COMPONENT_TYPE_SENSOR_ACTUATOR_OWNER_RELATION_INFO;}};
  /**
   * Reference from the Sensor Actuator Software Component Type to the description of the actual hardware.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef getSensorActuator();
  /**
   * Reference from the Sensor Actuator Software Component Type to the description of the actual hardware.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSensorActuator(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef newValue);
}
