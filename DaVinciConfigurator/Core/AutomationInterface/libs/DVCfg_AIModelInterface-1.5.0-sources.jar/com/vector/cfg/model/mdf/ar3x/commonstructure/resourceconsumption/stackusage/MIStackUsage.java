package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes the stack memory usage of a software.
 */
public interface MIStackUsage extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext
{
  public final static String CLASS_NAME = "StackUsage";
  // reference : resourceConsumption_stackUsage_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RESOURCE_CONSUMPTION_STACK_USAGE_OWNER = "resourceConsumption_stackUsage_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: stackUsage
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RESOURCE_CONSUMPTION_STACK_USAGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RESOURCE_CONSUMPTION_STACK_USAGE_OWNER,"ar3x.commonstructure.resourceconsumption.stackusage.StackUsage",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.STACK_USAGE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption getResourceConsumptionStackUsageOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setResourceConsumptionStackUsageOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption newValue);
  // reference : runnable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RUNNABLE = "runnable";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: stackUsage_runnable_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RUNNABLE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RUNNABLE,"ar3x.commonstructure.resourceconsumption.stackusage.StackUsage",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.STACK_USAGE_RUNNABLE_OWNER_RELATION_INFO;}};
  /**
   * Reference to the runnable this stack usage is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef getRunnable();
  /**
   * Reference to the runnable this stack usage is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRunnable(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef newValue);
  // reference : ecu generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU = "ecu";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: stackUsage_ecu_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU,"ar3x.commonstructure.resourceconsumption.stackusage.StackUsage",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.STACK_USAGE_ECU_OWNER_RELATION_INFO;}};
  /**
   * Reference to the ECU description this implementation is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef getEcu();
  /**
   * Reference to the ECU description this implementation is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcu(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef newValue);
}
