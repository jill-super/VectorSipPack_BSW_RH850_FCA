package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwRecordLayoutGroupContentChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SwRecordLayoutGroupContentChild";
  // reference : swRecordLayoutGroupContent_swRecordLayoutGroupContentChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_GROUP_CONTENT_SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_OWNER = "swRecordLayoutGroupContent_swRecordLayoutGroupContentChildren_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swRecordLayoutGroupContentChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_GROUP_CONTENT_SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_GROUP_CONTENT_SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_OWNER,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroupContentChild",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent.SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent getSwRecordLayoutGroupContentSwRecordLayoutGroupContentChildrenOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayoutGroupContentSwRecordLayoutGroupContentChildrenOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent newValue);
}
