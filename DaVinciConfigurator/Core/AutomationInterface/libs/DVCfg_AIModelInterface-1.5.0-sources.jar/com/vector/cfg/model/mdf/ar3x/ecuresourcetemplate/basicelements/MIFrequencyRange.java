package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Class describing minimum, maximum and typical frequencies.
 */
public interface MIFrequencyRange extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "FrequencyRange";
  // attribute : minFrequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_FREQUENCY = "minFrequency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_FREQUENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_FREQUENCY,"ar3x.ecuresourcetemplate.basicelements.FrequencyRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinFrequency();
  /**
   * Minimum frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public void setMinFrequency(java.math.BigDecimal newValue);
  // attribute : maxFrequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_FREQUENCY = "maxFrequency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_FREQUENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_FREQUENCY,"ar3x.ecuresourcetemplate.basicelements.FrequencyRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaxFrequency();
  /**
   * Maximum frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public void setMaxFrequency(java.math.BigDecimal newValue);
  // attribute : typicalFrequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPICAL_FREQUENCY = "typicalFrequency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPICAL_FREQUENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPICAL_FREQUENCY,"ar3x.ecuresourcetemplate.basicelements.FrequencyRange",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Typical frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTypicalFrequency();
  /**
   * Typical frequency. Unit: Herz
   * Attribute-Kind = versionAttribute   */
  public void setTypicalFrequency(java.math.BigDecimal newValue);
  // reference : clock_frequency_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLOCK_FREQUENCY_OWNER = "clock_frequency_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: frequency
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLOCK_FREQUENCY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLOCK_FREQUENCY_OWNER,"ar3x.ecuresourcetemplate.basicelements.FrequencyRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock.FREQUENCY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock getClockFrequencyOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClockFrequencyOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock newValue);
  // reference : oscillator_oscillatorFrequencyRange_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OSCILLATOR_OSCILLATOR_FREQUENCY_RANGE_OWNER = "oscillator_oscillatorFrequencyRange_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: oscillatorFrequencyRange
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OSCILLATOR_OSCILLATOR_FREQUENCY_RANGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OSCILLATOR_OSCILLATOR_FREQUENCY_RANGE_OWNER,"ar3x.ecuresourcetemplate.basicelements.FrequencyRange",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.OSCILLATOR_FREQUENCY_RANGE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator getOscillatorOscillatorFrequencyRangeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOscillatorOscillatorFrequencyRangeOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator newValue);
}
