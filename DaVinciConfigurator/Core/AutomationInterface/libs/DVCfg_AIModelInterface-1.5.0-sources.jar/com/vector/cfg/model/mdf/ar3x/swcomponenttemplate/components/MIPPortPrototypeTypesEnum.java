package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;
import javax.jmi.model.*;

public enum MIPPortPrototypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  P_PORT_PROTOTYPE("P-PORT-PROTOTYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "components" );
    temp.add( "PPortPrototypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIPPortPrototypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
