package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation to a "delegated port" to specify the Signal Fan In or Signal Fan Out inside the Composition Type.
 */
public interface MIDelegatedPortAnnotation extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation
{
  public final static String CLASS_NAME = "DelegatedPortAnnotation";
  // attribute : signalFan generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SIGNAL_FAN = "signalFan";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SIGNAL_FAN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SIGNAL_FAN,"ar3x.swcomponenttemplate.applicationattributes.DelegatedPortAnnotation",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specify the Signal Fan In or Signal Fan Out inside the Composition Type
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum getSignalFan();
  /**
   * Specify the Signal Fan In or Signal Fan Out inside the Composition Type
   * Attribute-Kind = versionAttribute   */
  public void setSignalFan(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISignalFanEnum newValue);
  // reference : portPrototype_delegatedPortAnnotation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE_DELEGATED_PORT_ANNOTATION_OWNER = "portPrototype_delegatedPortAnnotation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: delegatedPortAnnotation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_DELEGATED_PORT_ANNOTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_DELEGATED_PORT_ANNOTATION_OWNER,"ar3x.swcomponenttemplate.applicationattributes.DelegatedPortAnnotation",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.DELEGATED_PORT_ANNOTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getPortPrototypeDelegatedPortAnnotationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototypeDelegatedPortAnnotationOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newValue);
}
