package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIPortGroupInnerGroup extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PortGroupInnerGroup";
  // reference : portGroup_innerGroup_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP_INNER_GROUP_OWNER = "portGroup_innerGroup_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: innerGroup
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_INNER_GROUP_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_INNER_GROUP_OWNER,"ar3x.swcomponenttemplate.components.instanceref.PortGroupInnerGroup",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.INNER_GROUP_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup getPortGroupInnerGroupOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortGroupInnerGroupOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup newValue);
  // reference : componentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_PROTOTYPE = "componentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portGroupInnerGroup_componentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.components.instanceref.PortGroupInnerGroup",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.PORT_GROUP_INNER_GROUP_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef> getComponentPrototype();
  // reference : portGroup generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP = "portGroup";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portGroupInnerGroup_portGroup_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP,"ar3x.swcomponenttemplate.components.instanceref.PortGroupInnerGroup",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef.PORT_GROUP_INNER_GROUP_PORT_GROUP_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef getPortGroup();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortGroup(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef newValue);
}
