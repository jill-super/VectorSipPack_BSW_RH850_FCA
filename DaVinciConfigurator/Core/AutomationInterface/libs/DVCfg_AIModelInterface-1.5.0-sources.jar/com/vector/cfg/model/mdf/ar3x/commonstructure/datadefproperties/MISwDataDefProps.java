package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class is a collection of properties relevant for data objects under various aspects. One could consider this class as a "pattern of inheritance by aggregation". The properties can be applied to all objects of all classes in which SwDataDefProps is agrregated.  Note that not all of the attributes or associated elements are useful all of the time. Hence, the process definition (e.g. expressed with an OCL or a Document Control Instance) MSR-DCI has the task of implementing limitations.  SwDataDefProps covers various aspects:  * Structure of the data element, is it a single value, a curve, or a map, but also the recordLayouts which specify, how such elements are mapped/converted to the DataTypes in the programming language (or in Autosar). This is mainly expressed by properties like swRecordLayout and swCalprmAxisSet   * Implementation policy, mainly expressed by swImplPolicy, swVariableAccessImplPolicy, swAddrMethod   * Access policy for the MDC system, mainly expressed by swCalibrationAccess   * Semantics of the data element, mainly expressed by compuMethod and/or unit, dataConstr   * Code generation policy provided by swCodeSyntax
 */
public interface MISwDataDefProps extends com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant.MIIsSyscond
{
  public final static String CLASS_NAME = "SwDataDefProps";
  // attribute : displayFormat generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DISPLAY_FORMAT = "displayFormat";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DISPLAY_FORMAT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DISPLAY_FORMAT,"ar3x.commonstructure.datadefproperties.SwDataDefProps",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This property describes how a number is to be rendered e.g. in documents or in a measurement and calibration system. 
   * Attribute-Kind = versionAttribute   */
  public String getDisplayFormat();
  /**
   * This property describes how a number is to be rendered e.g. in documents or in a measurement and calibration system. 
   * Attribute-Kind = versionAttribute   */
  public void setDisplayFormat(String newValue);
  // attribute : swCalibrationAccess generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_CALIBRATION_ACCESS = "swCalibrationAccess";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_CALIBRATION_ACCESS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_CALIBRATION_ACCESS,"ar3x.commonstructure.datadefproperties.SwDataDefProps",null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the read or write access by MCD tools for this data object.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum getSwCalibrationAccess();
  /**
   * Specifies the read or write access by MCD tools for this data object.
   * Attribute-Kind = versionAttribute   */
  public void setSwCalibrationAccess(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum newValue);
  // attribute : swImplPolicy generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_IMPL_POLICY = "swImplPolicy";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_IMPL_POLICY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_IMPL_POLICY,"ar3x.commonstructure.datadefproperties.SwDataDefProps",null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Implementation policy for this data object. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum getSwImplPolicy();
  /**
   * Implementation policy for this data object. 
   * Attribute-Kind = versionAttribute   */
  public void setSwImplPolicy(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwImplPolicyEnum newValue);
  // attribute : swVariableAccessImplPolicy generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_VARIABLE_ACCESS_IMPL_POLICY = "swVariableAccessImplPolicy";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_VARIABLE_ACCESS_IMPL_POLICY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_VARIABLE_ACCESS_IMPL_POLICY,"ar3x.commonstructure.datadefproperties.SwDataDefProps",null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableAccessImplPolicyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * In case of a swImplPolicy set to "message" the access policy can be refined here. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableAccessImplPolicyEnum getSwVariableAccessImplPolicy();
  /**
   * In case of a swImplPolicy set to "message" the access policy can be refined here. 
   * Attribute-Kind = versionAttribute   */
  public void setSwVariableAccessImplPolicy(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableAccessImplPolicyEnum newValue);
  // reference : invalidValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INVALID_VALUE = "invalidValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_invalidValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INVALID_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INVALID_VALUE,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIPrimitiveSpecification.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIPrimitiveSpecification.SW_DATA_DEF_PROPS_INVALID_VALUE_OWNER_RELATION_INFO;}};
  /**
   * Optional value to express invalidity of the actual data element. If given, the owning component has the API to set this data element invalid, otherwise it does not.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIPrimitiveSpecification getInvalidValue();
  /**
   * Optional value to express invalidity of the actual data element. If given, the owning component has the API to set this data element invalid, otherwise it does not.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInvalidValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIPrimitiveSpecification newValue);
  // reference : swAddrMethod generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_ADDR_METHOD = "swAddrMethod";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swAddrMethod_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_ADDR_METHOD_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_ADDR_METHOD,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.SW_DATA_DEF_PROPS_SW_ADDR_METHOD_OWNER_RELATION_INFO;}};
  /**
   * Addressing method related to this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef getSwAddrMethod();
  /**
   * Addressing method related to this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAddrMethod(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef newValue);
  // reference : swCodeSyntax generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CODE_SYNTAX = "swCodeSyntax";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swCodeSyntax_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CODE_SYNTAX_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CODE_SYNTAX,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef.SW_DATA_DEF_PROPS_SW_CODE_SYNTAX_OWNER_RELATION_INFO;}};
  /**
   * Coding policy for this data object expressed as a reference to a Code syntax to be applied.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef getSwCodeSyntax();
  /**
   * Coding policy for this data object expressed as a reference to a Code syntax to be applied.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCodeSyntax(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef newValue);
  // reference : swRecordLayout generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT = "swRecordLayout";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swRecordLayout_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.SW_DATA_DEF_PROPS_SW_RECORD_LAYOUT_OWNER_RELATION_INFO;}};
  /**
   * Record layout for this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef getSwRecordLayout();
  /**
   * Record layout for this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayout(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef newValue);
  // reference : swCalprmAxisSet generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_SET = "swCalprmAxisSet";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swCalprmAxisSet_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_SET_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_SET,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet.SW_DATA_DEF_PROPS_SW_CALPRM_AXIS_SET_OWNER_RELATION_INFO;}};
  /**
   * This specifies the properties of the axes in case of a curve or map etc. This is mainly applicable to calibration parameters.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet getSwCalprmAxisSet();
  /**
   * This specifies the properties of the axes in case of a curve or map etc. This is mainly applicable to calibration parameters.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisSet(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet newValue);
  // reference : swDataDependency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEPENDENCY = "swDataDependency";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swDataDependency_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEPENDENCY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEPENDENCY,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.SW_DATA_DEF_PROPS_SW_DATA_DEPENDENCY_OWNER_RELATION_INFO;}};
  /**
   * If the data object is virtual - that means it is not directly in the ecu, then this property describes how the "virtual variable" can be computed from the real ones.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency getSwDataDependency();
  /**
   * If the data object is virtual - that means it is not directly in the ecu, then this property describes how the "virtual variable" can be computed from the real ones.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDependency(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency newValue);
  // reference : swPointer generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_POINTER = "swPointer";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swPointer_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_POINTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_POINTER,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwPointer.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwPointer.SW_DATA_DEF_PROPS_SW_POINTER_OWNER_RELATION_INFO;}};
  /**
   * Specifies that the containing data object is a pointer to another data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwPointer getSwPointer();
  /**
   * Specifies that the containing data object is a pointer to another data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwPointer(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwPointer newValue);
  // reference : swTextProps generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_TEXT_PROPS = "swTextProps";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swTextProps_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_TEXT_PROPS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_TEXT_PROPS,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwTextProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwTextProps.SW_DATA_DEF_PROPS_SW_TEXT_PROPS_OWNER_RELATION_INFO;}};
  /**
   * the specific properties if the data object is a text object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwTextProps getSwTextProps();
  /**
   * the specific properties if the data object is a text object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwTextProps(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwTextProps newValue);
  // reference : annotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ANNOTATION = "annotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_annotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ANNOTATION,"ar3x.commonstructure.datadefproperties.SwDataDefProps",133,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIAnnotation.SW_DATA_DEF_PROPS_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * This aggregation allows to add annotations (yellow pads ...) related to the current data object. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIAnnotation> getAnnotation();
  // reference : swValueBlockSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_VALUE_BLOCK_SIZE = "swValueBlockSize";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swValueBlockSize_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VALUE_BLOCK_SIZE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VALUE_BLOCK_SIZE,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.SW_DATA_DEF_PROPS_SW_VALUE_BLOCK_SIZE_OWNER_RELATION_INFO;}};
  /**
   * Specifies the size in case the data object is an VAL_BLK. It is there for compatibility reasons, where value blocks were introduced as a kind of an array.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize getSwValueBlockSize();
  /**
   * Specifies the size in case the data object is an VAL_BLK. It is there for compatibility reasons, where value blocks were introduced as a kind of an array.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwValueBlockSize(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize newValue);
  // reference : dataConstr generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_CONSTR = "dataConstr";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_dataConstr_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_CONSTR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_CONSTR,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef.SW_DATA_DEF_PROPS_DATA_CONSTR_OWNER_RELATION_INFO;}};
  /**
   * Data constraint for this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef getDataConstr();
  /**
   * Data constraint for this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataConstr(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstrARRef newValue);
  // reference : unit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String UNIT = "unit";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_unit_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo UNIT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(UNIT,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef.SW_DATA_DEF_PROPS_UNIT_OWNER_RELATION_INFO;}};
  /**
   * Physical unit associated with the semantics of this data object. This attribute applies, if no compuMethod is specified. If buth units (this as well as via compuMethod is specified,the units ust be the same.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef getUnit();
  /**
   * Physical unit associated with the semantics of this data object. This attribute applies, if no compuMethod is specified. If buth units (this as well as via compuMethod is specified,the units ust be the same.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setUnit(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.units.MIUnitARRef newValue);
  // reference : swHostVariable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_HOST_VARIABLE = "swHostVariable";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swHostVariable_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_HOST_VARIABLE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_HOST_VARIABLE,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableRef.SW_DATA_DEF_PROPS_SW_HOST_VARIABLE_OWNER_RELATION_INFO;}};
  /**
   * Contains a reference to a variable, which serves as a host-variable for a bit variable. Only applicable to bit objects.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableRef getSwHostVariable();
  /**
   * Contains a reference to a variable, which serves as a host-variable for a bit variable. Only applicable to bit objects.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwHostVariable(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwVariableRef newValue);
  // reference : baseType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE = "baseType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_baseType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.SW_DATA_DEF_PROPS_BASE_TYPE_OWNER_RELATION_INFO;}};
  /**
   * Base type associated with the value axis of this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef getBaseType();
  /**
   * Base type associated with the value axis of this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef newValue);
  // reference : compuMethod generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_METHOD = "compuMethod";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_compuMethod_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_METHOD_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_METHOD,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef.SW_DATA_DEF_PROPS_COMPU_METHOD_OWNER_RELATION_INFO;}};
  /**
   * Computation method associated with the semantics of this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef getCompuMethod();
  /**
   * Computation method associated with the semantics of this data object.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuMethod(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethodARRef newValue);
  // reference : swBitRepresentation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_BIT_REPRESENTATION = "swBitRepresentation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDefProps_swBitRepresentation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_BIT_REPRESENTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_BIT_REPRESENTATION,"ar3x.commonstructure.datadefproperties.SwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwBitRepresentation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwBitRepresentation.SW_DATA_DEF_PROPS_SW_BIT_REPRESENTATION_OWNER_RELATION_INFO;}};
  /**
   * Description of the binary representaion in case of a bit variable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwBitRepresentation getSwBitRepresentation();
  /**
   * Description of the binary representaion in case of a bit variable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwBitRepresentation(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwBitRepresentation newValue);
  // reference : hasSwDataDefProps_swDataDefProps_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SW_DATA_DEF_PROPS_SW_DATA_DEF_PROPS_OWNER = "hasSwDataDefProps_swDataDefProps_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swDataDefProps
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SW_DATA_DEF_PROPS_SW_DATA_DEF_PROPS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SW_DATA_DEF_PROPS_SW_DATA_DEF_PROPS_OWNER,"ar3x.commonstructure.datadefproperties.SwDataDefProps",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps.SW_DATA_DEF_PROPS_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps getHasSwDataDefPropsSwDataDefPropsOwner();
  public void setHasSwDataDefPropsSwDataDefPropsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps newValue);
}
