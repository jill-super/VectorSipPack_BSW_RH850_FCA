package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;
import javax.jmi.model.*;

public enum MIMemoryMappedHWPortTypesEnum implements javax.jmi.reflect.RefEnum
{
  MEMORY_MAPPED_HW_PORT("MEMORY-MAPPED-HW-PORT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memory" );
    temp.add( "MemoryMappedHWPortTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemoryMappedHWPortTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
