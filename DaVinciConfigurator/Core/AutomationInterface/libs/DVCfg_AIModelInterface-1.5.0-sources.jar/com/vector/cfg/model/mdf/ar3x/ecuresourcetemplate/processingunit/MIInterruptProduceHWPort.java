package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This port represents the source of an interrupt request, i.e. the HWElement to which this port is attached is capable of raising interrupt requests.
 */
public interface MIInterruptProduceHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptHWPort
{
  public final static String CLASS_NAME = "InterruptProduceHWPort";
  // reference : interruptProduceHWPortARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INTERRUPT_PRODUCE_HWPORT_ARREF_REF_TARGETS_OWNER = "interruptProduceHWPortARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INTERRUPT_PRODUCE_HWPORT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INTERRUPT_PRODUCE_HWPORT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.processingunit.InterruptProduceHWPort",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef> getInterruptProduceHWPortARRefRefTargetsOwner();
  // reference : mPU_raisedInterrupt_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String M_PU_RAISED_INTERRUPT_OWNER = "mPU_raisedInterrupt_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: raisedInterrupt
  public static final ru.novosoft.mdf.impl.MDFRelationInfo M_PU_RAISED_INTERRUPT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(M_PU_RAISED_INTERRUPT_OWNER,"ar3x.ecuresourcetemplate.processingunit.InterruptProduceHWPort",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.RAISED_INTERRUPT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU getMPURaisedInterruptOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setMPURaisedInterruptOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU newValue);
}
