package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MIAdcBehaviourAtLimitEnum implements javax.jmi.reflect.RefEnum
{
  CLIPPING("CLIPPING"),
  DEFAULT("DEFAULT"),
  UNDEFINED("UNDEFINED"),
  OTHER("OTHER");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "AdcBehaviourAtLimitEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIAdcBehaviourAtLimitEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
