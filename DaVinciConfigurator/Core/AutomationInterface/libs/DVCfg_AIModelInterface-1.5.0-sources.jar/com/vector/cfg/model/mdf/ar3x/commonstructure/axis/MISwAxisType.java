package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Stands for a specific axis calculation strategy. No formal specification is given, due to the fact that it is possible to use arbitrary algorithms for calculating axis-points. Instead, the algorithm is described verbally but the parameters are specified formally with respect to their names and constraints. As a result, SwAxisType mainly reserves appropriate keywords.
 */
public interface MISwAxisType extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "SwAxisType";
  // reference : swAxisTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_AXIS_TYPE_ARREF_REF_TARGETS_OWNER = "swAxisTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.axis.SwAxisType",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef> getSwAxisTypeARRefRefTargetsOwner();
  // reference : swGenericAxisParamType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_TYPE = "swGenericAxisParamType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisType_swGenericAxisParamType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_TYPE,"ar3x.commonstructure.axis.SwAxisType",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType.SW_AXIS_TYPE_SW_GENERIC_AXIS_PARAM_TYPE_OWNER_RELATION_INFO;}};
  /**
   * Parameters for this calcultaion algorithm.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType> getSwGenericAxisParamType();
}
