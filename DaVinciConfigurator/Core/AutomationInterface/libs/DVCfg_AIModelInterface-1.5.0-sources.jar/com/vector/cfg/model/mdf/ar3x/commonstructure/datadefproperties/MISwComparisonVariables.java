package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * These variables can be used to display the value of a variable on the value axis of a calibration parameter (characteristic), that is currently displayed in the MCD-System. The purpose is to compare the appropriate result from the calibration parameter in question, with a value being calculated or taken from a sensor (the comparison variable).  The sole purpose of this comparison-variable is to serve the calibration process.  Screen representation of comparison variable      Vs |              |                         |              |                         |              |                      V _|______________|______________                         |         /----|------                         |  /-----/     |                         | /            |                         |/             |                         |--------------|--------------                                        tx          tmot                                          tx: current temperature                         V:  current speed as shown in the MCD system for comparison:                             this is the SwComparisonVariable                         Vs: speed characteristic over temperature                         tmot: motor temperature
 */
public interface MISwComparisonVariables extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy
{
  public final static String CLASS_NAME = "SwComparisonVariables";
}
