package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs of a compoment or module on the configuration of OBD Services in relation to a particular "ratio monitoring", which is supported by this component or module.
 */
public interface MIObdRatioServiceNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ObdRatioServiceNeeds";
  // attribute : iumprGroup generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String IUMPR_GROUP = "iumprGroup";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo IUMPR_GROUP_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,IUMPR_GROUP,"ar3x.commonstructure.serviceneeds.ObdRatioServiceNeeds",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the IUMPR Group of the SAE standard. Note that possible values are not predefined by an enumeration meta-type in oder to make the meta-model independent of the details of the SAE standard. Possible values are currently (AUTOSAR R3.1): CAT1 CAT2 OXS1 OXS2 EGR SAIR EVAP SECOXS1 SECOXS2 NMHCCAT NOXCAT NOXADSORB PMFILTER EGSENSOR BOOSTPRS NOGROUP NONE.
   * Attribute-Kind = versionAttribute   */
  public String getIumprGroup();
  /**
   * Defines the IUMPR Group of the SAE standard. Note that possible values are not predefined by an enumeration meta-type in oder to make the meta-model independent of the details of the SAE standard. Possible values are currently (AUTOSAR R3.1): CAT1 CAT2 OXS1 OXS2 EGR SAIR EVAP SECOXS1 SECOXS2 NMHCCAT NOXCAT NOXADSORB PMFILTER EGSENSOR BOOSTPRS NOGROUP NONE.
   * Attribute-Kind = versionAttribute   */
  public void setIumprGroup(String newValue);
  // attribute : connectionType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CONNECTION_TYPE = "connectionType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CONNECTION_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CONNECTION_TYPE,"ar3x.commonstructure.serviceneeds.ObdRatioServiceNeeds",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIObdRatioConnectionKind.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines how the DEM is connected to the component or module to perform the IUMPR service.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIObdRatioConnectionKind getConnectionType();
  /**
   * Defines how the DEM is connected to the component or module to perform the IUMPR service.
   * Attribute-Kind = versionAttribute   */
  public void setConnectionType(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIObdRatioConnectionKind newValue);
  // reference : rateBasedMonitoredEvent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RATE_BASED_MONITORED_EVENT = "rateBasedMonitoredEvent";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: obdRatioServiceNeeds_rateBasedMonitoredEvent_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RATE_BASED_MONITORED_EVENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RATE_BASED_MONITORED_EVENT,"ar3x.commonstructure.serviceneeds.ObdRatioServiceNeeds",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef.OBD_RATIO_SERVICE_NEEDS_RATE_BASED_MONITORED_EVENT_OWNER_RELATION_INFO;}};
  /**
   * The rate based monitored Diagnosic Event.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef getRateBasedMonitoredEvent();
  /**
   * The rate based monitored Diagnosic Event.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRateBasedMonitoredEvent(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef newValue);
  // reference : usedFid generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String USED_FID = "usedFid";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: obdRatioServiceNeeds_usedFid_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo USED_FID_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(USED_FID,"ar3x.commonstructure.serviceneeds.ObdRatioServiceNeeds",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIFunctionInhibitionNeedsARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIFunctionInhibitionNeedsARRef.OBD_RATIO_SERVICE_NEEDS_USED_FID_OWNER_RELATION_INFO;}};
  /**
   * Function Inhibition Identifier used for the rate based monitor. This is an optional attribute.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIFunctionInhibitionNeedsARRef getUsedFid();
  /**
   * Function Inhibition Identifier used for the rate based monitor. This is an optional attribute.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setUsedFid(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIFunctionInhibitionNeedsARRef newValue);
}
