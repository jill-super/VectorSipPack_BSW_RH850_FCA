package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A ProcessingUnit describes the plain processor core. The identifier provides the actual type name of the processing unit.
 */
public interface MIProcessingUnit extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement
{
  public final static String CLASS_NAME = "ProcessingUnit";
  // attribute : architectureKind generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ARCHITECTURE_KIND = "architectureKind";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ARCHITECTURE_KIND_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ARCHITECTURE_KIND,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureKindEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The kind of architecture
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureKindEnum getArchitectureKind();
  /**
   * The kind of architecture
   * Attribute-Kind = versionAttribute   */
  public void setArchitectureKind(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureKindEnum newValue);
  // attribute : architectureName generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ARCHITECTURE_NAME = "architectureName";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ARCHITECTURE_NAME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ARCHITECTURE_NAME,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The name of the architecture (e.g. ARM, MIPS, PowerPC).
   * Attribute-Kind = versionAttribute   */
  public String getArchitectureName();
  /**
   * The name of the architecture (e.g. ARM, MIPS, PowerPC).
   * Attribute-Kind = versionAttribute   */
  public void setArchitectureName(String newValue);
  // attribute : architectureType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ARCHITECTURE_TYPE = "architectureType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ARCHITECTURE_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ARCHITECTURE_TYPE,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The architecture type take influence to the performance index of a PU, but are not necessarily a main topic of software development, as some of the aspects are transparent  to the user as the are handled with in the compiler. The last two types are slightly different as they require a detailed planning during system design, how the data must be prepared in order to use the features of an SIMD or MIMD very efficiently. Application like video processing use in general this features by their data format, as every pixel information is formed by the three basic colours and intensity, thus each pixel is represented by four different values, which have to be processed simultaneously.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureTypeEnum getArchitectureType();
  /**
   * The architecture type take influence to the performance index of a PU, but are not necessarily a main topic of software development, as some of the aspects are transparent  to the user as the are handled with in the compiler. The last two types are slightly different as they require a detailed planning during system design, how the data must be prepared in order to use the features of an SIMD or MIMD very efficiently. Application like video processing use in general this features by their data format, as every pixel information is formed by the three basic colours and intensity, thus each pixel is represented by four different values, which have to be processed simultaneously.
   * Attribute-Kind = versionAttribute   */
  public void setArchitectureType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitArchitectureTypeEnum newValue);
  // attribute : dmaChannelCount generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DMA_CHANNEL_COUNT = "dmaChannelCount";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DMA_CHANNEL_COUNT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DMA_CHANNEL_COUNT,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Direct Memory Access is a mechanism for off-loading a PU and having transfer directly between memory and peripherals without involving the PU.  In most common PU the DMA mechanism is implemented with a specialised cell (DMA unit) that transfers data between a peripheral device and memory, independent of the processor. The DMA controller becomes the bus master and directs the reads or writes between itself and memory. A typical DMA transfer can be described in three steps: 1. The PU sets up the DMA transfer by supplying the identity of the periphery module, the operation to perform on that device, the memory address that is the source or the destination of the data to be transferred, and the number of bytes to transfer.  2. The DMA starts the operation on the periphery device and arbitrates for the bus. When the data is available, from the periphery device or memory, it transfers the data. The DMA unit supplies the memory address and initiates the next transfer. With this technique, a DMA unit can complete an entire transfer, which may be Kbytes of data, without bothering the PU. Many DMA units contain some memory to allow them to deal flexibly with delays either in transfer or those incurred while waiting to become bus master.  3. Once the DMA transfer is complete, the DMA unit interrupts the processor, which can then determine by interrogating the DMA unit or examining memory whether the entire operation completed successfully.  During an active DMA transfer the PU cannot access the involved resources concurrently.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDmaChannelCount();
  /**
   * Direct Memory Access is a mechanism for off-loading a PU and having transfer directly between memory and peripherals without involving the PU.  In most common PU the DMA mechanism is implemented with a specialised cell (DMA unit) that transfers data between a peripheral device and memory, independent of the processor. The DMA controller becomes the bus master and directs the reads or writes between itself and memory. A typical DMA transfer can be described in three steps: 1. The PU sets up the DMA transfer by supplying the identity of the periphery module, the operation to perform on that device, the memory address that is the source or the destination of the data to be transferred, and the number of bytes to transfer.  2. The DMA starts the operation on the periphery device and arbitrates for the bus. When the data is available, from the periphery device or memory, it transfers the data. The DMA unit supplies the memory address and initiates the next transfer. With this technique, a DMA unit can complete an entire transfer, which may be Kbytes of data, without bothering the PU. Many DMA units contain some memory to allow them to deal flexibly with delays either in transfer or those incurred while waiting to become bus master.  3. Once the DMA transfer is complete, the DMA unit interrupts the processor, which can then determine by interrogating the DMA unit or examining memory whether the entire operation completed successfully.  During an active DMA transfer the PU cannot access the involved resources concurrently.
   * Attribute-Kind = versionAttribute   */
  public void setDmaChannelCount(java.math.BigInteger newValue);
  // attribute : implementationTechnology generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String IMPLEMENTATION_TECHNOLOGY = "implementationTechnology";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo IMPLEMENTATION_TECHNOLOGY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,IMPLEMENTATION_TECHNOLOGY,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Name of the technology used to implement this PU.
   * Attribute-Kind = versionAttribute   */
  public String getImplementationTechnology();
  /**
   * Name of the technology used to implement this PU.
   * Attribute-Kind = versionAttribute   */
  public void setImplementationTechnology(String newValue);
  // attribute : maxInterruptNestingLevels generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_INTERRUPT_NESTING_LEVELS = "maxInterruptNestingLevels";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_INTERRUPT_NESTING_LEVELS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_INTERRUPT_NESTING_LEVELS,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines how many interrupts are allowed to be activated at one time. This entry is mainly defined by the size of the according stack as the data saving mechanism during interrupts and the data passing mechanism during function calls use the stack.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaxInterruptNestingLevels();
  /**
   * Defines how many interrupts are allowed to be activated at one time. This entry is mainly defined by the size of the according stack as the data saving mechanism during interrupts and the data passing mechanism during function calls use the stack.
   * Attribute-Kind = versionAttribute   */
  public void setMaxInterruptNestingLevels(java.math.BigInteger newValue);
  // attribute : naturalDataSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NATURAL_DATA_SIZE = "naturalDataSize";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NATURAL_DATA_SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NATURAL_DATA_SIZE,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The natural data size prvides information which data manipulations are optimized on this PU. The natural data size is typically the Data Register size. The PU is optimised for this data size. Typical natural data size is one of following (in bits): 8, 16, 32, 64, other (12, 20, 80) 
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getNaturalDataSize();
  /**
   * The natural data size prvides information which data manipulations are optimized on this PU. The natural data size is typically the Data Register size. The PU is optimised for this data size. Typical natural data size is one of following (in bits): 8, 16, 32, 64, other (12, 20, 80) 
   * Attribute-Kind = versionAttribute   */
  public void setNaturalDataSize(java.math.BigInteger newValue);
  // attribute : opcodeSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPCODE_SIZE = "opcodeSize";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPCODE_SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPCODE_SIZE,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The attribute describes the typical length of the opcodes. In CISC machines the opcode size is variable due to the opcode itself. In RISC machines the opcode is by definition limited to a defined size. Type definition is used if the PU has more than one opcode set is incorporated. E.g. at the ARM architecture there is the ARM opcode set (size of 32 bit) and the Thumb opcode set (size of 16 bit). Code compression is a technology where the opcodes are stored in a compressed form and are automatically decompressed before execution.
   * Attribute-Kind = versionAttribute   */
  public String getOpcodeSize();
  /**
   * The attribute describes the typical length of the opcodes. In CISC machines the opcode size is variable due to the opcode itself. In RISC machines the opcode is by definition limited to a defined size. Type definition is used if the PU has more than one opcode set is incorporated. E.g. at the ARM architecture there is the ARM opcode set (size of 32 bit) and the Thumb opcode set (size of 16 bit). Code compression is a technology where the opcodes are stored in a compressed form and are automatically decompressed before execution.
   * Attribute-Kind = versionAttribute   */
  public void setOpcodeSize(String newValue);
  // reference : processingUnitARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROCESSING_UNIT_ARREF_REF_TARGETS_OWNER = "processingUnitARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef> getProcessingUnitARRefRefTargetsOwner();
  // reference : addressingModes generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ADDRESSING_MODES = "addressingModes";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_addressingModes_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ADDRESSING_MODES_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ADDRESSING_MODES,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitAdressingModeEnumItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitAdressingModeEnumItem.PROCESSING_UNIT_ADDRESSING_MODES_OWNER_RELATION_INFO;}};
  /**
   * The addressing modes describe the options to access the data from the memory. 
   */
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitAdressingModeEnumItem> getAddressingModes();
  // reference : specialOpcodes generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SPECIAL_OPCODES = "specialOpcodes";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_specialOpcodes_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SPECIAL_OPCODES_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SPECIAL_OPCODES,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnumItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnumItem.PROCESSING_UNIT_SPECIAL_OPCODES_OWNER_RELATION_INFO;}};
  /**
   * The following attributes are opcodes, which are not supported by all PUs. The support of this opcodes has an influence on the performance of the PU. - Bit-manipulation - Multiplication - Division - Multiply Accumulate - Floating-point Support In the future further opcodes may be possible.  The special opcodes  take important influence to the performance index of a PU, but are not main topic of the software development, as far as high level programming languages are used, due to the fact that these are covered by compiler settings, compiler strategies and software libraries where the direct usage or a SW emulation is available for almost any general use case. For some of these opcodes the main advantage is available only at the level of assembler programming or compiler optimization.
   */
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnumItem> getSpecialOpcodes();
  // reference : bootTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BOOT_TIME = "bootTime";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_bootTime_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BOOT_TIME_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BOOT_TIME,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIBootTime.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIBootTime.PROCESSING_UNIT_BOOT_TIME_OWNER_RELATION_INFO;}};
  /**
   * Provide information about the boot time of the PU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIBootTime getBootTime();
  /**
   * Provide information about the boot time of the PU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBootTime(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIBootTime newValue);
  // reference : mpu generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MPU = "mpu";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_mpu_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MPU_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MPU,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.PROCESSING_UNIT_MPU_OWNER_RELATION_INFO;}};
  /**
   * Describes the Memory Protection Unit, if available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU getMpu();
  /**
   * Describes the Memory Protection Unit, if available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setMpu(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU newValue);
  // reference : puClock generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PU_CLOCK = "puClock";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_puClock_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PU_CLOCK_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PU_CLOCK,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock.PROCESSING_UNIT_PU_CLOCK_OWNER_RELATION_INFO;}};
  /**
   * The clock source for the PU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock getPuClock();
  /**
   * The clock source for the PU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPuClock(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClock newValue);
  // reference : registerModel generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REGISTER_MODEL = "registerModel";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_registerModel_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REGISTER_MODEL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REGISTER_MODEL,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegister.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegister.PROCESSING_UNIT_REGISTER_MODEL_OWNER_RELATION_INFO;}};
  /**
   * Describes the register model of the PU. For each register type availabe one 'Regsiter' element is used to give the number available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegister> getRegisterModel();
  // reference : supportedDataType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPORTED_DATA_TYPE = "supportedDataType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: processingUnit_supportedDataType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTED_DATA_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTED_DATA_TYPE,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnit",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MISupportedDataType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MISupportedDataType.PROCESSING_UNIT_SUPPORTED_DATA_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This element provides a list of all supported data types and its according data sizes of the described PU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MISupportedDataType> getSupportedDataType();
}
