package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIScaleConstr extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.model.autosar.commonpatterns.textmodel.multilanguagedata.MIHasDescMultiLanguageOverviewParagraph, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.localconstraints.MIHasUpperLimitLimit, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.localconstraints.MIHasLowerLimitLimit
{
  public final static String CLASS_NAME = "ScaleConstr";
  // attribute : shortLabel generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SHORT_LABEL = "shortLabel";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SHORT_LABEL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SHORT_LABEL,"ar3x.commonstructure.globalconstraints.ScaleConstr",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies a short name for the scaleConstr. This can for example be used to create more specific messages of a constraint checker. The constraints cannot be associated in the metamodel, therefore shortLabel is somehow a substitute for shortName.
   * Attribute-Kind = versionAttribute   */
  public String getShortLabel();
  /**
   * This element specifies a short name for the scaleConstr. This can for example be used to create more specific messages of a constraint checker. The constraints cannot be associated in the metamodel, therefore shortLabel is somehow a substitute for shortName.
   * Attribute-Kind = versionAttribute   */
  public void setShortLabel(String newValue);
  // attribute : validity generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALIDITY = "validity";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALIDITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALIDITY,"ar3x.commonstructure.globalconstraints.ScaleConstr",null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstrValidityEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies if the values defined by the scales are considered to be valid. If the attribute is missing then the default value is "VALID".
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstrValidityEnum getValidity();
  /**
   * Specifies if the values defined by the scales are considered to be valid. If the attribute is missing then the default value is "VALID".
   * Attribute-Kind = versionAttribute   */
  public void setValidity(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstrValidityEnum newValue);
  // reference : hasScaleConstr_scaleConstr_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SCALE_CONSTR_SCALE_CONSTR_OWNER = "hasScaleConstr_scaleConstr_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: scaleConstr
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SCALE_CONSTR_SCALE_CONSTR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SCALE_CONSTR_SCALE_CONSTR_OWNER,"ar3x.commonstructure.globalconstraints.ScaleConstr",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr.SCALE_CONSTR_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr getHasScaleConstrScaleConstrOwner();
  public void setHasScaleConstrScaleConstrOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr newValue);
}
