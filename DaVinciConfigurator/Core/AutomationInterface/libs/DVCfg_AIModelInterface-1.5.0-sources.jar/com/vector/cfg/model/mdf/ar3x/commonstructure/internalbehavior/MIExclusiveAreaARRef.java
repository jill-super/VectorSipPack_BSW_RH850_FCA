package com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIExclusiveAreaARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ExclusiveAreaARRef";
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: exclusiveAreaARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea.EXCLUSIVE_AREA_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea> getRefTargets();
  // reference : bswModuleEntity_canEnterExclusiveArea_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER = "bswModuleEntity_canEnterExclusiveArea_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: canEnterExclusiveArea
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.CAN_ENTER_EXCLUSIVE_AREA_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity getBswModuleEntityCanEnterExclusiveAreaOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleEntityCanEnterExclusiveAreaOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity newValue);
  // reference : runnableEntity_runsInsideExclusiveArea_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RUNNABLE_ENTITY_RUNS_INSIDE_EXCLUSIVE_AREA_OWNER = "runnableEntity_runsInsideExclusiveArea_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: runsInsideExclusiveArea
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RUNNABLE_ENTITY_RUNS_INSIDE_EXCLUSIVE_AREA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RUNNABLE_ENTITY_RUNS_INSIDE_EXCLUSIVE_AREA_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity.RUNS_INSIDE_EXCLUSIVE_AREA_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity getRunnableEntityRunsInsideExclusiveAreaOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRunnableEntityRunsInsideExclusiveAreaOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity newValue);
  // reference : runnableEntity_canEnterExclusiveArea_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RUNNABLE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER = "runnableEntity_canEnterExclusiveArea_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: canEnterExclusiveArea
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RUNNABLE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RUNNABLE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity.CAN_ENTER_EXCLUSIVE_AREA_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity getRunnableEntityCanEnterExclusiveAreaOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRunnableEntityCanEnterExclusiveAreaOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIRunnableEntity newValue);
  // reference : executionTime_exclusiveArea_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXECUTION_TIME_EXCLUSIVE_AREA_OWNER = "executionTime_exclusiveArea_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: exclusiveArea
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXECUTION_TIME_EXCLUSIVE_AREA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXECUTION_TIME_EXCLUSIVE_AREA_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveAreaARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.EXCLUSIVE_AREA_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime getExecutionTimeExclusiveAreaOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setExecutionTimeExclusiveAreaOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea newRefTarget);

}
