package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MIDisplayHwTypeOfCharactersEnum implements javax.jmi.reflect.RefEnum
{
  NUMERICAL("NUMERICAL"),
  ALPHA_NUMERICAL("ALPHA-NUMERICAL"),
  SEMI_GRAPHICAL("SEMI-GRAPHICAL"),
  GRAPHICAL("GRAPHICAL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "DisplayHwTypeOfCharactersEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDisplayHwTypeOfCharactersEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
