package com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This abstract class makes all its specialization dependant on a so called system condition. If the expression in swSyscond evaluates to greater than "0", then the object exists. Otherwise it is treated as removed.
 */
public interface MIIsSyscond extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "IsSyscond";
}
