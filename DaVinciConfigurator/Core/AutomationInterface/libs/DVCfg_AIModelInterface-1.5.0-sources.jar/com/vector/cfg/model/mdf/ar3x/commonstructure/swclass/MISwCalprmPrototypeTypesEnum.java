package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;
import javax.jmi.model.*;

public enum MISwCalprmPrototypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_CALPRM_PROTOTYPE("SW-CALPRM-PROTOTYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "swclass" );
    temp.add( "SwCalprmPrototypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwCalprmPrototypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
