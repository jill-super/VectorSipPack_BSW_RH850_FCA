package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.specializedswcalprmrefproxy;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwCalprm extends com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild
{
  public final static String CLASS_NAME = "SwCalprm";
}
