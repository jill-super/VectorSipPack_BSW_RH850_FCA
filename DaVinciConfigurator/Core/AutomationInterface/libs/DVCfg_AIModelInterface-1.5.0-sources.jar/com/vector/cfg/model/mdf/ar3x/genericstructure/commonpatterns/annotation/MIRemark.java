package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * <remark> is used for comments e.g. on the specific calibration state. The remark can be a regular paragraph or a preformatted text. 
 */
public interface MIRemark extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Remark";
  // reference : generalAnnotation_annotationText_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String GENERAL_ANNOTATION_ANNOTATION_TEXT_OWNER = "generalAnnotation_annotationText_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: annotationText
  public static final ru.novosoft.mdf.impl.MDFRelationInfo GENERAL_ANNOTATION_ANNOTATION_TEXT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(GENERAL_ANNOTATION_ANNOTATION_TEXT_OWNER,"ar3x.genericstructure.commonpatterns.annotation.Remark",64,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation.ANNOTATION_TEXT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation getGeneralAnnotationAnnotationTextOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setGeneralAnnotationAnnotationTextOwner(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation newValue);
  // reference : remarkChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REMARK_CHILDREN = "remarkChildren";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: remark_remarkChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REMARK_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REMARK_CHILDREN,"ar3x.genericstructure.commonpatterns.annotation.Remark",133,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemarkChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemarkChild.REMARK_REMARK_CHILDREN_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemarkChild> getRemarkChildren();
}
