package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation of the data elements in a port that realizes a sender/receiver interface.
 */
public interface MISenderReceiverAnnotation extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation
{
  public final static String CLASS_NAME = "SenderReceiverAnnotation";
  // attribute : computed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COMPUTED = "computed";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COMPUTED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COMPUTED,"ar3x.swcomponenttemplate.applicationattributes.SenderReceiverAnnotation",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Flag whether this data element was not measured directly but instead was calculated from possibly several other measured or calculated values.
   * Attribute-Kind = versionAttribute   */
  public Boolean getComputed();
  /**
   * Flag whether this data element was not measured directly but instead was calculated from possibly several other measured or calculated values.
   * Attribute-Kind = versionAttribute   */
  public void setComputed(Boolean newValue);
  // attribute : limitKind generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LIMIT_KIND = "limitKind";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LIMIT_KIND_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LIMIT_KIND,"ar3x.swcomponenttemplate.applicationattributes.SenderReceiverAnnotation",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MILimitKind.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This min or max has not to be mismatched with the min- and max for data-value in a CompuMethod. For example, this annotation shows when the result of the calculation performed in a RunnableEntity owned by one AtomicSoftwareComponentType is transmitted to another AtomicSoftwareComponentType whose RunnableEntity will use this value as a limit, e.g. the max.power which can be used by that software-component, or the current min. slip.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MILimitKind getLimitKind();
  /**
   * This min or max has not to be mismatched with the min- and max for data-value in a CompuMethod. For example, this annotation shows when the result of the calculation performed in a RunnableEntity owned by one AtomicSoftwareComponentType is transmitted to another AtomicSoftwareComponentType whose RunnableEntity will use this value as a limit, e.g. the max.power which can be used by that software-component, or the current min. slip.
   * Attribute-Kind = versionAttribute   */
  public void setLimitKind(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MILimitKind newValue);
  // attribute : processingKind generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROCESSING_KIND = "processingKind";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PROCESSING_KIND_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PROCESSING_KIND,"ar3x.swcomponenttemplate.applicationattributes.SenderReceiverAnnotation",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIProcessingKind.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute indicates how the data is processed according to the PorcessingKind.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIProcessingKind getProcessingKind();
  /**
   * This attribute indicates how the data is processed according to the PorcessingKind.
   * Attribute-Kind = versionAttribute   */
  public void setProcessingKind(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIProcessingKind newValue);
  // reference : portPrototype_senderReceiverAnnotation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE_SENDER_RECEIVER_ANNOTATION_OWNER = "portPrototype_senderReceiverAnnotation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: senderReceiverAnnotation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_SENDER_RECEIVER_ANNOTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_SENDER_RECEIVER_ANNOTATION_OWNER,"ar3x.swcomponenttemplate.applicationattributes.SenderReceiverAnnotation",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.SENDER_RECEIVER_ANNOTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getPortPrototypeSenderReceiverAnnotationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototypeSenderReceiverAnnotationOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newValue);
  // reference : dataElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_ELEMENT = "dataElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: senderReceiverAnnotation_dataElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_ELEMENT,"ar3x.swcomponenttemplate.applicationattributes.SenderReceiverAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.SENDER_RECEIVER_ANNOTATION_DATA_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * The instance of data element annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getDataElement();
  /**
   * The instance of data element annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
}
