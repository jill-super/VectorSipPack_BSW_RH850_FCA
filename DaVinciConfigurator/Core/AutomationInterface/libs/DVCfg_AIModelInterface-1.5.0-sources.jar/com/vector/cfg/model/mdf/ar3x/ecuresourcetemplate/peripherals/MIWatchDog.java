package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A form of interval timer, which is used to detect a possible malfunction of the processing unit. The timer is started as a countdown and has to be triggered within a specific time. Either the trigger only has to occur before the count-down runs out, or the trigger has to occur within a specific window before the timeout, therefore a trigger too early will also set off the watchdog. If the trigger is not correctly performed the watchdog will set off and will initiate an interrupt or perform a reset of the whole processing unit or ECU. The watchdog can be implemented in software or hardware and if the implementation is in hardware it can be integrated into the processing unit or connected externally. Depending on the complexity of the watchdog the interfacing is either a serial communication or some discrete I/O lines. Also the trigger itself can be just some digital peak or can be some calculated request-response mechanism. The actual handling of the watchdog has to be covered by some specific driver software. The watchdog will use at least an interrupt of the processing unit and also some peripheral connections for the control and set-up. To enable different operating modes of the processing unit and the ECU it is important to specify if the watchdog can be disabled (e.g. during flash programming).
 */
public interface MIWatchDog extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral, com.vector.cfg.model.mdf.commoncore.basetypes.MIHasThresholdValueIntegerItem
{
  public final static String CLASS_NAME = "WatchDog";
  // attribute : mode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODE = "mode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODE,"ar3x.ecuresourcetemplate.peripherals.WatchDog",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIWatchDogModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A Watchdog can be running in different modes. In normal mode must the watchdog be kicked within a certain maximum time. In the windowed mode there is also a lower limit of the time when the watchdog has to be kicked. In debug mode is the watchdog disabled. Sometimes it's also required that the watchdog can be disabled and enabled during software download. To ensure that this mode is not entered in normal operation there is often some kind of security procedure to enter the mode.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIWatchDogModeEnum getMode();
  /**
   * A Watchdog can be running in different modes. In normal mode must the watchdog be kicked within a certain maximum time. In the windowed mode there is also a lower limit of the time when the watchdog has to be kicked. In debug mode is the watchdog disabled. Sometimes it's also required that the watchdog can be disabled and enabled during software download. To ensure that this mode is not entered in normal operation there is often some kind of security procedure to enter the mode.
   * Attribute-Kind = versionAttribute   */
  public void setMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIWatchDogModeEnum newValue);
  // reference : clockSource generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLOCK_SOURCE = "clockSource";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: watchDog_clockSource_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLOCK_SOURCE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLOCK_SOURCE,"ar3x.ecuresourcetemplate.peripherals.WatchDog",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.WATCH_DOG_CLOCK_SOURCE_OWNER_RELATION_INFO;}};
  /**
   * The clock input to a timer can have different sources like the internal system clock or an external clock. If the clock is pre-scaled this information should be entered in the table.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef getClockSource();
  /**
   * The clock input to a timer can have different sources like the internal system clock or an external clock. If the clock is pre-scaled this information should be entered in the table.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClockSource(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef newValue);
}
