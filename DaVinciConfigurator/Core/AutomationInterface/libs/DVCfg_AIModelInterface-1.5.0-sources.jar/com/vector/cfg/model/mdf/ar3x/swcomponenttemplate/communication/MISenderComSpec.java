package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes for a sender port (P-Port and sender-receiver interface).
 */
public interface MISenderComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "SenderComSpec";
  // attribute : usesEndToEndProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String USES_END_TO_END_PROTECTION = "usesEndToEndProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo USES_END_TO_END_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,USES_END_TO_END_PROTECTION,"ar3x.swcomponenttemplate.communication.SenderComSpec",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection.
   * Attribute-Kind = versionAttribute   */
  public Boolean getUsesEndToEndProtection();
  /**
   * This indicates whether the corresponding dataElement shall be transmitted using end-to-end protection.
   * Attribute-Kind = versionAttribute   */
  public void setUsesEndToEndProtection(Boolean newValue);
  // reference : dataElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_ELEMENT = "dataElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: senderComSpec_dataElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_ELEMENT,"ar3x.swcomponenttemplate.communication.SenderComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.SENDER_COM_SPEC_DATA_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * Data element these quality of service attributes apply to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getDataElement();
  /**
   * Data element these quality of service attributes apply to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
  // reference : transmissionAcknowledge generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String TRANSMISSION_ACKNOWLEDGE = "transmissionAcknowledge";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: senderComSpec_transmissionAcknowledge_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo TRANSMISSION_ACKNOWLEDGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(TRANSMISSION_ACKNOWLEDGE,"ar3x.swcomponenttemplate.communication.SenderComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MITransmissionAcknowledgementRequest.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MITransmissionAcknowledgementRequest.SENDER_COM_SPEC_TRANSMISSION_ACKNOWLEDGE_OWNER_RELATION_INFO;}};
  /**
   * Requested transmission acknowledgement for data element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MITransmissionAcknowledgementRequest getTransmissionAcknowledge();
  /**
   * Requested transmission acknowledgement for data element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setTransmissionAcknowledge(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MITransmissionAcknowledgementRequest newValue);
}
