package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIAssemblyConnectorPrototypeRequester extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "AssemblyConnectorPrototypeRequester";
  // reference : assemblyConnectorPrototype_requester_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_OWNER = "assemblyConnectorPrototype_requester_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: requester
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_OWNER,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeRequester",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype.REQUESTER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype getAssemblyConnectorPrototypeRequesterOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeRequesterOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIAssemblyConnectorPrototype newValue);
  // reference : requesterRPortPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUESTER_RPORT_PROTOTYPE = "requesterRPortPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototypeRequester_requesterRPortPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUESTER_RPORT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUESTER_RPORT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeRequester",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef.ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_REQUESTER_RPORT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef getRequesterRPortPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRequesterRPortPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeARRef newValue);
  // reference : componentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_PROTOTYPE = "componentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: assemblyConnectorPrototypeRequester_componentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.AssemblyConnectorPrototypeRequester",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef getComponentPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef newValue);
}
