package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwDataDependencyArgsChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SwDataDependencyArgsChild";
  // reference : swDataDependencyArgs_swDataDependencyArgsChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEPENDENCY_ARGS_SW_DATA_DEPENDENCY_ARGS_CHILDREN_OWNER = "swDataDependencyArgs_swDataDependencyArgsChildren_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swDataDependencyArgsChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEPENDENCY_ARGS_SW_DATA_DEPENDENCY_ARGS_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEPENDENCY_ARGS_SW_DATA_DEPENDENCY_ARGS_CHILDREN_OWNER,"ar3x.commonstructure.datadefproperties.SwDataDependencyArgsChild",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgs.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgs.SW_DATA_DEPENDENCY_ARGS_CHILDREN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgs getSwDataDependencyArgsSwDataDependencyArgsChildrenOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDependencyArgsSwDataDependencyArgsChildrenOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgs newValue);
}
