package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation of a sender port, specifying properties of data elements that don't affect communication or generation of the RTE. 
 */
public interface MISenderAnnotation extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISenderReceiverAnnotation
{
  public final static String CLASS_NAME = "SenderAnnotation";
}
