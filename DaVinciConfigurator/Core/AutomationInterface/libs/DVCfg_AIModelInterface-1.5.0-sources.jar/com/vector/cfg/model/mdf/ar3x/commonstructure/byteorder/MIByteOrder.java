package com.vector.cfg.model.mdf.ar3x.commonstructure.byteorder;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element specifies the byte order of the parent element. The byte order is defined with the attribute TYPE. Possible values are:  * MOST-SIGNIFICANT-BYTE-FIRST  * MOST-SIGNIFICANT-BYTE-LAST
 */
public interface MIByteOrder extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ByteOrder";
  // attribute : content generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CONTENT = "content";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CONTENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CONTENT,"ar3x.commonstructure.byteorder.ByteOrder",null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This represents the actual setting of the byte order.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum getContent();
  /**
   * This represents the actual setting of the byte order.
   * Attribute-Kind = versionAttribute   */
  public void setContent(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum newValue);
  // reference : baseTypeDirectDefinition_byteOrder_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_DIRECT_DEFINITION_BYTE_ORDER_OWNER = "baseTypeDirectDefinition_byteOrder_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: byteOrder
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_DIRECT_DEFINITION_BYTE_ORDER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_DIRECT_DEFINITION_BYTE_ORDER_OWNER,"ar3x.commonstructure.byteorder.ByteOrder",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition.BYTE_ORDER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition getBaseTypeDirectDefinitionByteOrderOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeDirectDefinitionByteOrderOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDirectDefinition newValue);
}
