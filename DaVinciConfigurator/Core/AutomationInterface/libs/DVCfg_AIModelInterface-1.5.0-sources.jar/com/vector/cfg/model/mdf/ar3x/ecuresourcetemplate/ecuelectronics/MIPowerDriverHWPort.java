package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Define the option of a Power Driver that the output of a Power Driver can be superposed by a PWM signal asserted by a HW Element e.g. a microprocessor.  In most cases, the PWM signal is connected by a separate wire, even when the general control information are transmitted by a bus.
 */
public interface MIPowerDriverHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "PowerDriverHWPort";
  // attribute : pwmMaxFrequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PWM_MAX_FREQUENCY = "pwmMaxFrequency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PWM_MAX_FREQUENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PWM_MAX_FREQUENCY,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWPort",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * It defines the upper limit at which the device can fulfil the PWM capability. EMC and power dissipation are increasing almost exponential with the PWM frequency. Choosing PWM frequencies be aware that some effects can cause secondary effects, which can create a audible noise for the user, e.g. a PWM dimmed lamp can be noticed by the driver. Unit: Hz
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getPwmMaxFrequency();
  /**
   * It defines the upper limit at which the device can fulfil the PWM capability. EMC and power dissipation are increasing almost exponential with the PWM frequency. Choosing PWM frequencies be aware that some effects can cause secondary effects, which can create a audible noise for the user, e.g. a PWM dimmed lamp can be noticed by the driver. Unit: Hz
   * Attribute-Kind = versionAttribute   */
  public void setPwmMaxFrequency(java.math.BigDecimal newValue);
  // attribute : pwmMinOnTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PWM_MIN_ON_TIME = "pwmMinOnTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PWM_MIN_ON_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PWM_MIN_ON_TIME,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWPort",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the characteristic, that a Power Driver has to be on at least a minimum time in order to assure the function. Unit: s
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getPwmMinOnTime();
  /**
   * Defines the characteristic, that a Power Driver has to be on at least a minimum time in order to assure the function. Unit: s
   * Attribute-Kind = versionAttribute   */
  public void setPwmMinOnTime(java.math.BigDecimal newValue);
  // attribute : pwmMinOffTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PWM_MIN_OFF_TIME = "pwmMinOffTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PWM_MIN_OFF_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PWM_MIN_OFF_TIME,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWPort",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the characteristic, that a Power Driver has to be off at least a minimum time in order to assure the function. Unit: s
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getPwmMinOffTime();
  /**
   * Defines the characteristic, that a Power Driver has to be off at least a minimum time in order to assure the function. Unit: s
   * Attribute-Kind = versionAttribute   */
  public void setPwmMinOffTime(java.math.BigDecimal newValue);
}
