package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes for a server port (P-Port and client-server interface).
 */
public interface MIServerComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "ServerComSpec";
  // attribute : queueLength generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String QUEUE_LENGTH = "queueLength";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo QUEUE_LENGTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,QUEUE_LENGTH,"ar3x.swcomponenttemplate.communication.ServerComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Length of call queue on the mode user side. The queue is implemented by the RTE. The value must be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getQueueLength();
  /**
   * Length of call queue on the mode user side. The queue is implemented by the RTE. The value must be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
   * Attribute-Kind = versionAttribute   */
  public void setQueueLength(java.math.BigInteger newValue);
  // reference : operation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OPERATION = "operation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serverComSpec_operation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OPERATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OPERATION,"ar3x.swcomponenttemplate.communication.ServerComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef.SERVER_COM_SPEC_OPERATION_OWNER_RELATION_INFO;}};
  /**
   * Operation these communication attributes apply to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef getOperation();
  /**
   * Operation these communication attributes apply to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOperation(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef newValue);
}
