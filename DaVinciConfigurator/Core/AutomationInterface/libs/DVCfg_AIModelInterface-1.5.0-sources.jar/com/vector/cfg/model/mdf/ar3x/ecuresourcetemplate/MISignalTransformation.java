package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Signal Transformation defines the conversion of the signal attached to a HW Port (direction In) and a signal attached to a HW Port (direction Out). 
 */
public interface MISignalTransformation extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SignalTransformation";
  // reference : hWElement_signalTransformation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_SIGNAL_TRANSFORMATION_OWNER = "hWElement_signalTransformation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: signalTransformation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_SIGNAL_TRANSFORMATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_SIGNAL_TRANSFORMATION_OWNER,"ar3x.ecuresourcetemplate.SignalTransformation",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.SIGNAL_TRANSFORMATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement getHWElementSignalTransformationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementSignalTransformationOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement newValue);
  // reference : inputHwPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INPUT_HW_PORT = "inputHwPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: signalTransformation_inputHwPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INPUT_HW_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INPUT_HW_PORT,"ar3x.ecuresourcetemplate.SignalTransformation",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.SIGNAL_TRANSFORMATION_INPUT_HW_PORT_OWNER_RELATION_INFO;}};
  /**
   * The input port the signal transformation is refering to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef> getInputHwPort();
  // reference : outputHwPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OUTPUT_HW_PORT = "outputHwPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: signalTransformation_outputHwPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OUTPUT_HW_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OUTPUT_HW_PORT,"ar3x.ecuresourcetemplate.SignalTransformation",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.SIGNAL_TRANSFORMATION_OUTPUT_HW_PORT_OWNER_RELATION_INFO;}};
  /**
   * The output port the signal transformation is refering to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef> getOutputHwPort();
}
