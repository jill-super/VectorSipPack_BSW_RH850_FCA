package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This port is directed from the peripheral to the ecu electronics and communication.
 */
public interface MIPeripheralHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "PeripheralHWPort";
  // attribute : inversion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INVERSION = "inversion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo INVERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,INVERSION,"ar3x.ecuresourcetemplate.peripherals.PeripheralHWPort",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * An input or output can sometimes be programmed to invert the level of a signal.
   * Attribute-Kind = versionAttribute   */
  public Boolean getInversion();
  /**
   * An input or output can sometimes be programmed to invert the level of a signal.
   * Attribute-Kind = versionAttribute   */
  public void setInversion(Boolean newValue);
  // attribute : wakeUpCapability generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WAKE_UP_CAPABILITY = "wakeUpCapability";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WAKE_UP_CAPABILITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WAKE_UP_CAPABILITY,"ar3x.ecuresourcetemplate.peripherals.PeripheralHWPort",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The peripheral device has the feature to issue a wake-up event to the processing unit. Example: HW Port with Key-Wake-Up on a PU is still active while the PU is in stop mode and only partially supplied with power. The Key-Wake-Up reacts on any changes at the input of the HW Port with the activation of the power supply, the activation of the clock system and later the resuming of the software, which has to process the input of the HW Port.
   * Attribute-Kind = versionAttribute   */
  public Boolean getWakeUpCapability();
  /**
   * The peripheral device has the feature to issue a wake-up event to the processing unit. Example: HW Port with Key-Wake-Up on a PU is still active while the PU is in stop mode and only partially supplied with power. The Key-Wake-Up reacts on any changes at the input of the HW Port with the activation of the power supply, the activation of the clock system and later the resuming of the software, which has to process the input of the HW Port.
   * Attribute-Kind = versionAttribute   */
  public void setWakeUpCapability(Boolean newValue);
  // attribute : powerOnCapability generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String POWER_ON_CAPABILITY = "powerOnCapability";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo POWER_ON_CAPABILITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,POWER_ON_CAPABILITY,"ar3x.ecuresourcetemplate.peripherals.PeripheralHWPort",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The peripheral device has the feature to issue a Power On event to the ECU. Example: Some CAN bus transceivers have a dedicated low power voltage regulator and a feature, which allows to turn on the main voltage regulator of the ECU by detecting a bus activity. Example: A wired-or connection of a termination KL30 and KL15 can fulfil this requirement.
   * Attribute-Kind = versionAttribute   */
  public Boolean getPowerOnCapability();
  /**
   * The peripheral device has the feature to issue a Power On event to the ECU. Example: Some CAN bus transceivers have a dedicated low power voltage regulator and a feature, which allows to turn on the main voltage regulator of the ECU by detecting a bus activity. Example: A wired-or connection of a termination KL30 and KL15 can fulfil this requirement.
   * Attribute-Kind = versionAttribute   */
  public void setPowerOnCapability(Boolean newValue);
  // reference : buffer generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BUFFER = "buffer";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: peripheralHWPort_buffer_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BUFFER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BUFFER,"ar3x.ecuresourcetemplate.peripherals.PeripheralHWPort",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIBuffer.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIBuffer.PERIPHERAL_HWPORT_BUFFER_OWNER_RELATION_INFO;}};
  /**
   * Defines the number of elements that can be stored in an input or output buffer. A capture timer can for example have several registers to store the timer value when an external event has occurred.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIBuffer> getBuffer();
}
