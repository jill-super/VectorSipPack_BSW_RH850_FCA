package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes the implementation details of a class attribute which manifests itself as a calibration parameter.
 */
public interface MISwCalprmImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwCalprmImpl";
  // reference : swCalprmPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_PROTOTYPE = "swCalprmPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swCalprmImpl_swCalprmPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_PROTOTYPE,"ar3x.commonstructure.swclass.SwCalprmImpl",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototypeARRef.SW_CALPRM_IMPL_SW_CALPRM_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * This element describes the prototype declaration of a class attribute, which is used as a calibration parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototypeARRef getSwCalprmPrototype();
  /**
   * This element describes the prototype declaration of a class attribute, which is used as a calibration parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmPrototype(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototypeARRef newValue);
  // reference : hasSwCalprmImpl_swCalprmImpl_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SW_CALPRM_IMPL_SW_CALPRM_IMPL_OWNER = "hasSwCalprmImpl_swCalprmImpl_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swCalprmImpl
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SW_CALPRM_IMPL_SW_CALPRM_IMPL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SW_CALPRM_IMPL_SW_CALPRM_IMPL_OWNER,"ar3x.commonstructure.swclass.SwCalprmImpl",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl.SW_CALPRM_IMPL_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl getHasSwCalprmImplSwCalprmImplOwner();
  public void setHasSwCalprmImplSwCalprmImplOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl newValue);
}
