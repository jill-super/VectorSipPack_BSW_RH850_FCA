package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * An atomic software component is atomic in the sense that it cannot be further decomposed and distributed across multiple ECUs.
 */
public interface MIAtomicSoftwareComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType
{
  public final static String CLASS_NAME = "AtomicSoftwareComponentType";
  // reference : atomicSoftwareComponentTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ATOMIC_SOFTWARE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER = "atomicSoftwareComponentTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ATOMIC_SOFTWARE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ATOMIC_SOFTWARE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.AtomicSoftwareComponentType",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentTypeARRef> getAtomicSoftwareComponentTypeARRefRefTargetsOwner();
  // reference : symbolProps generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SYMBOL_PROPS = "symbolProps";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: atomicSoftwareComponentType_symbolProps_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SYMBOL_PROPS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SYMBOL_PROPS,"ar3x.swcomponenttemplate.components.AtomicSoftwareComponentType",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISymbolProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISymbolProps.ATOMIC_SOFTWARE_COMPONENT_TYPE_SYMBOL_PROPS_OWNER_RELATION_INFO;}};
  /**
   * This represents the SymbolProps for the AtomicSwComponentType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISymbolProps getSymbolProps();
  /**
   * This represents the SymbolProps for the AtomicSwComponentType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSymbolProps(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISymbolProps newValue);
}
