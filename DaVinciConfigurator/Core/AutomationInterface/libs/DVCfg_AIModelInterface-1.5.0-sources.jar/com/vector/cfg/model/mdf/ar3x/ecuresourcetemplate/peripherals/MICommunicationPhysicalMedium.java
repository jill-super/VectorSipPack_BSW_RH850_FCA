package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes the physical medium the bus is working on. In most cases it is not relevant for the SW to know about it, only for compatibility checking.
 */
public interface MICommunicationPhysicalMedium extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "CommunicationPhysicalMedium";
  // attribute : physicalMediumDataLines generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PHYSICAL_MEDIUM_DATA_LINES = "physicalMediumDataLines";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PHYSICAL_MEDIUM_DATA_LINES_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PHYSICAL_MEDIUM_DATA_LINES,"ar3x.ecuresourcetemplate.peripherals.CommunicationPhysicalMedium",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies how many data lines (ground not included) are used for the physical layer. Some bus systems can be implemented with e.g. 1, 2 or 4 data lines.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getPhysicalMediumDataLines();
  /**
   * Specifies how many data lines (ground not included) are used for the physical layer. Some bus systems can be implemented with e.g. 1, 2 or 4 data lines.
   * Attribute-Kind = versionAttribute   */
  public void setPhysicalMediumDataLines(java.math.BigInteger newValue);
  // attribute : physicalMediumStandard generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PHYSICAL_MEDIUM_STANDARD = "physicalMediumStandard";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PHYSICAL_MEDIUM_STANDARD_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PHYSICAL_MEDIUM_STANDARD,"ar3x.ecuresourcetemplate.peripherals.CommunicationPhysicalMedium",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The element protocol name defines the exact standardised protocol name. Examples are: - ISO 11519 for low-speed CAN - IEEE 802.11g for W-LAN (54 Mbit/s at 2,5 GHz) - IEEE-1394a for Firewire-400 
   * Attribute-Kind = versionAttribute   */
  public String getPhysicalMediumStandard();
  /**
   * The element protocol name defines the exact standardised protocol name. Examples are: - ISO 11519 for low-speed CAN - IEEE 802.11g for W-LAN (54 Mbit/s at 2,5 GHz) - IEEE-1394a for Firewire-400 
   * Attribute-Kind = versionAttribute   */
  public void setPhysicalMediumStandard(String newValue);
  // attribute : physicalMediumType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PHYSICAL_MEDIUM_TYPE = "physicalMediumType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PHYSICAL_MEDIUM_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PHYSICAL_MEDIUM_TYPE,"ar3x.ecuresourcetemplate.peripherals.CommunicationPhysicalMedium",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMediumEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the actual medium used for transmission. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMediumEnum getPhysicalMediumType();
  /**
   * Describes the actual medium used for transmission. 
   * Attribute-Kind = versionAttribute   */
  public void setPhysicalMediumType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMediumEnum newValue);
  // reference : communicationHWPort_physicalLayer_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_HWPORT_PHYSICAL_LAYER_OWNER = "communicationHWPort_physicalLayer_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: physicalLayer
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_HWPORT_PHYSICAL_LAYER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_HWPORT_PHYSICAL_LAYER_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationPhysicalMedium",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.PHYSICAL_LAYER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort getCommunicationHWPortPhysicalLayerOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationHWPortPhysicalLayerOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort newValue);
}
