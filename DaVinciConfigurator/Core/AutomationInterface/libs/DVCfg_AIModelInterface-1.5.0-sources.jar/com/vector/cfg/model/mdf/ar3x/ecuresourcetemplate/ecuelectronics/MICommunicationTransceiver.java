package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Communication Transceiver has to transfer and receive the data through the physical link and is the implementation of the OSI layer 1. Communication Transceivers have additional links to the controller/PU to support wake-up feature, enabling/disabling and error indication. 
 */
public interface MICommunicationTransceiver extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics, com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter, com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter
{
  public final static String CLASS_NAME = "CommunicationTransceiver";
  // attribute : architecture generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ARCHITECTURE = "architecture";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ARCHITECTURE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ARCHITECTURE,"ar3x.ecuresourcetemplate.ecuelectronics.CommunicationTransceiver",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Distinguish between different implementations.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum getArchitecture();
  /**
   * Distinguish between different implementations.
   * Attribute-Kind = versionAttribute   */
  public void setArchitecture(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum newValue);
  // reference : termination generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String TERMINATION = "termination";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationTransceiver_termination_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo TERMINATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(TERMINATION,"ar3x.ecuresourcetemplate.ecuelectronics.CommunicationTransceiver",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIBusTermination.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIBusTermination.COMMUNICATION_TRANSCEIVER_TERMINATION_OWNER_RELATION_INFO;}};
  /**
   * Description how this network node is terminated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIBusTermination getTermination();
  /**
   * Description how this network node is terminated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setTermination(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIBusTermination newValue);
}
