package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This expresses the abstract needs that a Software Component or Basic Software Module has on the configuration of an AUTOSAR Service to which it will be connected. "Abstract needs" means, that the model abstracts from the Configuration Paramaters of the underlying Basic Software.
 */
public interface MIServiceNeeds extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ServiceNeeds";
  // reference : bswModuleDependency_serviceItem_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DEPENDENCY_SERVICE_ITEM_OWNER = "bswModuleDependency_serviceItem_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: serviceItem
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DEPENDENCY_SERVICE_ITEM_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DEPENDENCY_SERVICE_ITEM_OWNER,"ar3x.commonstructure.serviceneeds.ServiceNeeds",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.SERVICE_ITEM_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency getBswModuleDependencyServiceItemOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDependencyServiceItemOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency newValue);
  // reference : internalBehavior_serviceNeeds_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INTERNAL_BEHAVIOR_SERVICE_NEEDS_OWNER = "internalBehavior_serviceNeeds_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: serviceNeeds
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INTERNAL_BEHAVIOR_SERVICE_NEEDS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INTERNAL_BEHAVIOR_SERVICE_NEEDS_OWNER,"ar3x.commonstructure.serviceneeds.ServiceNeeds",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIInternalBehavior.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIInternalBehavior.SERVICE_NEEDS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIInternalBehavior getInternalBehaviorServiceNeedsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInternalBehaviorServiceNeedsOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.MIInternalBehavior newValue);
}
