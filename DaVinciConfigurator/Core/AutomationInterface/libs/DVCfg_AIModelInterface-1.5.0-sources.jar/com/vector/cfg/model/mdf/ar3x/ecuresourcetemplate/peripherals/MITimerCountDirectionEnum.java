package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MITimerCountDirectionEnum implements javax.jmi.reflect.RefEnum
{
  UP("UP"),
  DOWN("DOWN"),
  SELECTABLE("SELECTABLE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "TimerCountDirectionEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MITimerCountDirectionEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
