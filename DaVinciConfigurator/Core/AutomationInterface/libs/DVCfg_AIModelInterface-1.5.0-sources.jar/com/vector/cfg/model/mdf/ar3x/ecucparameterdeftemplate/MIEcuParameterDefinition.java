package com.vector.cfg.model.mdf.ar3x.ecucparameterdeftemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This represents the anchor point of an ECU Configuration Parameter Definition within the AUTOSAR templates structure.
 */
public interface MIEcuParameterDefinition extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "EcuParameterDefinition";
  // reference : module generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODULE = "module";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ecuParameterDefinition_module_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODULE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODULE,"ar3x.ecucparameterdeftemplate.EcuParameterDefinition",133,null,com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDefARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDefARRef.ECU_PARAMETER_DEFINITION_MODULE_OWNER_RELATION_INFO;}};
  /**
   * References to  the module definitions of individual software modules.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDefARRef> getModule();
}
