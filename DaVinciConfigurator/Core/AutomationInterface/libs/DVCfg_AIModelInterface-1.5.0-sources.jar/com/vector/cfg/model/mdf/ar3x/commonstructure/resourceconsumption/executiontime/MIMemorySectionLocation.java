package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifes in which hardware ProvidedMemorySegment the softwareMemorySection is located.
 */
public interface MIMemorySectionLocation extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "MemorySectionLocation";
  // reference : executionTime_memorySectionLocation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXECUTION_TIME_MEMORY_SECTION_LOCATION_OWNER = "executionTime_memorySectionLocation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: memorySectionLocation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXECUTION_TIME_MEMORY_SECTION_LOCATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXECUTION_TIME_MEMORY_SECTION_LOCATION_OWNER,"ar3x.commonstructure.resourceconsumption.executiontime.MemorySectionLocation",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.MEMORY_SECTION_LOCATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime getExecutionTimeMemorySectionLocationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setExecutionTimeMemorySectionLocationOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime newValue);
  // reference : softwareMemorySection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SOFTWARE_MEMORY_SECTION = "softwareMemorySection";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memorySectionLocation_softwareMemorySection_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SOFTWARE_MEMORY_SECTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SOFTWARE_MEMORY_SECTION,"ar3x.commonstructure.resourceconsumption.executiontime.MemorySectionLocation",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef.MEMORY_SECTION_LOCATION_SOFTWARE_MEMORY_SECTION_OWNER_RELATION_INFO;}};
  /**
   * Reference to the MemorySection which is mapped on a certain hardware memory segment.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef getSoftwareMemorySection();
  /**
   * Reference to the MemorySection which is mapped on a certain hardware memory segment.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSoftwareMemorySection(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef newValue);
  // reference : providedMemory generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDED_MEMORY = "providedMemory";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memorySectionLocation_providedMemory_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_MEMORY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_MEMORY,"ar3x.commonstructure.resourceconsumption.executiontime.MemorySectionLocation",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef.MEMORY_SECTION_LOCATION_PROVIDED_MEMORY_OWNER_RELATION_INFO;}};
  /**
   * Reference to the hardware ProvidedMemorySegment.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef getProvidedMemory();
  /**
   * Reference to the hardware ProvidedMemorySegment.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProvidedMemory(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef newValue);
}
