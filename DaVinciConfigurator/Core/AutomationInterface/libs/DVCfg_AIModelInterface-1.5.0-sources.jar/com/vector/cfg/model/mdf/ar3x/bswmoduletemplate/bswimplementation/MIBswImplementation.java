package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswimplementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBswImplementation extends com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation, com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation
{
  public final static String CLASS_NAME = "BswImplementation";
  // attribute : arMajorVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AR_MAJOR_VERSION = "arMajorVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AR_MAJOR_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AR_MAJOR_VERSION,"ar3x.bswmoduletemplate.bswimplementation.BswImplementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Major version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getArMajorVersion();
  /**
   * Major version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public void setArMajorVersion(java.math.BigInteger newValue);
  // attribute : arMinorVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AR_MINOR_VERSION = "arMinorVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AR_MINOR_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AR_MINOR_VERSION,"ar3x.bswmoduletemplate.bswimplementation.BswImplementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minor version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getArMinorVersion();
  /**
   * Minor version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public void setArMinorVersion(java.math.BigInteger newValue);
  // attribute : arPatchVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AR_PATCH_VERSION = "arPatchVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AR_PATCH_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AR_PATCH_VERSION,"ar3x.bswmoduletemplate.bswimplementation.BswImplementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Patch level version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getArPatchVersion();
  /**
   * Patch level version number of AUTOSAR specification on which this implementation is based on.
   * Attribute-Kind = versionAttribute   */
  public void setArPatchVersion(java.math.BigInteger newValue);
  // reference : requiredHW generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUIRED_HW = "requiredHW";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswImplementation_requiredHW_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUIRED_HW_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUIRED_HW,"ar3x.bswmoduletemplate.bswimplementation.BswImplementation",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.BSW_IMPLEMENTATION_REQUIRED_HW_OWNER_RELATION_INFO;}};
  /**
   * Hardware resource required by this BswImplementation
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef> getRequiredHW();
  // reference : behavior generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BEHAVIOR = "behavior";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswImplementation_behavior_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BEHAVIOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BEHAVIOR,"ar3x.bswmoduletemplate.bswimplementation.BswImplementation",128,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef.BSW_IMPLEMENTATION_BEHAVIOR_OWNER_RELATION_INFO;}};
  /**
   * The behavior of this implementation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef getBehavior();
  /**
   * The behavior of this implementation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBehavior(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef newValue);
}
