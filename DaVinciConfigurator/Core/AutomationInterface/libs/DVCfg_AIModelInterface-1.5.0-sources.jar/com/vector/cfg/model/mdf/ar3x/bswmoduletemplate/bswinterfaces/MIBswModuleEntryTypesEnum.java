package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;
import javax.jmi.model.*;

public enum MIBswModuleEntryTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_MODULE_ENTRY("BSW-MODULE-ENTRY");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswinterfaces" );
    temp.add( "BswModuleEntryTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswModuleEntryTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
