package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Peripheral representing communication devices.
 */
public interface MICommunicationPeripheral extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral, com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter, com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter
{
  public final static String CLASS_NAME = "CommunicationPeripheral";
  // attribute : architecture generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ARCHITECTURE = "architecture";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ARCHITECTURE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ARCHITECTURE,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The implemented architecture
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum getArchitecture();
  /**
   * The implemented architecture
   * Attribute-Kind = versionAttribute   */
  public void setArchitecture(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationArchitectureEnum newValue);
  // attribute : monitor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MONITOR = "monitor";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MONITOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MONITOR,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The Element Monitor specifies if the device supports listen only. In this mode the device is passive on the bus and no acknowledgement or other responds are transmitted.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMonitor();
  /**
   * The Element Monitor specifies if the device supports listen only. In this mode the device is passive on the bus and no acknowledgement or other responds are transmitted.
   * Attribute-Kind = versionAttribute   */
  public void setMonitor(Boolean newValue);
  // attribute : timestampAvailable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TIMESTAMP_AVAILABLE = "timestampAvailable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TIMESTAMP_AVAILABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TIMESTAMP_AVAILABLE,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Is a timestamp for received frames available.
   * Attribute-Kind = versionAttribute   */
  public Boolean getTimestampAvailable();
  /**
   * Is a timestamp for received frames available.
   * Attribute-Kind = versionAttribute   */
  public void setTimestampAvailable(Boolean newValue);
  // reference : communicationPeripheralARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COMMUNICATION_PERIPHERAL_ARREF_REF_TARGETS_OWNER = "communicationPeripheralARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_PERIPHERAL_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_PERIPHERAL_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheralARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheralARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheralARRef> getCommunicationPeripheralARRefRefTargetsOwner();
  // reference : errorDetection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ERROR_DETECTION = "errorDetection";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationPeripheral_errorDetection_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ERROR_DETECTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ERROR_DETECTION,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection.COMMUNICATION_PERIPHERAL_ERROR_DETECTION_OWNER_RELATION_INFO;}};
  /**
   * Under certain conditions that are likely to appear in automotive applications, the transmission of information between communication endpoints might be unsafe because of particular sources of interference . It is possible to detect the presence of interference by means of error-detection codes (EDC) and at least partly overcome the problem by means of error-correction codes (ECC).  Error detection is a method that allows some communication errors to be detected. For this purpose the introduction of redundancy is required such that the information transmitted consists of more bits than the source of information. The extra bits are required for EDC and ECC.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection getErrorDetection();
  /**
   * Under certain conditions that are likely to appear in automotive applications, the transmission of information between communication endpoints might be unsafe because of particular sources of interference . It is possible to detect the presence of interference by means of error-detection codes (EDC) and at least partly overcome the problem by means of error-correction codes (ECC).  Error detection is a method that allows some communication errors to be detected. For this purpose the introduction of redundancy is required such that the information transmitted consists of more bits than the source of information. The extra bits are required for EDC and ECC.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setErrorDetection(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection newValue);
  // reference : hwPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HW_PORT = "hwPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationPeripheral_hwPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HW_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HW_PORT,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort.COMMUNICATION_PERIPHERAL_HW_PORT_OWNER_RELATION_INFO;}};
  /**
   * Describes the actual ommunication HW Port of this peripheral.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort> getHwPort();
  // reference : clock generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLOCK = "clock";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationPeripheral_clock_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLOCK_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLOCK,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef.COMMUNICATION_PERIPHERAL_CLOCK_OWNER_RELATION_INFO;}};
  /**
   * Reference to the clock description. This is used to calculate possible transmission rates.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef getClock();
  /**
   * Reference to the clock description. This is used to calculate possible transmission rates.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClock(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIClockARRef newValue);
  // reference : protocol generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROTOCOL = "protocol";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationPeripheral_protocol_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROTOCOL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROTOCOL,"ar3x.ecuresourcetemplate.peripherals.CommunicationPeripheral",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationProtocol.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationProtocol.COMMUNICATION_PERIPHERAL_PROTOCOL_OWNER_RELATION_INFO;}};
  /**
   * Describes which protocols are supported by this hardware.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationProtocol> getProtocol();
}
