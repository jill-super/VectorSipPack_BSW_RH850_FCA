package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Defines the object-oriented class-attributes containing the prototypes: <swVariablePrototypes> which denote attributes within the classes that are variables, <swCalprmPrototypes> which denote attributes within the classes that are calibration parameters , <SW-SERVICE-PROTOTYPES> which denote attributes within the classes that are services and <swClassPrototypes> which denote attributes within the classes that are class instances themselves.
 */
public interface MISwClassAttr extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwClassAttr";
  // reference : swCalprmPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_PROTOTYPE = "swCalprmPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swClassAttr_swCalprmPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_PROTOTYPE,"ar3x.commonstructure.swclass.SwClassAttr",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototype.SW_CLASS_ATTR_SW_CALPRM_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * This element describes the prototype declaration of a class attribute, which is used as a calibration parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmPrototype> getSwCalprmPrototype();
  // reference : swVariablePrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_VARIABLE_PROTOTYPE = "swVariablePrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swClassAttr_swVariablePrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_PROTOTYPE,"ar3x.commonstructure.swclass.SwClassAttr",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype.SW_CLASS_ATTR_SW_VARIABLE_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * This element describes the prototype declaration of a class attribute, which appears in the form of a variable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype> getSwVariablePrototype();
}
