package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSwVariableRefSwVariableRefProxy extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSwVariableRefSwVariableRefProxy";
  // reference : swVariableRef generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_VARIABLE_REF = "swVariableRef";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSwVariableRefSwVariableRefProxy_swVariableRef_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_REF_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_REF,"ar3x.commonstructure.datadictionaryproxies.HasSwVariableRefSwVariableRefProxy",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy.HAS_SW_VARIABLE_REF_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy getSwVariableRef();
  public void setSwVariableRef(com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy newValue);
}
