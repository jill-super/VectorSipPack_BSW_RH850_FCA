package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A generic code descriptor.
 */
public interface MICode extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "Code";
  // attribute : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPE = "type";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPE,"ar3x.commonstructure.implementation.Code",null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The type of described code.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum getType();
  /**
   * The type of described code.
   * Attribute-Kind = versionAttribute   */
  public void setType(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICodeTypeEnum newValue);
  // reference : implementation_codeDescriptor_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_CODE_DESCRIPTOR_OWNER = "implementation_codeDescriptor_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: codeDescriptor
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_CODE_DESCRIPTOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_CODE_DESCRIPTOR_OWNER,"ar3x.commonstructure.implementation.Code",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.CODE_DESCRIPTOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationCodeDescriptorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationCodeDescriptorOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);
  // reference : codeXfile generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CODE_XFILE = "codeXfile";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: code_codeXfile_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CODE_XFILE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CODE_XFILE,"ar3x.commonstructure.implementation.Code",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo.CODE_CODE_XFILE_OWNER_RELATION_INFO;}};
  /**
   * The files belonging to this code descriptor.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIXfileSo> getCodeXfile();
}
