package com.vector.cfg.model.mdf;

import ru.novosoft.mdf.ext.MDFOutermostPackage;

//CHECKSTYLE:OFF
/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
public interface MIOutermostPackage extends MDFOutermostPackage {

}
