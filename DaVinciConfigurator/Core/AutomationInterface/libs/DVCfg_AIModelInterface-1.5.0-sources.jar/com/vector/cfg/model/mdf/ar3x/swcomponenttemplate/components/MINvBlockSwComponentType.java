package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The NvBlockSwComponentType defines non volatile data which data can be shared between SwComponentPrototypes. The non volatile data of the NvBlockSwComponentType are accessible via provided and required ports. 
 */
public interface MINvBlockSwComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "NvBlockSwComponentType";
  // reference : nvBlockDescriptor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_BLOCK_DESCRIPTOR = "nvBlockDescriptor";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvBlockSwComponentType_nvBlockDescriptor_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_BLOCK_DESCRIPTOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_BLOCK_DESCRIPTOR,"ar3x.swcomponenttemplate.components.NvBlockSwComponentType",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor.NV_BLOCK_SW_COMPONENT_TYPE_NV_BLOCK_DESCRIPTOR_OWNER_RELATION_INFO;}};
  /**
   * Specification of the properties of exactly on NvBlock.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor> getNvBlockDescriptor();
}
