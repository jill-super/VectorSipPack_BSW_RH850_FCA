package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A cyclically recurring BSW event. The cyclic activity has to be implemented by the BSW Scheduler.
 */
public interface MIBswCyclicEvent extends com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent
{
  public final static String CLASS_NAME = "BswCyclicEvent";
  // attribute : cycleTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CYCLE_TIME = "cycleTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CYCLE_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CYCLE_TIME,"ar3x.bswmoduletemplate.bswbehavior.BswCyclicEvent",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Requirement for the cycle time (in seconds) by which this event is triggered.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getCycleTime();
  /**
   * Requirement for the cycle time (in seconds) by which this event is triggered.
   * Attribute-Kind = versionAttribute   */
  public void setCycleTime(java.math.BigDecimal newValue);
}
