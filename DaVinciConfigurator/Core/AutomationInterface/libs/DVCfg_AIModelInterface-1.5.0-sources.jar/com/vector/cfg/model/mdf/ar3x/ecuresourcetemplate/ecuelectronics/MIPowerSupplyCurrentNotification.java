package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIPowerSupplyCurrentNotification extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PowerSupplyCurrentNotification";
  // attribute : level generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LEVEL = "level";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LEVEL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LEVEL,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyCurrentNotification",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getLevel();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setLevel(java.math.BigDecimal newValue);
  // attribute : hysteresis generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HYSTERESIS = "hysteresis";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo HYSTERESIS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,HYSTERESIS,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyCurrentNotification",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getHysteresis();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setHysteresis(java.math.BigDecimal newValue);
  // reference : powerSupplyHWElement_overCurrentNotification_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String POWER_SUPPLY_HWELEMENT_OVER_CURRENT_NOTIFICATION_OWNER = "powerSupplyHWElement_overCurrentNotification_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: overCurrentNotification
  public static final ru.novosoft.mdf.impl.MDFRelationInfo POWER_SUPPLY_HWELEMENT_OVER_CURRENT_NOTIFICATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(POWER_SUPPLY_HWELEMENT_OVER_CURRENT_NOTIFICATION_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyCurrentNotification",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWElement.OVER_CURRENT_NOTIFICATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWElement getPowerSupplyHWElementOverCurrentNotificationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPowerSupplyHWElementOverCurrentNotificationOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyHWElement newValue);
  // reference : interrupt generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INTERRUPT = "interrupt";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerSupplyCurrentNotification_interrupt_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INTERRUPT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INTERRUPT,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyCurrentNotification",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.POWER_SUPPLY_CURRENT_NOTIFICATION_INTERRUPT_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef> getInterrupt();
}
