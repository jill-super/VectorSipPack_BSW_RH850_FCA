package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Rough estimation of the stack usage.
 */
public interface MIRoughEstimateStackUsage extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage
{
  public final static String CLASS_NAME = "RoughEstimateStackUsage";
  // attribute : memoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEMORY_CONSUMPTION = "memoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.stackusage.RoughEstimateStackUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Rough estimate of the stack usage.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMemoryConsumption();
  /**
   * Rough estimate of the stack usage.
   * Attribute-Kind = versionAttribute   */
  public void setMemoryConsumption(java.math.BigInteger newValue);
}
