package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Root element for the description of a single BSW module or BSW cluster. In case it describes a BSW module, the short name of this element equals the name of the BSW module.
 */
public interface MIBswModuleDescription extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "BswModuleDescription";
  // attribute : moduleId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODULE_ID = "moduleId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODULE_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODULE_ID,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescription",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Refers to the BSW Module Identifier defined by the AUTOSAR standard.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getModuleId();
  /**
   * Refers to the BSW Module Identifier defined by the AUTOSAR standard.
   * Attribute-Kind = versionAttribute   */
  public void setModuleId(java.math.BigInteger newValue);
  // reference : bswModuleDescriptionARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_MODULE_DESCRIPTION_ARREF_REF_TARGETS_OWNER = "bswModuleDescriptionARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescription",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef> getBswModuleDescriptionARRefRefTargetsOwner();
  // reference : bswModuleDependency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DEPENDENCY = "bswModuleDependency";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDescription_bswModuleDependency_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DEPENDENCY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DEPENDENCY,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescription",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.BSW_MODULE_DESCRIPTION_BSW_MODULE_DEPENDENCY_OWNER_RELATION_INFO;}};
  /**
   * Describes the dependency to another BSW module.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency> getBswModuleDependency();
  // reference : providedEntry generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDED_ENTRY = "providedEntry";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDescription_providedEntry_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_ENTRY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_ENTRY,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescription",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_DESCRIPTION_PROVIDED_ENTRY_OWNER_RELATION_INFO;}};
  /**
   * Specifies an entry provided by this module which can be called by other modules. This includes "main" functions and interrupt routines, but not callbacks (because the signature of a callback is defined by the calller).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getProvidedEntry();
  // reference : outgoingCallback generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OUTGOING_CALLBACK = "outgoingCallback";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDescription_outgoingCallback_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OUTGOING_CALLBACK_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OUTGOING_CALLBACK,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescription",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_DESCRIPTION_OUTGOING_CALLBACK_OWNER_RELATION_INFO;}};
  /**
   * Specifies a callback, which will be called from this module if required by  another module.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getOutgoingCallback();
}
