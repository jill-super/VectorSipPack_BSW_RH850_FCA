package com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior;
import javax.jmi.model.*;

public enum MIExclusiveAreaTypesEnum implements javax.jmi.reflect.RefEnum
{
  EXCLUSIVE_AREA("EXCLUSIVE-AREA");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "internalbehavior" );
    temp.add( "ExclusiveAreaTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIExclusiveAreaTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
