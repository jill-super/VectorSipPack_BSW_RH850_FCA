package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSwVariableImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSwVariableImpl";
  // reference : swVariableImpl generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_VARIABLE_IMPL = "swVariableImpl";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSwVariableImpl_swVariableImpl_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_IMPL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_IMPL,"ar3x.commonstructure.swclass.HasSwVariableImpl",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl.HAS_SW_VARIABLE_IMPL_SW_VARIABLE_IMPL_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl> getSwVariableImpl();
}
