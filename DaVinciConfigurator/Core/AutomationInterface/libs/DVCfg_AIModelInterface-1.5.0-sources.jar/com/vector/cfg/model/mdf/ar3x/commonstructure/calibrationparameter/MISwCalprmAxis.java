package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element specifies an individual input parameter axis (abscissa).
 */
public interface MISwCalprmAxis extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwCalprmAxis";
  // attribute : category generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CATEGORY = "category";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CATEGORY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CATEGORY,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MICalprmAxisCategoryEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This property specifies the category of a particular axis.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MICalprmAxisCategoryEnum getCategory();
  /**
   * This property specifies the category of a particular axis.
   * Attribute-Kind = versionAttribute   */
  public void setCategory(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MICalprmAxisCategoryEnum newValue);
  // attribute : displayFormat generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DISPLAY_FORMAT = "displayFormat";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DISPLAY_FORMAT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DISPLAY_FORMAT,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This property specifies how the axis values shall be displayed e.g. in documents or in measurement and calibration tools.
   * Attribute-Kind = versionAttribute   */
  public String getDisplayFormat();
  /**
   * This property specifies how the axis values shall be displayed e.g. in documents or in measurement and calibration tools.
   * Attribute-Kind = versionAttribute   */
  public void setDisplayFormat(String newValue);
  // attribute : swAxisIndex generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_AXIS_INDEX = "swAxisIndex";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_AXIS_INDEX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_AXIS_INDEX,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the index referring to the axis currently described, for which the contents is specified.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public String getSwAxisIndex();
  /**
   * Describes the index referring to the axis currently described, for which the contents is specified.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public void setSwAxisIndex(String newValue);
  // attribute : swCalibrationAccess generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_CALIBRATION_ACCESS = "swCalibrationAccess";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_CALIBRATION_ACCESS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_CALIBRATION_ACCESS,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the applicability of parameters and variables. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum getSwCalibrationAccess();
  /**
   * Describes the applicability of parameters and variables. 
   * Attribute-Kind = versionAttribute   */
  public void setSwCalibrationAccess(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwCalibrationAccessEnum newValue);
  // reference : swCalprmAxisSet_swCalprmAxis_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_SET_SW_CALPRM_AXIS_OWNER = "swCalprmAxisSet_swCalprmAxis_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swCalprmAxis
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_SET_SW_CALPRM_AXIS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_SET_SW_CALPRM_AXIS_OWNER,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet.SW_CALPRM_AXIS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet getSwCalprmAxisSetSwCalprmAxisOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisSetSwCalprmAxisOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisSet newValue);
  // reference : swCalprmAxisTypeProps generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_TYPE_PROPS = "swCalprmAxisTypeProps";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swCalprmAxis_swCalprmAxisTypeProps_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_TYPE_PROPS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_TYPE_PROPS,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps.SW_CALPRM_AXIS_SW_CALPRM_AXIS_TYPE_PROPS_OWNER_RELATION_INFO;}};
  /**
   * specific properties depending on the type of the axis.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps getSwCalprmAxisTypeProps();
  /**
   * specific properties depending on the type of the axis.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisTypeProps(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps newValue);
  // reference : baseType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE = "baseType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swCalprmAxis_baseType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE,"ar3x.commonstructure.calibrationparameter.SwCalprmAxis",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.SW_CALPRM_AXIS_BASE_TYPE_OWNER_RELATION_INFO;}};
  /**
   * The SwBaseType to be used for the axis.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef getBaseType();
  /**
   * The SwBaseType to be used for the axis.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef newValue);
}
