package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;
import javax.jmi.model.*;

public enum MIHandleInvalidType implements javax.jmi.reflect.RefEnum
{
  KEEP("KEEP"),
  REPLACE("REPLACE"),
  DONT_INVALIDATE("DONT-INVALIDATE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "communication" );
    temp.add( "HandleInvalidType" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHandleInvalidType(String literalName)
  {
    this.literalName = literalName;
  }
}
