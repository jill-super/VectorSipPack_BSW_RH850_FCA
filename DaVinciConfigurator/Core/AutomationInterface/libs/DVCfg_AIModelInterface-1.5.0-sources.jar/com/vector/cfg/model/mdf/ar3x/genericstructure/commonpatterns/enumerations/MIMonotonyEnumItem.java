package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIMonotonyEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "MonotonyEnumItem";
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.genericstructure.commonpatterns.enumerations.MonotonyEnumItem",null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIMonotonyEnum newValue);
}
