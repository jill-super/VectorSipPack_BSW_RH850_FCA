package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes in which mode the hardware is operating while providing the ExecutionTime.
 */
public interface MIHardwareConfiguration extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "HardwareConfiguration";
  // attribute : additionalInformation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ADDITIONAL_INFORMATION = "additionalInformation";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ADDITIONAL_INFORMATION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ADDITIONAL_INFORMATION,"ar3x.commonstructure.resourceconsumption.HardwareConfiguration",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies additional information on the HardwareConfiguration.
   * Attribute-Kind = versionAttribute   */
  public String getAdditionalInformation();
  /**
   * Specifies additional information on the HardwareConfiguration.
   * Attribute-Kind = versionAttribute   */
  public void setAdditionalInformation(String newValue);
  // attribute : processorMode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROCESSOR_MODE = "processorMode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PROCESSOR_MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PROCESSOR_MODE,"ar3x.commonstructure.resourceconsumption.HardwareConfiguration",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies in which mode the processor is operating.
   * Attribute-Kind = versionAttribute   */
  public String getProcessorMode();
  /**
   * Specifies in which mode the processor is operating.
   * Attribute-Kind = versionAttribute   */
  public void setProcessorMode(String newValue);
  // attribute : processorSpeed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROCESSOR_SPEED = "processorSpeed";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PROCESSOR_SPEED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PROCESSOR_SPEED,"ar3x.commonstructure.resourceconsumption.HardwareConfiguration",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the speed the processor is operating.
   * Attribute-Kind = versionAttribute   */
  public String getProcessorSpeed();
  /**
   * Specifies the speed the processor is operating.
   * Attribute-Kind = versionAttribute   */
  public void setProcessorSpeed(String newValue);
  // reference : hasHardwareConfiguration_hardwareConfiguration_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_HARDWARE_CONFIGURATION_HARDWARE_CONFIGURATION_OWNER = "hasHardwareConfiguration_hardwareConfiguration_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: hardwareConfiguration
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_HARDWARE_CONFIGURATION_HARDWARE_CONFIGURATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_HARDWARE_CONFIGURATION_HARDWARE_CONFIGURATION_OWNER,"ar3x.commonstructure.resourceconsumption.HardwareConfiguration",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration.HARDWARE_CONFIGURATION_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration getHasHardwareConfigurationHardwareConfigurationOwner();
  public void setHasHardwareConfigurationHardwareConfigurationOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration newValue);
}
