package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIFtChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "FtChild";
  // reference : ft_ftChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FT_FT_CHILDREN_OWNER = "ft_ftChildren_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: ftChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo FT_FT_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(FT_FT_CHILDREN_OWNER,"ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.FtChild",74,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFt.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFt.FT_CHILDREN_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFt getFtFtChildrenOwner();
  public void setFtFtChildrenOwner(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFt newValue);
}
