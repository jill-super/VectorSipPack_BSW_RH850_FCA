package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * An SwAxisGrouped is an axis which is shared between multiple calibration parameters.
 */
public interface MISwAxisGrouped extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwAxisGrouped";
  // reference : swCalprmAxisCommonAxis_swAxisGrouped_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_COMMON_AXIS_SW_AXIS_GROUPED_OWNER = "swCalprmAxisCommonAxis_swAxisGrouped_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swAxisGrouped
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_COMMON_AXIS_SW_AXIS_GROUPED_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_COMMON_AXIS_SW_AXIS_GROUPED_OWNER,"ar3x.commonstructure.axis.SwAxisGrouped",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisCommonAxis.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisCommonAxis.SW_AXIS_GROUPED_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisCommonAxis getSwCalprmAxisCommonAxisSwAxisGroupedOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisCommonAxisSwAxisGroupedOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisCommonAxis newValue);
  // reference : swCalprm generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM = "swCalprm";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisGrouped_swCalprm_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM,"ar3x.commonstructure.axis.SwAxisGrouped",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy.SW_AXIS_GROUPED_SW_CALPRM_OWNER_RELATION_INFO;}};
  /**
   * This property specifes the calibration parameter which serves as the input axis. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy getSwCalprm();
  /**
   * This property specifes the calibration parameter which serves as the input axis. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprm(com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwCalprmRefProxy newValue);
}
