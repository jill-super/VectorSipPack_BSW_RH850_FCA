package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs of a compoment or module on the configuration of OBD Service 08 (request control of on-board system) in relation to a particular test-Identifier (TID) supported by this component or module.
 */
public interface MIObdControlServiceNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ObdControlServiceNeeds";
  // attribute : testId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TEST_ID = "testId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TEST_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TEST_ID,"ar3x.commonstructure.serviceneeds.ObdControlServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Test Identifier (TID) according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getTestId();
  /**
   * Test Identifier (TID) according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public void setTestId(java.math.BigInteger newValue);
}
