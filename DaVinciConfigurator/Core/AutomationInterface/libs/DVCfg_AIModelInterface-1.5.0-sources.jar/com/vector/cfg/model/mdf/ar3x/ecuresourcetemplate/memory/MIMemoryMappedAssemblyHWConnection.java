package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This connection is used to connect Memory HWPort on the same hierarchical level (inside one HW Container).
 */
public interface MIMemoryMappedAssemblyHWConnection extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIAssemblyHWConnection
{
  public final static String CLASS_NAME = "MemoryMappedAssemblyHWConnection";
  // attribute : baseAddress generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BASE_ADDRESS = "baseAddress";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BASE_ADDRESS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BASE_ADDRESS,"ar3x.ecuresourcetemplate.memory.MemoryMappedAssemblyHWConnection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the base address of the memory within the ECU template. The same base address might be defined multiple times according to the access type and the architecture. A base address is uniquely bound to a defined memory segment.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getBaseAddress();
  /**
   * Defines the base address of the memory within the ECU template. The same base address might be defined multiple times according to the access type and the architecture. A base address is uniquely bound to a defined memory segment.
   * Attribute-Kind = versionAttribute   */
  public void setBaseAddress(java.math.BigInteger newValue);
  // attribute : byteOrder generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BYTE_ORDER = "byteOrder";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BYTE_ORDER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BYTE_ORDER,"ar3x.ecuresourcetemplate.memory.MemoryMappedAssemblyHWConnection",null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * When a PU stores data in a memory the ordering of the bytes can be done in two different ways. This storing scheme is normally fixed in the PU when more than one byte is stored in the memory. When the least significant byte is stored at the lowest address this architecture is called "mostSignificantByteLast" (aka little endian) and when the most significant byte is stored at the lowest address this is called "mostSignificantByteFirst" (aka big endian). Some CPU architectures like ARM and PowerPC can be configured to handle both little and big endian. This is called bi-endian. ByteOrder is very important when you communicate between different PUs or ECUs.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum getByteOrder();
  /**
   * When a PU stores data in a memory the ordering of the bytes can be done in two different ways. This storing scheme is normally fixed in the PU when more than one byte is stored in the memory. When the least significant byte is stored at the lowest address this architecture is called "mostSignificantByteLast" (aka little endian) and when the most significant byte is stored at the lowest address this is called "mostSignificantByteFirst" (aka big endian). Some CPU architectures like ARM and PowerPC can be configured to handle both little and big endian. This is called bi-endian. ByteOrder is very important when you communicate between different PUs or ECUs.
   * Attribute-Kind = versionAttribute   */
  public void setByteOrder(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum newValue);
  // attribute : cachable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CACHABLE = "cachable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CACHABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CACHABLE,"ar3x.ecuresourcetemplate.memory.MemoryMappedAssemblyHWConnection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A memory segment may be cacheable. This has to be defined in the description of the segment connection.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCachable();
  /**
   * A memory segment may be cacheable. This has to be defined in the description of the segment connection.
   * Attribute-Kind = versionAttribute   */
  public void setCachable(Boolean newValue);
  // reference : segmentUsage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SEGMENT_USAGE = "segmentUsage";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memoryMappedAssemblyHWConnection_segmentUsage_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SEGMENT_USAGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SEGMENT_USAGE,"ar3x.ecuresourcetemplate.memory.MemoryMappedAssemblyHWConnection",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnumItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnumItem.MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_SEGMENT_USAGE_OWNER_RELATION_INFO;}};
  /**
   * The segment usage is defined in the linker memory map. Usually it is fixed within an operation mode but different operations modes have different memory usage. The element segment usage contains the following attributes.  - Data: The attribute data is used for all kind of data: constant, variable, calibration, system initialisation, system configuration, etc.  - Code: The attribute code is used for the program code itself.  - Stack: Memory usable for a system or software stack is in some cases only available on limited number of segments within a PU.  - Boot: The boot memory is used to store program and data for the start up or test of an ECU. Within the boot program the basic ECU initialisation is performed. Furthermore some system maintenance programs, like the set-up for flash programming or loading of data via communication interface, can be part of the boot program.  Boot memory is in general not a subject of AUTOSAR SW.  -- Boot sector: Boot sector is the location in memory, preferable Flash or ROM, where the boot program is stored. The location of the boot sector might be dependant on the PU architecture as reset and interrupt vectors must be accessible during boot. The boot sector should be separated from other user accessible Flash or implemented as ROM. In Flash the boot sector should have the appropriate array size, some few kilobyte and provide protection mechanism against unintended erasure or system manipulation. A system may have different boot sectors, one accessible only for testing the PU during the manufacturing and configuration of the PU, in factory test mode or some initial program mode, and a user boot mode.  -- Mapping of boot sector: Mapping of the boot sector is useful to enhance the boot sequence and the release of the used resources during the boot phase at the later user mode, e.g. the use of reset vector and interrupt vector can be improved.
   */
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnumItem> getSegmentUsage();
  // reference : hwConnectionAccess generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HW_CONNECTION_ACCESS = "hwConnectionAccess";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memoryMappedAssemblyHWConnection_hwConnectionAccess_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HW_CONNECTION_ACCESS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HW_CONNECTION_ACCESS,"ar3x.ecuresourcetemplate.memory.MemoryMappedAssemblyHWConnection",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess.MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_HW_CONNECTION_ACCESS_OWNER_RELATION_INFO;}};
  /**
   * Access time is the timing characteristic for each access type. Access time at the Memory Mapped HW Port is only theoretical. The actual Access time is given in the Memory Mapped HW Connection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccess> getHwConnectionAccess();
}
