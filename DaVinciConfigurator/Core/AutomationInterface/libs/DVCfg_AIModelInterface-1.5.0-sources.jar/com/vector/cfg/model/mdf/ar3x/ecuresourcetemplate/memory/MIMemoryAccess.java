package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes the different possible kinds of access to the memory and the time these access takes.
 */
public interface MIMemoryAccess extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "MemoryAccess";
  // attribute : accessType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACCESS_TYPE = "accessType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACCESS_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACCESS_TYPE,"ar3x.ecuresourcetemplate.memory.MemoryAccess",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The element access type describes the different possible kinds of access to the memory. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum getAccessType();
  /**
   * The element access type describes the different possible kinds of access to the memory. 
   * Attribute-Kind = versionAttribute   */
  public void setAccessType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum newValue);
  // reference : memoryMappedAssemblyHWConnection_hwConnectionAccess_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_HW_CONNECTION_ACCESS_OWNER = "memoryMappedAssemblyHWConnection_hwConnectionAccess_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: hwConnectionAccess
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_HW_CONNECTION_ACCESS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_HW_CONNECTION_ACCESS_OWNER,"ar3x.ecuresourcetemplate.memory.MemoryAccess",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection.HW_CONNECTION_ACCESS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection getMemoryMappedAssemblyHWConnectionHwConnectionAccessOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setMemoryMappedAssemblyHWConnectionHwConnectionAccessOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection newValue);
  // reference : time generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String TIME = "time";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memoryAccess_time_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo TIME_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(TIME,"ar3x.ecuresourcetemplate.memory.MemoryAccess",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange.MEMORY_ACCESS_TIME_OWNER_RELATION_INFO;}};
  /**
   * Access time is the timing characteristic for each access type. Access time at the Memory Mapped HW Port is only theoretical. The actual Access time is given in the Memory Mapped HW Connection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange getTime();
  /**
   * Access time is the timing characteristic for each access type. Access time at the Memory Mapped HW Port is only theoretical. The actual Access time is given in the Memory Mapped HW Connection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setTime(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange newValue);
}
