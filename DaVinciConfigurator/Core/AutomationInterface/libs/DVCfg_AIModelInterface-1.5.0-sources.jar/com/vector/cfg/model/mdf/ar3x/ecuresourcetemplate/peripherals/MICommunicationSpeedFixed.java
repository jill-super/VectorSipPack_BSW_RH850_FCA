package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Fixed value for the communication speed.
 */
public interface MICommunicationSpeedFixed extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed
{
  public final static String CLASS_NAME = "CommunicationSpeedFixed";
  // attribute : fixSpeed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FIX_SPEED = "fixSpeed";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo FIX_SPEED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,FIX_SPEED,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeedFixed",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getFixSpeed();
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public void setFixSpeed(java.math.BigInteger newValue);
}
