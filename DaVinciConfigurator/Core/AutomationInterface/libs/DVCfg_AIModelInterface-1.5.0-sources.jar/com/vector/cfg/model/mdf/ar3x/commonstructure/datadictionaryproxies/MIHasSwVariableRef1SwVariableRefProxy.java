package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSwVariableRef1SwVariableRefProxy extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSwVariableRef1SwVariableRefProxy";
  // reference : swVariableRef1 generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_VARIABLE_REF1 = "swVariableRef1";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSwVariableRef1SwVariableRefProxy_swVariableRef1_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_REF1_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_REF1,"ar3x.commonstructure.datadictionaryproxies.HasSwVariableRef1SwVariableRefProxy",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy.HAS_SW_VARIABLE_REF1_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF1_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy> getSwVariableRef1();
}
