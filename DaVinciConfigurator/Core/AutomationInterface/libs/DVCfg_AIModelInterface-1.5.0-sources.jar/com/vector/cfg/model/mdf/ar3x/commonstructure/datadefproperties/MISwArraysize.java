package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The existence of SwArraysize turns the containing element into a multidimensional object. It is then possible to create arrays of variables, parameters etc. SwArraysize should not be used to imitate stereotypes such as curves or maps since these structures are modeled as separate elements, refer to SwCalprmAxisSet for an SwCalprm. Apart from that any array can be created.
 */
public interface MISwArraysize extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwArraysize";
  // reference : swDataDefProps_swValueBlockSize_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEF_PROPS_SW_VALUE_BLOCK_SIZE_OWNER = "swDataDefProps_swValueBlockSize_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swValueBlockSize
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_SW_VALUE_BLOCK_SIZE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS_SW_VALUE_BLOCK_SIZE_OWNER,"ar3x.commonstructure.datadefproperties.SwArraysize",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.SW_VALUE_BLOCK_SIZE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefPropsSwValueBlockSizeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDefPropsSwValueBlockSizeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
  // reference : swArraysizeChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_ARRAYSIZE_CHILDREN = "swArraysizeChildren";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swArraysize_swArraysizeChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_ARRAYSIZE_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_ARRAYSIZE_CHILDREN,"ar3x.commonstructure.datadefproperties.SwArraysize",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysizeChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysizeChild.SW_ARRAYSIZE_SW_ARRAYSIZE_CHILDREN_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysizeChild> getSwArraysizeChildren();
  // reference : swServiceArg_swArraysize_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_ARG_SW_ARRAYSIZE_OWNER = "swServiceArg_swArraysize_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swArraysize
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_ARG_SW_ARRAYSIZE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_ARG_SW_ARRAYSIZE_OWNER,"ar3x.commonstructure.datadefproperties.SwArraysize",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.SW_ARRAYSIZE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg getSwServiceArgSwArraysizeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceArgSwArraysizeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg newValue);
}
