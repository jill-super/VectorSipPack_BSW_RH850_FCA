package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompu extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Compu";
  // reference : compuMethod_compuPhysToInternal_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_METHOD_COMPU_PHYS_TO_INTERNAL_OWNER = "compuMethod_compuPhysToInternal_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: compuPhysToInternal
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_METHOD_COMPU_PHYS_TO_INTERNAL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_METHOD_COMPU_PHYS_TO_INTERNAL_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.Compu",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod.COMPU_PHYS_TO_INTERNAL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod getCompuMethodCompuPhysToInternalOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuMethodCompuPhysToInternalOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod newValue);
  // reference : compuMethod_compuInternalToPhys_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_METHOD_COMPU_INTERNAL_TO_PHYS_OWNER = "compuMethod_compuInternalToPhys_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: compuInternalToPhys
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_METHOD_COMPU_INTERNAL_TO_PHYS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_METHOD_COMPU_INTERNAL_TO_PHYS_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.Compu",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod.COMPU_INTERNAL_TO_PHYS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod getCompuMethodCompuInternalToPhysOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuMethodCompuInternalToPhysOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuMethod newValue);
  // reference : compuContentType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_CONTENT_TYPE = "compuContentType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compu_compuContentType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_CONTENT_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_CONTENT_TYPE,"ar3x.swcomponenttemplate.datatype.computationmethod.Compu",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuContent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuContent.COMPU_COMPU_CONTENT_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This specifies the details of the computation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuContent getCompuContentType();
  /**
   * This specifies the details of the computation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuContentType(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuContent newValue);
  // reference : compuDefaultValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_DEFAULT_VALUE = "compuDefaultValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compu_compuDefaultValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_DEFAULT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_DEFAULT_VALUE,"ar3x.swcomponenttemplate.datatype.computationmethod.Compu",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConst.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConst.COMPU_COMPU_DEFAULT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * This property can be used to specify an output value for a conversion formula, if the value to be converted lies outside the plausibility limit. Although this is possible for all conversion formulae, it is especially valid for variables with tabular conversion formulae.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConst getCompuDefaultValue();
  /**
   * This property can be used to specify an output value for a conversion formula, if the value to be converted lies outside the plausibility limit. Although this is possible for all conversion formulae, it is especially valid for variables with tabular conversion formulae.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuDefaultValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConst newValue);
}
