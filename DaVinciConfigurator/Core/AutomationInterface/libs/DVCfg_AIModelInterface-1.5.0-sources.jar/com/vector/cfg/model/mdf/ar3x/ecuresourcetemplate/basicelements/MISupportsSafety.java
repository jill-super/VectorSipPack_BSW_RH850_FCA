package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * In the current version of the ECU Resource Template the element SupportsSafety is optional. A HW Element uses this element if it provides a safety mechanism, otherwise this element is missing in the description of the HW Element.
 */
public interface MISupportsSafety extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SupportsSafety";
  // reference : hWElement_supportsSafety_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_SUPPORTS_SAFETY_OWNER = "hWElement_supportsSafety_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: supportsSafety
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_SUPPORTS_SAFETY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_SUPPORTS_SAFETY_OWNER,"ar3x.ecuresourcetemplate.basicelements.SupportsSafety",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.SUPPORTS_SAFETY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement getHWElementSupportsSafetyOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementSupportsSafetyOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement newValue);
}
