package com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Abstraction of executable code.
 */
public interface MIExecutableEntity extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ExecutableEntity";
  // reference : executableEntityARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXECUTABLE_ENTITY_ARREF_REF_TARGETS_OWNER = "executableEntityARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXECUTABLE_ENTITY_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXECUTABLE_ENTITY_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.internalbehavior.ExecutableEntity",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef> getExecutableEntityARRefRefTargetsOwner();
}
