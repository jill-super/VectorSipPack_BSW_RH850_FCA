package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Container for the properties of a grouped axis.
 */
public interface MISwCalprmAxisCommonAxis extends com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps
{
  public final static String CLASS_NAME = "SwCalprmAxisCommonAxis";
  // reference : swAxisGrouped generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_GROUPED = "swAxisGrouped";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swCalprmAxisCommonAxis_swAxisGrouped_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_GROUPED_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_GROUPED,"ar3x.commonstructure.calibrationparameter.SwCalprmAxisCommonAxis",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped.SW_CALPRM_AXIS_COMMON_AXIS_SW_AXIS_GROUPED_OWNER_RELATION_INFO;}};
  /**
   * The grouped axis contained.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped getSwAxisGrouped();
  /**
   * The grouped axis contained.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisGrouped(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped newValue);
}
