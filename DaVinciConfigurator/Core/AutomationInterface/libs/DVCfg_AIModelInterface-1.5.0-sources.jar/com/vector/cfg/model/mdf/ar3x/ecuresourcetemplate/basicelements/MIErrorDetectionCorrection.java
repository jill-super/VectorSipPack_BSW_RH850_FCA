package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Provides information on what extra bits are used for error detection and correction.
 */
public interface MIErrorDetectionCorrection extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ErrorDetectionCorrection";
  // attribute : extraBits generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXTRA_BITS = "extraBits";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo EXTRA_BITS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,EXTRA_BITS,"ar3x.ecuresourcetemplate.basicelements.ErrorDetectionCorrection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * How many extra bits are used for ensuring error detection and correction. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getExtraBits();
  /**
   * How many extra bits are used for ensuring error detection and correction. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public void setExtraBits(java.math.BigInteger newValue);
  // attribute : detectedBits generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DETECTED_BITS = "detectedBits";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DETECTED_BITS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DETECTED_BITS,"ar3x.ecuresourcetemplate.basicelements.ErrorDetectionCorrection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * How many bit errors can be reconginsed. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDetectedBits();
  /**
   * How many bit errors can be reconginsed. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public void setDetectedBits(java.math.BigInteger newValue);
  // attribute : correctedBits generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CORRECTED_BITS = "correctedBits";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CORRECTED_BITS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CORRECTED_BITS,"ar3x.ecuresourcetemplate.basicelements.ErrorDetectionCorrection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * How many error bits can be corrected. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getCorrectedBits();
  /**
   * How many error bits can be corrected. Unit: Bit
   * Attribute-Kind = versionAttribute   */
  public void setCorrectedBits(java.math.BigInteger newValue);
  // reference : communicationPeripheral_errorDetection_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_PERIPHERAL_ERROR_DETECTION_OWNER = "communicationPeripheral_errorDetection_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: errorDetection
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_PERIPHERAL_ERROR_DETECTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_PERIPHERAL_ERROR_DETECTION_OWNER,"ar3x.ecuresourcetemplate.basicelements.ErrorDetectionCorrection",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.ERROR_DETECTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral getCommunicationPeripheralErrorDetectionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationPeripheralErrorDetectionOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral newValue);
  // reference : providedMemorySegment_architecturalQuality_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDED_MEMORY_SEGMENT_ARCHITECTURAL_QUALITY_OWNER = "providedMemorySegment_architecturalQuality_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: architecturalQuality
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_MEMORY_SEGMENT_ARCHITECTURAL_QUALITY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_MEMORY_SEGMENT_ARCHITECTURAL_QUALITY_OWNER,"ar3x.ecuresourcetemplate.basicelements.ErrorDetectionCorrection",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegment.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegment.ARCHITECTURAL_QUALITY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegment getProvidedMemorySegmentArchitecturalQualityOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProvidedMemorySegmentArchitecturalQualityOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegment newValue);
}
