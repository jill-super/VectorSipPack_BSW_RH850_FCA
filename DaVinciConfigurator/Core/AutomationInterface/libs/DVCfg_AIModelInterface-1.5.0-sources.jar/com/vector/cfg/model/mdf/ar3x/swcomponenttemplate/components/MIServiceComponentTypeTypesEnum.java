package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;
import javax.jmi.model.*;

public enum MIServiceComponentTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SERVICE_COMPONENT_TYPE("SERVICE-COMPONENT-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "components" );
    temp.add( "ServiceComponentTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIServiceComponentTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
