package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Description of consumed resources by one implementation of a software.
 */
public interface MIResourceConsumption extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ResourceConsumption";
  // reference : implementation_resourceConsumption_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_RESOURCE_CONSUMPTION_OWNER = "implementation_resourceConsumption_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: resourceConsumption
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_RESOURCE_CONSUMPTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_RESOURCE_CONSUMPTION_OWNER,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.RESOURCE_CONSUMPTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationResourceConsumptionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationResourceConsumptionOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);
  // reference : objectFileSection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OBJECT_FILE_SECTION = "objectFileSection";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: resourceConsumption_objectFileSection_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OBJECT_FILE_SECTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OBJECT_FILE_SECTION,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySection.RESOURCE_CONSUMPTION_OBJECT_FILE_SECTION_OWNER_RELATION_INFO;}};
  /**
   * Provides additional information to the sections of the object-file containing the implementation of the SW-Component
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySection> getObjectFileSection();
  // reference : stackUsage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String STACK_USAGE = "stackUsage";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: resourceConsumption_stackUsage_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo STACK_USAGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(STACK_USAGE,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage.RESOURCE_CONSUMPTION_STACK_USAGE_OWNER_RELATION_INFO;}};
  /**
   * Collection of the stack memory usage for each runnable entity of this implementation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage> getStackUsage();
  // reference : heapUsage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HEAP_USAGE = "heapUsage";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: resourceConsumption_heapUsage_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HEAP_USAGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HEAP_USAGE,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage.RESOURCE_CONSUMPTION_HEAP_USAGE_OWNER_RELATION_INFO;}};
  /**
   * Collection of the heap memory allocated by this implementation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage> getHeapUsage();
  // reference : executionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXECUTION_TIME = "executionTime";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: resourceConsumption_executionTime_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXECUTION_TIME_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime.RESOURCE_CONSUMPTION_EXECUTION_TIME_OWNER_RELATION_INFO;}};
  /**
   * Collection of the execution time descriptions for the runnable entities of this implementation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime> getExecutionTime();
  // reference : ecuResourceEstimation_bswResourceEstimation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_RESOURCE_ESTIMATION_BSW_RESOURCE_ESTIMATION_OWNER = "ecuResourceEstimation_bswResourceEstimation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: bswResourceEstimation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_RESOURCE_ESTIMATION_BSW_RESOURCE_ESTIMATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_RESOURCE_ESTIMATION_BSW_RESOURCE_ESTIMATION_OWNER,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation.BSW_RESOURCE_ESTIMATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation getEcuResourceEstimationBswResourceEstimationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuResourceEstimationBswResourceEstimationOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation newValue);
  // reference : ecuResourceEstimation_rteResourceEstimation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_RESOURCE_ESTIMATION_RTE_RESOURCE_ESTIMATION_OWNER = "ecuResourceEstimation_rteResourceEstimation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rteResourceEstimation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_RESOURCE_ESTIMATION_RTE_RESOURCE_ESTIMATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_RESOURCE_ESTIMATION_RTE_RESOURCE_ESTIMATION_OWNER,"ar3x.commonstructure.resourceconsumption.ResourceConsumption",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation.RTE_RESOURCE_ESTIMATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation getEcuResourceEstimationRteResourceEstimationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuResourceEstimationRteResourceEstimationOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.MIEcuResourceEstimation newValue);
}
