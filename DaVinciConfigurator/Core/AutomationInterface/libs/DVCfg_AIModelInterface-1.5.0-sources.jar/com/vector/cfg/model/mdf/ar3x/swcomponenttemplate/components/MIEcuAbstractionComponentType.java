package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The ECUAbstraction is a special AtomicSoftwareComponent that sits between a component that wants to access ECUperiphery and the Microcontroller Abstraction. The EcuAbstractionComponentType introduces the possibility to link from the software representation to its hardware description provided by the ECU Resource Template.
 */
public interface MIEcuAbstractionComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "EcuAbstractionComponentType";
  // reference : hardwareElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HARDWARE_ELEMENT = "hardwareElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ecuAbstractionComponentType_hardwareElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HARDWARE_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HARDWARE_ELEMENT,"ar3x.swcomponenttemplate.components.EcuAbstractionComponentType",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.ECU_ABSTRACTION_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * Reference from the EcuAbstractionComponentType to the description of the used HWElements.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef> getHardwareElement();
  // reference : bswModuleDescription generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION = "bswModuleDescription";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ecuAbstractionComponentType_bswModuleDescription_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION,"ar3x.swcomponenttemplate.components.EcuAbstractionComponentType",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.ECU_ABSTRACTION_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO;}};
  /**
   * Reference from the EcuAbstractionComponentType to the Basic Software Module Description describing the BSW part of the ECU Abstraction Component.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef> getBswModuleDescription();
}
