package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the properties of a data object exchanged during the call of an SwService, e.g. an argument or a return value.
 */
public interface MISwServiceArg extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwServiceArg";
  // reference : swService_swServiceReturn_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_SW_SERVICE_RETURN_OWNER = "swService_swServiceReturn_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swServiceReturn
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_SW_SERVICE_RETURN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_SW_SERVICE_RETURN_OWNER,"ar3x.commonstructure.serviceprocesstask.SwServiceArg",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.SW_SERVICE_RETURN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService getSwServiceSwServiceReturnOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceSwServiceReturnOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService newValue);
  // reference : swService_swServiceArg_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_SW_SERVICE_ARG_OWNER = "swService_swServiceArg_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swServiceArg
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_SW_SERVICE_ARG_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_SW_SERVICE_ARG_OWNER,"ar3x.commonstructure.serviceprocesstask.SwServiceArg",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.SW_SERVICE_ARG_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService getSwServiceSwServiceArgOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceSwServiceArgOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService newValue);
  // reference : swArraysize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_ARRAYSIZE = "swArraysize";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swServiceArg_swArraysize_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_ARRAYSIZE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_ARRAYSIZE,"ar3x.commonstructure.serviceprocesstask.SwServiceArg",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.SW_SERVICE_ARG_SW_ARRAYSIZE_OWNER_RELATION_INFO;}};
  /**
   * The existence of <swArraysize> turns the parent element into a multidimensional object. It is then possible to create arrays of variables, parameters etc. <swArraysize> should ** to imitate stereotypes such as curves or maps since these structures are stored in the DTD itself as own elements, refer to <swCalprmAxisSet> for a <swCalprm>. Apart from that any array can be created.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize getSwArraysize();
  /**
   * The existence of <swArraysize> turns the parent element into a multidimensional object. It is then possible to create arrays of variables, parameters etc. <swArraysize> should ** to imitate stereotypes such as curves or maps since these structures are stored in the DTD itself as own elements, refer to <swCalprmAxisSet> for a <swCalprm>. Apart from that any array can be created.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwArraysize(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize newValue);
}
