package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes certain properties of the service implementation.
 */
public interface MISwServiceProps extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwServiceProps";
  // attribute : swImplPolicy generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_IMPL_POLICY = "swImplPolicy";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_IMPL_POLICY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_IMPL_POLICY,"ar3x.commonstructure.serviceprocesstask.SwServiceProps",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceImplPolicyEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Enables the specification of an implementation strategy. In this way, the direction of the implementation to come, can be specified in advance in an earlier phase.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceImplPolicyEnum getSwImplPolicy();
  /**
   * Enables the specification of an implementation strategy. In this way, the direction of the implementation to come, can be specified in advance in an earlier phase.
   * Attribute-Kind = versionAttribute   */
  public void setSwImplPolicy(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceImplPolicyEnum newValue);
  // attribute : swServiceReentrance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_SERVICE_REENTRANCE = "swServiceReentrance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_SERVICE_REENTRANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_SERVICE_REENTRANCE,"ar3x.commonstructure.serviceprocesstask.SwServiceProps",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceReentranceEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Reentrance enables or prohibits the service to be invoked again, before the service has finished and delivered a result. If the attribute is missing, then reentrance is prohibited.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceReentranceEnum getSwServiceReentrance();
  /**
   * Reentrance enables or prohibits the service to be invoked again, before the service has finished and delivered a result. If the attribute is missing, then reentrance is prohibited.
   * Attribute-Kind = versionAttribute   */
  public void setSwServiceReentrance(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceReentranceEnum newValue);
  // reference : swService_swServiceProps_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_SW_SERVICE_PROPS_OWNER = "swService_swServiceProps_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swServiceProps
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_SW_SERVICE_PROPS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_SW_SERVICE_PROPS_OWNER,"ar3x.commonstructure.serviceprocesstask.SwServiceProps",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.SW_SERVICE_PROPS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService getSwServiceSwServicePropsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceSwServicePropsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService newValue);
}
