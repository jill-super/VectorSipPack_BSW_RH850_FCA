package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * HW Element Actuator definition.
 */
public interface MIActuatorHW extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW
{
  public final static String CLASS_NAME = "ActuatorHW";
  // attribute : defaultPositionType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEFAULT_POSITION_TYPE = "defaultPositionType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEFAULT_POSITION_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEFAULT_POSITION_TYPE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the way the actuator is seen after power on. On Bi-Stable or Multistable actuators the software has to know the status of this device after reset or Power On. Each actuator has a control input that determines its behaviour
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum getDefaultPositionType();
  /**
   * Defines the way the actuator is seen after power on. On Bi-Stable or Multistable actuators the software has to know the status of this device after reset or Power On. Each actuator has a control input that determines its behaviour
   * Attribute-Kind = versionAttribute   */
  public void setDefaultPositionType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum newValue);
  // attribute : defaultPositionValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEFAULT_POSITION_VALUE = "defaultPositionValue";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEFAULT_POSITION_VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEFAULT_POSITION_VALUE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHW",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * If there is a specific default value is available. E.g. Valve status = off;
   * Attribute-Kind = versionAttribute   */
  public String getDefaultPositionValue();
  /**
   * If there is a specific default value is available. E.g. Valve status = off;
   * Attribute-Kind = versionAttribute   */
  public void setDefaultPositionValue(String newValue);
  // attribute : electricalType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ELECTRICAL_TYPE = "electricalType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ELECTRICAL_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ELECTRICAL_TYPE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwElectricalTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the most typical electrical behaviour of the system. This information is necessary for the ECU generation process and for tools which check for later interaction of the different component. (avoid resonance's, planning of the ECU power management).
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwElectricalTypeEnum getElectricalType();
  /**
   * Defines the most typical electrical behaviour of the system. This information is necessary for the ECU generation process and for tools which check for later interaction of the different component. (avoid resonance's, planning of the ECU power management).
   * Attribute-Kind = versionAttribute   */
  public void setElectricalType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwElectricalTypeEnum newValue);
  // attribute : endurance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ENDURANCE = "endurance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ENDURANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ENDURANCE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHW",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Number of activation cycles the actuator is designed for.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getEndurance();
  /**
   * Number of activation cycles the actuator is designed for.
   * Attribute-Kind = versionAttribute   */
  public void setEndurance(java.math.BigInteger newValue);
  // attribute : movement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MOVEMENT = "movement";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MOVEMENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MOVEMENT,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the way the movement is controlled by AUTOSAR. Positional feedback can be provided by the actuator by the conglomeration of the requisite actuator and sensor primitives. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum getMovement();
  /**
   * Defines the way the movement is controlled by AUTOSAR. Positional feedback can be provided by the actuator by the conglomeration of the requisite actuator and sensor primitives. 
   * Attribute-Kind = versionAttribute   */
  public void setMovement(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwMovementEnum newValue);
}
