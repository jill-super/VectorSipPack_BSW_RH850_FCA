package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The simplest form is an array of directly coupled D-flip flops, which build up a shift register, with separate output from each stage, thus forming a time-register. A clock signal at the input increments the value of the register. Some cases uses some logic in combination of the shift register in order to form a special adopted representation of the information or to fulfil special requirements.
 */
public interface MITimer extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIGeneralPurposeTimer
{
  public final static String CLASS_NAME = "Timer";
  // attribute : canBeReInit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CAN_BE_RE_INIT = "canBeReInit";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CAN_BE_RE_INIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CAN_BE_RE_INIT,"ar3x.ecuresourcetemplate.peripherals.Timer",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if the peripheral can automatically be reset during operation.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCanBeReInit();
  /**
   * Defines if the peripheral can automatically be reset during operation.
   * Attribute-Kind = versionAttribute   */
  public void setCanBeReInit(Boolean newValue);
  // attribute : countDirection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COUNT_DIRECTION = "countDirection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COUNT_DIRECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COUNT_DIRECTION,"ar3x.ecuresourcetemplate.peripherals.Timer",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The direction defines if the counter of a timer counts up, down or if it can be selected.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum getCountDirection();
  /**
   * The direction defines if the counter of a timer counts up, down or if it can be selected.
   * Attribute-Kind = versionAttribute   */
  public void setCountDirection(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerCountDirectionEnum newValue);
  // attribute : mode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODE = "mode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODE,"ar3x.ecuresourcetemplate.peripherals.Timer",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * single: The timer is counted from a defined start value to a defined end value and then stopped.  continuous: The timer is counted from a defined start value to a defined end value and then restarted with the start value. free: The timer is counted always to the available maximum value of the timer structure, then a wrap around occurs and the timer starts again from the HW defined startpoint; e.g. a 16 bit Timer counts from 0(hex)....0FFFF(hex), then after the overflow again from 0(hex)....0FFFF(hex).
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerModeEnum getMode();
  /**
   * single: The timer is counted from a defined start value to a defined end value and then stopped.  continuous: The timer is counted from a defined start value to a defined end value and then restarted with the start value. free: The timer is counted always to the available maximum value of the timer structure, then a wrap around occurs and the timer starts again from the HW defined startpoint; e.g. a 16 bit Timer counts from 0(hex)....0FFFF(hex), then after the overflow again from 0(hex)....0FFFF(hex).
   * Attribute-Kind = versionAttribute   */
  public void setMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MITimerModeEnum newValue);
}
