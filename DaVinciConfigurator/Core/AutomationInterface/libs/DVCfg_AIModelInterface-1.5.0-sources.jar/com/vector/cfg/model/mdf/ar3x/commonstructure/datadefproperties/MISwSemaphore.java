package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element denotes a variable which servers as a semaphore for a particular resource which is specified in the surrounding data object, e.g. SwDataDefProps.
 */
public interface MISwSemaphore extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy
{
  public final static String CLASS_NAME = "SwSemaphore";
}
