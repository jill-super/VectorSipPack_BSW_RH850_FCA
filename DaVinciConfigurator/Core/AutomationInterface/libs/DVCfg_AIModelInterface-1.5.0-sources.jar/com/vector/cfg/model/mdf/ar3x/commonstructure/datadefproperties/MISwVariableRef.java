package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class establishes a reference to a variable. It is mainly introduced by the reverse engineering tool. 
 */
public interface MISwVariableRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy
{
  public final static String CLASS_NAME = "SwVariableRef";
  // reference : swDataDefProps_swHostVariable_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEF_PROPS_SW_HOST_VARIABLE_OWNER = "swDataDefProps_swHostVariable_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swHostVariable
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_SW_HOST_VARIABLE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS_SW_HOST_VARIABLE_OWNER,"ar3x.commonstructure.datadefproperties.SwVariableRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.SW_HOST_VARIABLE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefPropsSwHostVariableOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDefPropsSwHostVariableOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
}
