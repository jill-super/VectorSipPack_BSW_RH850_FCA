package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;
import javax.jmi.model.*;

public enum MISwBaseTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_BASE_TYPE("SW-BASE-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "basetypes" );
    temp.add( "SwBaseTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwBaseTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
