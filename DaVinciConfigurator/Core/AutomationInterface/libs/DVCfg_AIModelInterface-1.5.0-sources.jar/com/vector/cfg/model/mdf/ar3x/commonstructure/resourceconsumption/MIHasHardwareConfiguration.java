package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasHardwareConfiguration extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasHardwareConfiguration";
  // reference : hardwareConfiguration generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HARDWARE_CONFIGURATION = "hardwareConfiguration";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasHardwareConfiguration_hardwareConfiguration_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HARDWARE_CONFIGURATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HARDWARE_CONFIGURATION,"ar3x.commonstructure.resourceconsumption.HasHardwareConfiguration",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHardwareConfiguration.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHardwareConfiguration.HAS_HARDWARE_CONFIGURATION_HARDWARE_CONFIGURATION_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHardwareConfiguration getHardwareConfiguration();
  public void setHardwareConfiguration(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHardwareConfiguration newValue);
}
