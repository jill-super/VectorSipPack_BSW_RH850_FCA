package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes the prototype declaration of a class attribute, which appears in the form of a variable.
 */
public interface MISwVariablePrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant.MIIsSyscond, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwVariablePrototype";
  // reference : swVariablePrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_VARIABLE_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "swVariablePrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.swclass.SwVariablePrototype",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeARRef> getSwVariablePrototypeARRefRefTargetsOwner();
  // reference : swClassAttr_swVariablePrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_ATTR_SW_VARIABLE_PROTOTYPE_OWNER = "swClassAttr_swVariablePrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swVariablePrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_ATTR_SW_VARIABLE_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_ATTR_SW_VARIABLE_PROTOTYPE_OWNER,"ar3x.commonstructure.swclass.SwVariablePrototype",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttr.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttr.SW_VARIABLE_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttr getSwClassAttrSwVariablePrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwClassAttrSwVariablePrototypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttr newValue);
}
