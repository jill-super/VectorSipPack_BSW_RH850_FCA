package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes for both sender /server port (P-Port and sender-receiver interface).
 */
public interface MIModeSwitchComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "ModeSwitchComSpec";
  // attribute : queueLength generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String QUEUE_LENGTH = "queueLength";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo QUEUE_LENGTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,QUEUE_LENGTH,"ar3x.swcomponenttemplate.communication.ModeSwitchComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Length of call queue on the mode user side. The queue is implemented by the RTE. The value must be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getQueueLength();
  /**
   * Length of call queue on the mode user side. The queue is implemented by the RTE. The value must be greater or equal to 1. Setting the value of queueLength to 1 implies that incoming requests are rejected while another request that arrived earlier is being processed.
   * Attribute-Kind = versionAttribute   */
  public void setQueueLength(java.math.BigInteger newValue);
  // reference : modeGroup generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODE_GROUP = "modeGroup";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: modeSwitchComSpec_modeGroup_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODE_GROUP_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODE_GROUP,"ar3x.swcomponenttemplate.communication.ModeSwitchComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIModeDeclarationGroupPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIModeDeclarationGroupPrototypeARRef.MODE_SWITCH_COM_SPEC_MODE_GROUP_OWNER_RELATION_INFO;}};
  /**
   * Mode Declaration Group (of the same Port Interface) to which these communication attributes apply.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIModeDeclarationGroupPrototypeARRef getModeGroup();
  /**
   * Mode Declaration Group (of the same Port Interface) to which these communication attributes apply.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setModeGroup(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIModeDeclarationGroupPrototypeARRef newValue);
  // reference : modeSwitchedAck generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODE_SWITCHED_ACK = "modeSwitchedAck";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: modeSwitchComSpec_modeSwitchedAck_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODE_SWITCHED_ACK_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODE_SWITCHED_ACK,"ar3x.swcomponenttemplate.communication.ModeSwitchComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIModeSwitchedAckRequest.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIModeSwitchedAckRequest.MODE_SWITCH_COM_SPEC_MODE_SWITCHED_ACK_OWNER_RELATION_INFO;}};
  /**
   * This represents the ModeSwitchedAckrequest owned by the ModeSwitchComSoec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIModeSwitchedAckRequest getModeSwitchedAck();
  /**
   * This represents the ModeSwitchedAckrequest owned by the ModeSwitchComSoec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setModeSwitchedAck(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIModeSwitchedAckRequest newValue);
}
