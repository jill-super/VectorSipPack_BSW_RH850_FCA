package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class represents a single API entry (C-function prototype) into the BSW module or cluster.  The name of the C-function is equal to the short name of this element with one exception: In case of multiple instances of a module on the same CPU, special rules for "infixes" apply, see description of class BswImplementation. 
 */
public interface MIBswModuleEntry extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService
{
  public final static String CLASS_NAME = "BswModuleEntry";
  // attribute : serviceId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SERVICE_ID = "serviceId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SERVICE_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SERVICE_ID,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntry",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Refers to the service identifier of the Standardized Interfaces of AUTOSAR basic software.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getServiceId();
  /**
   * Refers to the service identifier of the Standardized Interfaces of AUTOSAR basic software.
   * Attribute-Kind = versionAttribute   */
  public void setServiceId(java.math.BigInteger newValue);
  // attribute : isSynchronous generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String IS_SYNCHRONOUS = "isSynchronous";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo IS_SYNCHRONOUS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,IS_SYNCHRONOUS,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntry",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * true: This calls a synchronous service, i.e. the service is completed when the call returns. false: The service (on semantical level) may not be complete when the call returns.
   * Attribute-Kind = versionAttribute   */
  public Boolean getIsSynchronous();
  /**
   * true: This calls a synchronous service, i.e. the service is completed when the call returns. false: The service (on semantical level) may not be complete when the call returns.
   * Attribute-Kind = versionAttribute   */
  public void setIsSynchronous(Boolean newValue);
  // attribute : callType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CALL_TYPE = "callType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CALL_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CALL_TYPE,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntry",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * the type of call associated with this service
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType getCallType();
  /**
   * the type of call associated with this service
   * Attribute-Kind = versionAttribute   */
  public void setCallType(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswCallType newValue);
  // attribute : executionContext generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXECUTION_CONTEXT = "executionContext";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo EXECUTION_CONTEXT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,EXECUTION_CONTEXT,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntry",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the excution context which is required (in case of entries into this module) or guaranteed (in case of entries called from this module) for this service.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext getExecutionContext();
  /**
   * Specifies the excution context which is required (in case of entries into this module) or guaranteed (in case of entries called from this module) for this service.
   * Attribute-Kind = versionAttribute   */
  public void setExecutionContext(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswExecutionContext newValue);
  // reference : bswModuleEntryARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_MODULE_ENTRY_ARREF_REF_TARGETS_OWNER = "bswModuleEntryARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_ENTRY_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_ENTRY_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntry",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getBswModuleEntryARRefRefTargetsOwner();
}
