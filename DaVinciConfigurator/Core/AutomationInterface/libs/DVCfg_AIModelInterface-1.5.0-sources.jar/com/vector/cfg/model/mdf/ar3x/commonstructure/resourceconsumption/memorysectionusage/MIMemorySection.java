package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The MemorySection provides description of the Memory Sections used in the Implementation.
 */
public interface MIMemorySection extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.commoncore.basetypes.MIHasOptionStringItem
{
  public final static String CLASS_NAME = "MemorySection";
  // attribute : alignment generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ALIGNMENT = "alignment";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ALIGNMENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ALIGNMENT,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The alignment (typically 1, 2, 4,...)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getAlignment();
  /**
   * The alignment (typically 1, 2, 4,...)
   * Attribute-Kind = versionAttribute   */
  public void setAlignment(java.math.BigInteger newValue);
  // attribute : sectionName generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SECTION_NAME = "sectionName";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SECTION_NAME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SECTION_NAME,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This is the name of the section in the Implementation.
   * Attribute-Kind = versionAttribute   */
  public String getSectionName();
  /**
   * This is the name of the section in the Implementation.
   * Attribute-Kind = versionAttribute   */
  public void setSectionName(String newValue);
  // attribute : sectionType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SECTION_TYPE = "sectionType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SECTION_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SECTION_TYPE,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Memory section type of the described MemorySection.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionType getSectionType();
  /**
   * Memory section type of the described MemorySection.
   * Attribute-Kind = versionAttribute   */
  public void setSectionType(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionType newValue);
  // attribute : size generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SIZE = "size";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SIZE,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The size in bytes of the section.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSize();
  /**
   * The size in bytes of the section.
   * Attribute-Kind = versionAttribute   */
  public void setSize(java.math.BigInteger newValue);
  // reference : memorySectionARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEMORY_SECTION_ARREF_REF_TARGETS_OWNER = "memorySectionARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_SECTION_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_SECTION_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.memorysectionusage.MIMemorySectionARRef> getMemorySectionARRefRefTargetsOwner();
  // reference : resourceConsumption_objectFileSection_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RESOURCE_CONSUMPTION_OBJECT_FILE_SECTION_OWNER = "resourceConsumption_objectFileSection_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: objectFileSection
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RESOURCE_CONSUMPTION_OBJECT_FILE_SECTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RESOURCE_CONSUMPTION_OBJECT_FILE_SECTION_OWNER,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.OBJECT_FILE_SECTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption getResourceConsumptionObjectFileSectionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setResourceConsumptionObjectFileSectionOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption newValue);
  // reference : memorySwAddrMethod generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MEMORY_SW_ADDR_METHOD = "memorySwAddrMethod";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: memorySection_memorySwAddrMethod_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_SW_ADDR_METHOD_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_SW_ADDR_METHOD,"ar3x.commonstructure.resourceconsumption.memorysectionusage.MemorySection",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.MEMORY_SECTION_MEMORY_SW_ADDR_METHOD_OWNER_RELATION_INFO;}};
  /**
   * This assocation indicates all objects (e.g. calibration parameters, data element prototypes) being assigned to this SwAddrMethod shall be placed in this memory Section. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef> getMemorySwAddrMethod();
}
