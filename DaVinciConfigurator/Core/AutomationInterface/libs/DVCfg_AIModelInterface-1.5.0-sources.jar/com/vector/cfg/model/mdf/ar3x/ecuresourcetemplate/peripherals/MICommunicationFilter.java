package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes the amount and the size of the communication filters. These can be used as acceptance or rejection filters.
 */
public interface MICommunicationFilter extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "CommunicationFilter";
  // attribute : filterCount generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FILTER_COUNT = "filterCount";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo FILTER_COUNT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,FILTER_COUNT,"ar3x.ecuresourcetemplate.peripherals.CommunicationFilter",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * How many acceptance filters are availabe.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getFilterCount();
  /**
   * How many acceptance filters are availabe.
   * Attribute-Kind = versionAttribute   */
  public void setFilterCount(java.math.BigInteger newValue);
  // attribute : filterWidth generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FILTER_WIDTH = "filterWidth";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo FILTER_WIDTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,FILTER_WIDTH,"ar3x.ecuresourcetemplate.peripherals.CommunicationFilter",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Which bit-size do the filters have.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getFilterWidth();
  /**
   * Which bit-size do the filters have.
   * Attribute-Kind = versionAttribute   */
  public void setFilterWidth(java.math.BigInteger newValue);
  // attribute : wildCards generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WILD_CARDS = "wildCards";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WILD_CARDS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WILD_CARDS,"ar3x.ecuresourcetemplate.peripherals.CommunicationFilter",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Is it possible to provide wildcard identifires allowing to specify ranges for filtering.
   * Attribute-Kind = versionAttribute   */
  public Boolean getWildCards();
  /**
   * Is it possible to provide wildcard identifires allowing to specify ranges for filtering.
   * Attribute-Kind = versionAttribute   */
  public void setWildCards(Boolean newValue);
  // reference : hasRejectionFilterCommunicationFilter_rejectionFilter_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_REJECTION_FILTER_COMMUNICATION_FILTER_REJECTION_FILTER_OWNER = "hasRejectionFilterCommunicationFilter_rejectionFilter_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rejectionFilter
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_REJECTION_FILTER_COMMUNICATION_FILTER_REJECTION_FILTER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_REJECTION_FILTER_COMMUNICATION_FILTER_REJECTION_FILTER_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationFilter",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter.REJECTION_FILTER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter getHasRejectionFilterCommunicationFilterRejectionFilterOwner();
  public void setHasRejectionFilterCommunicationFilterRejectionFilterOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasRejectionFilterCommunicationFilter newValue);
  // reference : hasAcceptanceFilterCommunicationFilter_acceptanceFilter_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_ACCEPTANCE_FILTER_COMMUNICATION_FILTER_ACCEPTANCE_FILTER_OWNER = "hasAcceptanceFilterCommunicationFilter_acceptanceFilter_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: acceptanceFilter
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_ACCEPTANCE_FILTER_COMMUNICATION_FILTER_ACCEPTANCE_FILTER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_ACCEPTANCE_FILTER_COMMUNICATION_FILTER_ACCEPTANCE_FILTER_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationFilter",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter.ACCEPTANCE_FILTER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter getHasAcceptanceFilterCommunicationFilterAcceptanceFilterOwner();
  public void setHasAcceptanceFilterCommunicationFilterAcceptanceFilterOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIHasAcceptanceFilterCommunicationFilter newValue);
}
