package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The name and version of the communication protocol.
 */
public interface MICommunicationProtocol extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "CommunicationProtocol";
  // reference : communicationPeripheral_protocol_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_PERIPHERAL_PROTOCOL_OWNER = "communicationPeripheral_protocol_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: protocol
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_PERIPHERAL_PROTOCOL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_PERIPHERAL_PROTOCOL_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationProtocol",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.PROTOCOL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral getCommunicationPeripheralProtocolOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationPeripheralProtocolOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral newValue);
  // reference : version generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VERSION = "version";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationProtocol_version_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo VERSION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(VERSION,"ar3x.ecuresourcetemplate.peripherals.CommunicationProtocol",133,null,com.vector.cfg.model.mdf.commoncore.basetypes.MIStringItem.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.commoncore.basetypes.MIStringItem.COMMUNICATION_PROTOCOL_VERSION_OWNER_RELATION_INFO;}};
  /**
   * This is the version number of the implementation of the protocol layer, e.g.  - 2.0a, 2.0b  for CAN. - 1.3, 2.0 for LIN. - 2.0   for USB.
   */
  public java.util.List<com.vector.cfg.model.mdf.commoncore.basetypes.MIStringItem> getVersion();
}
