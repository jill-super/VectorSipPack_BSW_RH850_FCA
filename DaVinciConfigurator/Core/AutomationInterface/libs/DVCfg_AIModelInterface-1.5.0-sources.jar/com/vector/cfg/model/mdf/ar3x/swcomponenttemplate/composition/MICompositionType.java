package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A CompositionType aggregates ComponentPrototypes (that in turn are typed by ComponentTypes) as well as ConnectorPrototypes for primarily connecting ComponentPrototypes among each others and towards the surface of the CompositionType. By this means hierarchical structures of software-components can be created.  
 */
public interface MICompositionType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType
{
  public final static String CLASS_NAME = "CompositionType";
  // reference : compositionTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COMPOSITION_TYPE_ARREF_REF_TARGETS_OWNER = "compositionTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPOSITION_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPOSITION_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.composition.CompositionType",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionTypeARRef> getCompositionTypeARRefRefTargetsOwner();
  // reference : component generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT = "component";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compositionType_component_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT,"ar3x.swcomponenttemplate.composition.CompositionType",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype.COMPOSITION_TYPE_COMPONENT_OWNER_RELATION_INFO;}};
  /**
   * The instantiated components that are part of this composition.  The use case for having 0 components owned by the CompositionType could be to deliver an empty CompositionType to e.g. a supplier for filling the internal structure.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype> getComponent();
  // reference : compositionTypeConnector generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPOSITION_TYPE_CONNECTOR = "compositionTypeConnector";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compositionType_compositionTypeConnector_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPOSITION_TYPE_CONNECTOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPOSITION_TYPE_CONNECTOR,"ar3x.swcomponenttemplate.composition.CompositionType",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype.COMPOSITION_TYPE_COMPOSITION_TYPE_CONNECTOR_OWNER_RELATION_INFO;}};
  /**
   * ConnectorPrototypes have the principal ability to establish a connection among PortPrototypes. They can have many roles in the context of a CompositionType. Details are refined by subclasses.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype> getCompositionTypeConnector();
}
