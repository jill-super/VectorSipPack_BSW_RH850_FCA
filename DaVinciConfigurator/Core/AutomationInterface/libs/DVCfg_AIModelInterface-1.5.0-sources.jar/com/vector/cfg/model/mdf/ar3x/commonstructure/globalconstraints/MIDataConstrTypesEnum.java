package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;
import javax.jmi.model.*;

public enum MIDataConstrTypesEnum implements javax.jmi.reflect.RefEnum
{
  DATA_CONSTR("DATA-CONSTR");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "globalconstraints" );
    temp.add( "DataConstrTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDataConstrTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
