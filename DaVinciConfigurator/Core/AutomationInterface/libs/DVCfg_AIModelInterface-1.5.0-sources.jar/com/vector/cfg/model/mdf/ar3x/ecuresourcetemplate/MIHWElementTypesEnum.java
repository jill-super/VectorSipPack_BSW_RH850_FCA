package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;
import javax.jmi.model.*;

public enum MIHWElementTypesEnum implements javax.jmi.reflect.RefEnum
{
  ADC("ADC"),
  ACTUATOR_HW("ACTUATOR-HW"),
  ANALOGUE_IO("ANALOGUE-IO"),
  CCU("CCU"),
  CLOCK("CLOCK"),
  COMMUNICATION_PERIPHERAL("COMMUNICATION-PERIPHERAL"),
  COMMUNICATION_TRANSCEIVER("COMMUNICATION-TRANSCEIVER"),
  DAC("DAC"),
  DIGITAL_IO("DIGITAL-IO"),
  DISCRETE_ECU_ELECTRONICS("DISCRETE-ECU-ELECTRONICS"),
  DISPLAY_HW("DISPLAY-HW"),
  ECU("ECU"),
  ECU_ELECTRONICS("ECU-ELECTRONICS"),
  GENERAL_PURPOSE_TIMER("GENERAL-PURPOSE-TIMER"),
  HW_CONTAINER("HW-CONTAINER"),
  HW_ELEMENT("HW-ELEMENT"),
  HW_ELEMENT_CONTAINER("HW-ELEMENT-CONTAINER"),
  OSCILLATOR("OSCILLATOR"),
  PWD("PWD"),
  PWM("PWM"),
  PERIPHERAL("PERIPHERAL"),
  POWER_DRIVER_HW_ELEMENT("POWER-DRIVER-HW-ELEMENT"),
  POWER_SUPPLY_HW_ELEMENT("POWER-SUPPLY-HW-ELEMENT"),
  PROCESSING_UNIT("PROCESSING-UNIT"),
  PROVIDED_MEMORY_SEGMENT("PROVIDED-MEMORY-SEGMENT"),
  PROVIDED_NV_MEMORY_SEGMENT("PROVIDED-NV-MEMORY-SEGMENT"),
  PULSE_WIDTH_PERIPHERAL("PULSE-WIDTH-PERIPHERAL"),
  SENSOR_ACTUATOR_HW("SENSOR-ACTUATOR-HW"),
  SENSOR_HW("SENSOR-HW"),
  TIMER("TIMER"),
  WATCH_DOG("WATCH-DOG");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuresourcetemplate" );
    temp.add( "HWElementTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHWElementTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
