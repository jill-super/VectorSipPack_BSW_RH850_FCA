package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes how variables or parameters are addressed in the ECU. It contains a description of the addressing process and a reference to the concerned CPU memory segment. 
 */
public interface MISwAddrMethod extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "SwAddrMethod";
  // reference : swAddrMethodARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_ADDR_METHOD_ARREF_REF_TARGETS_OWNER = "swAddrMethodARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_ADDR_METHOD_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_ADDR_METHOD_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.auxillaryobjects.SwAddrMethod",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwAddrMethodARRef> getSwAddrMethodARRefRefTargetsOwner();
}
