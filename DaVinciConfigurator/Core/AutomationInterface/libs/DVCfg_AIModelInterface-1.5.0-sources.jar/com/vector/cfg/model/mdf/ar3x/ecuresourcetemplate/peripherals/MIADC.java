package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * An ADC converts an analogue signal at an input pin to a digital value. The analogue signal are quantified to a maximum number of different levels defined by the resolution of the ADC. The Accuracy of the ADC is important for the overall functionality.
 */
public interface MIADC extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO
{
  public final static String CLASS_NAME = "ADC";
  // attribute : behaviourAtLimit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BEHAVIOUR_AT_LIMIT = "behaviourAtLimit";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BEHAVIOUR_AT_LIMIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BEHAVIOUR_AT_LIMIT,"ar3x.ecuresourcetemplate.peripherals.ADC",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAdcBehaviourAtLimitEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the action that is going to be performed when a limit is reached. - Clipping: Logical value is limited to minimal or maximal range of the value range. E.g. The max. resolution of an ADC is at 5V represented 0xFF; in case off clipping a voltage of 6V is also represented as 0xFF; - Undefined: Exceeding the resolution results in an undefined representation of the logical value.  - Default: Exceeding the resolution results in a predefined default value. The default value might be a value, which report the status to the application e.g. as an error condition.  - Other: A predefined function occur in order to prevent a undefined logical value. A typical application is a "Soft-Clipping" in a logarithmic form at the limit of the resolutions in audio applications.  The according methods have to be specified in the signal description.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAdcBehaviourAtLimitEnum getBehaviourAtLimit();
  /**
   * Defines the action that is going to be performed when a limit is reached. - Clipping: Logical value is limited to minimal or maximal range of the value range. E.g. The max. resolution of an ADC is at 5V represented 0xFF; in case off clipping a voltage of 6V is also represented as 0xFF; - Undefined: Exceeding the resolution results in an undefined representation of the logical value.  - Default: Exceeding the resolution results in a predefined default value. The default value might be a value, which report the status to the application e.g. as an error condition.  - Other: A predefined function occur in order to prevent a undefined logical value. A typical application is a "Soft-Clipping" in a logarithmic form at the limit of the resolutions in audio applications.  The according methods have to be specified in the signal description.
   * Attribute-Kind = versionAttribute   */
  public void setBehaviourAtLimit(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAdcBehaviourAtLimitEnum newValue);
}
