package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes a procedure call in the software. Depending on the usage, the description can contain properties of the function call (signature) and of its implementation as well.
 */
public interface MISwService extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "SwService";
  // reference : swServiceReturn generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_RETURN = "swServiceReturn";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swService_swServiceReturn_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_RETURN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_RETURN,"ar3x.commonstructure.serviceprocesstask.SwService",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.SW_SERVICE_SW_SERVICE_RETURN_OWNER_RELATION_INFO;}};
  /**
   * The return type belonging to this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg getSwServiceReturn();
  /**
   * The return type belonging to this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceReturn(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg newValue);
  // reference : swServiceProps generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_PROPS = "swServiceProps";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swService_swServiceProps_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_PROPS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_PROPS,"ar3x.commonstructure.serviceprocesstask.SwService",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceProps.SW_SERVICE_SW_SERVICE_PROPS_OWNER_RELATION_INFO;}};
  /**
   * The properties assigned to this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceProps getSwServiceProps();
  /**
   * The properties assigned to this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceProps(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceProps newValue);
  // reference : swServiceAccessedElementSet generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_ACCESSED_ELEMENT_SET = "swServiceAccessedElementSet";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swService_swServiceAccessedElementSet_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_ACCESSED_ELEMENT_SET_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_ACCESSED_ELEMENT_SET,"ar3x.commonstructure.serviceprocesstask.SwService",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceAccessedElementSet.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceAccessedElementSet.SW_SERVICE_SW_SERVICE_ACCESSED_ELEMENT_SET_OWNER_RELATION_INFO;}};
  /**
   * Interface elements accessed by this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceAccessedElementSet> getSwServiceAccessedElementSet();
  // reference : swServiceArg generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_ARG = "swServiceArg";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swService_swServiceArg_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_ARG_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_ARG,"ar3x.commonstructure.serviceprocesstask.SwService",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg.SW_SERVICE_SW_SERVICE_ARG_OWNER_RELATION_INFO;}};
  /**
   * An argument belonging to this SwService.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwServiceArg> getSwServiceArg();
}
