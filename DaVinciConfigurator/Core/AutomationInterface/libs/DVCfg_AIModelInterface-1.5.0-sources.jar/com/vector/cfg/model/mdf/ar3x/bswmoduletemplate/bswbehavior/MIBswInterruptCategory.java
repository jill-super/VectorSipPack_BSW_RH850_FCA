package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;
import javax.jmi.model.*;

public enum MIBswInterruptCategory implements javax.jmi.reflect.RefEnum
{
  CAT_1("CAT-1"),
  CAT_2("CAT-2");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswbehavior" );
    temp.add( "BswInterruptCategory" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswInterruptCategory(String literalName)
  {
    this.literalName = literalName;
  }
}
