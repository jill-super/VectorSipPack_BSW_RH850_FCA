package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Base class for the type of the calibration axis. This provides the particular model of the specialization. If the specialization would be the directly from SwCalPrmAxis, the sequence of common properties and the specializes ones would be different.
 */
public interface MISwCalprmAxisTypeProps extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwCalprmAxisTypeProps";
  // reference : swCalprmAxis_swCalprmAxisTypeProps_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_SW_CALPRM_AXIS_TYPE_PROPS_OWNER = "swCalprmAxis_swCalprmAxisTypeProps_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swCalprmAxisTypeProps
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_SW_CALPRM_AXIS_TYPE_PROPS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_SW_CALPRM_AXIS_TYPE_PROPS_OWNER,"ar3x.commonstructure.calibrationparameter.SwCalprmAxisTypeProps",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis.SW_CALPRM_AXIS_TYPE_PROPS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis getSwCalprmAxisSwCalprmAxisTypePropsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisSwCalprmAxisTypePropsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis newValue);
}
