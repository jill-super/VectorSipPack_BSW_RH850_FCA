package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The General HW Element specifies definitions valid for all specific HW Elements.
 */
public interface MIHWElement extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "HWElement";
  // attribute : standbyCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STANDBY_CURRENT = "standbyCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STANDBY_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STANDBY_CURRENT,"ar3x.ecuresourcetemplate.HWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The Standby Current is the current in state OFF. For HW Elements the Standby Current consists of the current needed by the logic to stay in the state OFF and the leakage current of the HW Element. For big HW Elements the leakage current can be up to several 100 microA. Standby Current is used to determine which elements are necessary to be switch off, when the car itself is in a standby mode. This can be done automatically or by the user. The value for the Standby Current can be entered for each HW Element and HW Container respectively. The user has to take care about these values and decides about the entries necessary for the calculation of the complete standby current. On the other side the sum for all HW Elements grouped in a HW Container may have a bigger value than the value for the HW Container itself. In this case the values for the HW Elements represent the worst case for each HW Element.  Unit: Ampere (A)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getStandbyCurrent();
  /**
   * The Standby Current is the current in state OFF. For HW Elements the Standby Current consists of the current needed by the logic to stay in the state OFF and the leakage current of the HW Element. For big HW Elements the leakage current can be up to several 100 microA. Standby Current is used to determine which elements are necessary to be switch off, when the car itself is in a standby mode. This can be done automatically or by the user. The value for the Standby Current can be entered for each HW Element and HW Container respectively. The user has to take care about these values and decides about the entries necessary for the calculation of the complete standby current. On the other side the sum for all HW Elements grouped in a HW Container may have a bigger value than the value for the HW Container itself. In this case the values for the HW Elements represent the worst case for each HW Element.  Unit: Ampere (A)
   * Attribute-Kind = versionAttribute   */
  public void setStandbyCurrent(java.math.BigDecimal newValue);
  // reference : hWElementARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String H_WELEMENT_ARREF_REF_TARGETS_OWNER = "hWElementARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.HWElement",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef> getHWElementARRefRefTargetsOwner();
  // reference : supportsSafety generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPORTS_SAFETY = "supportsSafety";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElement_supportsSafety_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTS_SAFETY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTS_SAFETY,"ar3x.ecuresourcetemplate.HWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSafety.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSafety.H_WELEMENT_SUPPORTS_SAFETY_OWNER_RELATION_INFO;}};
  /**
   * The ECU Resource Template provides the element Supports Safety storing the information about the supported safety mechanism. In the current version of the ECU Resource Template the element Supports Safety is optional. A HW Element uses this element if it provides a safety mechanism otherwise this element is missing in the description of the HW Element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSafety getSupportsSafety();
  /**
   * The ECU Resource Template provides the element Supports Safety storing the information about the supported safety mechanism. In the current version of the ECU Resource Template the element Supports Safety is optional. A HW Element uses this element if it provides a safety mechanism otherwise this element is missing in the description of the HW Element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSupportsSafety(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSafety newValue);
  // reference : supportsSecurity generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPORTS_SECURITY = "supportsSecurity";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElement_supportsSecurity_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTS_SECURITY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTS_SECURITY,"ar3x.ecuresourcetemplate.HWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSecurity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSecurity.H_WELEMENT_SUPPORTS_SECURITY_OWNER_RELATION_INFO;}};
  /**
   * The ECU Resource Template provides the element SupportsSecurity storing the information about the supported security mechanism. In the current version of the ECU Resource Template the element SupportsSecurity is optional. A HW Element uses this element if it provides a security mechanism otherwise this element is missing in the description of the HW Element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSecurity getSupportsSecurity();
  /**
   * The ECU Resource Template provides the element SupportsSecurity storing the information about the supported security mechanism. In the current version of the ECU Resource Template the element SupportsSecurity is optional. A HW Element uses this element if it provides a security mechanism otherwise this element is missing in the description of the HW Element.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSupportsSecurity(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MISupportsSecurity newValue);
  // reference : hwElementTemperature generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HW_ELEMENT_TEMPERATURE = "hwElementTemperature";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElement_hwElementTemperature_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HW_ELEMENT_TEMPERATURE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HW_ELEMENT_TEMPERATURE,"ar3x.ecuresourcetemplate.HWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITemperature.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITemperature.H_WELEMENT_HW_ELEMENT_TEMPERATURE_OWNER_RELATION_INFO;}};
  /**
   * For the placement of a HW Element within a car the temperature has to be considered the HW Element has been designed for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITemperature getHwElementTemperature();
  /**
   * For the placement of a HW Element within a car the temperature has to be considered the HW Element has been designed for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHwElementTemperature(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITemperature newValue);
  // reference : port generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT = "port";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElement_port_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT,"ar3x.ecuresourcetemplate.HWElement",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort.H_WELEMENT_PORT_OWNER_RELATION_INFO;}};
  /**
   * All the HWPorts this HWElement exposes. This also includes delegation HWPorts of HWContainers.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort> getPort();
  // reference : signalTransformation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SIGNAL_TRANSFORMATION = "signalTransformation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElement_signalTransformation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SIGNAL_TRANSFORMATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SIGNAL_TRANSFORMATION,"ar3x.ecuresourcetemplate.HWElement",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MISignalTransformation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MISignalTransformation.H_WELEMENT_SIGNAL_TRANSFORMATION_OWNER_RELATION_INFO;}};
  /**
   * The Signal Transformation defines the conversion of the signal attached to a HW Port (direction In) and a signal attached to a HW Port (direction Out).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MISignalTransformation> getSignalTransformation();
  // reference : hWElementContainer_containedElement_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_CONTAINER_CONTAINED_ELEMENT_OWNER = "hWElementContainer_containedElement_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: containedElement
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_CONTAINER_CONTAINED_ELEMENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_CONTAINER_CONTAINED_ELEMENT_OWNER,"ar3x.ecuresourcetemplate.HWElement",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer.CONTAINED_ELEMENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer getHWElementContainerContainedElementOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementContainerContainedElementOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer newValue);
}
