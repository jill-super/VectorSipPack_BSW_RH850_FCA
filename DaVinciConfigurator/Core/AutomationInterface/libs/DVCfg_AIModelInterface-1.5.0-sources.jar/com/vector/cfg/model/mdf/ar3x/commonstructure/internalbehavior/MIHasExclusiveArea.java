package com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasExclusiveArea extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasExclusiveArea";
  // reference : exclusiveArea generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXCLUSIVE_AREA = "exclusiveArea";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasExclusiveArea_exclusiveArea_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXCLUSIVE_AREA_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXCLUSIVE_AREA,"ar3x.commonstructure.internalbehavior.HasExclusiveArea",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea.HAS_EXCLUSIVE_AREA_EXCLUSIVE_AREA_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveArea> getExclusiveArea();
}
